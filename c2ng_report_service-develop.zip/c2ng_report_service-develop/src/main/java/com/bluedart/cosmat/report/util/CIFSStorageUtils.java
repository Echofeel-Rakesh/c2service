package com.bluedart.cosmat.report.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;

import com.bluedart.cosmat.commons.constants.CommonConstant;
import com.bluedart.cosmat.report.constant.ReportConstant;
import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.FileAttributes;
import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2CreateOptions;
import com.hierynomus.mssmb2.SMB2Dialect;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.protocol.commons.EnumWithValue;
import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.SmbConfig;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.share.File;
import com.hierynomus.smbj.utils.SmbFiles;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CIFSStorageUtils {
    private static final String FILE_PATH_SEPARATOR = "/";
    private static SmbConfig staticConfig = SmbConfig.builder().withDfsEnabled(true).withDialects(SMB2Dialect.SMB_2_1).withSoTimeout(180, TimeUnit.SECONDS).withTimeout(180, TimeUnit.SECONDS).build();
    private static DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("ddMMMyyyy").withResolverStyle(ResolverStyle.STRICT);
    
    private CIFSStorageUtils() {
    }
	
    private static Comparator<FileIdBothDirectoryInformation> dateTimeComparator = (a, b) -> Long.compare(a.getLastWriteTime().getWindowsTimeStamp(), b.getLastWriteTime().getWindowsTimeStamp());

    public static boolean isValidFolder(String folderName) {
        try {
            dateFormatter.parse(folderName);
        } catch (DateTimeParseException e) {
            return false;
        }
        return true;
    }

    private static String getParentFolder(String filePath) {
		if (filePath == null || filePath.isEmpty()) 
            return "";

        int idx = filePath.lastIndexOf('/');
        return (idx > 0) ? filePath.substring(0, idx) : "";
	}

	private static String[] extractServerAndShareFromUrl(String inputUrl) {
		String toSplit = inputUrl.substring(6);
		return toSplit.split("/", 3);
	}

	private static SMBClient getSmbClient() {
		return new SMBClient(staticConfig); 
	}

    private static AuthenticationContext getAuthContext(String userName, String password, String domain) {
        if (null != userName && null != password) {
            userName = userName.replace("\n", "").replace("\r", "");
            password = password.replace("\n", "").replace("\r", "");
            return new AuthenticationContext(userName, password.toCharArray(), domain);
        }
        return new AuthenticationContext(userName, null, domain);
    }

	private static File getFileForWrite(DiskShare share, String filePath) {
		return share.openFile(filePath,
		EnumSet.of(AccessMask.FILE_WRITE_DATA),
		EnumSet.of(FileAttributes.FILE_ATTRIBUTE_NORMAL),
		SMB2ShareAccess.ALL,
		SMB2CreateDisposition.FILE_CREATE,
		EnumSet.of(SMB2CreateOptions.FILE_DIRECTORY_FILE));
	}

	private static File getFileForRead(DiskShare share, String filePath) {
		return share.openFile(filePath,
		EnumSet.of(AccessMask.FILE_READ_DATA),
		EnumSet.of(FileAttributes.FILE_ATTRIBUTE_NORMAL),
		SMB2ShareAccess.ALL,
		SMB2CreateDisposition.FILE_OPEN,
		EnumSet.of(SMB2CreateOptions.FILE_DIRECTORY_FILE));
	}

    public static List<String> getUserFoldersByDateDesc(String storageLocation, String location, boolean sort, String domain, String userName, String password) throws IOException {
        String smbPathUrl = storageLocation + FILE_PATH_SEPARATOR + location + FILE_PATH_SEPARATOR;
        log.info("Loading folders from path:"+smbPathUrl);
        log.debug("Provided login details:"+domain+", "+userName);
		String [] pathElements = extractServerAndShareFromUrl(smbPathUrl);
		
        try (Connection connection = getSmbClient().connect(pathElements[0])) {
            AuthenticationContext ac = getAuthContext(userName, password, domain);
            Session session = connection.authenticate(ac);
			
            try (DiskShare share = (DiskShare) session.connectShare(pathElements[1])) {
                List<FileIdBothDirectoryInformation> files = share.list(pathElements[2], "*");
                if(sort)
                    files.sort(dateTimeComparator);
                else 
                    files.sort(dateTimeComparator.reversed());
                List<String> folderNames = new ArrayList<>();
                for(FileIdBothDirectoryInformation file:files) {
                    if((".").equals(file.getFileName()) || ("..").equals(file.getFileName())) continue;
                    
                    if(EnumWithValue.EnumUtils.isSet(file.getFileAttributes(), FileAttributes.FILE_ATTRIBUTE_DIRECTORY) && isValidFolder(file.getFileName())) folderNames.add(file.getFileName());
                }
                return folderNames;
			}
		} catch (IOException ioe) {
			log.error("Error while getting file list:", ioe);
            return null;
		}
    }

    public static List<String> getUserFilesByFolderByDateDesc(String storageLocation, String location, String folderName, String domain, String userName, String password) throws IOException {
        String smbPathUrl = storageLocation + FILE_PATH_SEPARATOR + location + FILE_PATH_SEPARATOR + folderName + FILE_PATH_SEPARATOR;
        log.info("Loading files from path:"+smbPathUrl);
        String [] pathElements = extractServerAndShareFromUrl(smbPathUrl);
		
        try (Connection connection = getSmbClient().connect(pathElements[0])) {
            AuthenticationContext ac = getAuthContext(userName, password, domain);
            Session session = connection.authenticate(ac);
			
            try (DiskShare share = (DiskShare) session.connectShare(pathElements[1])) {
                List<FileIdBothDirectoryInformation> files = share.list(pathElements[2], "*");
                files.sort(dateTimeComparator.reversed());
                List<String> fileNames = new ArrayList<>();
                for(FileIdBothDirectoryInformation file:files) {
                    if(!EnumWithValue.EnumUtils.isSet(file.getFileAttributes(), FileAttributes.FILE_ATTRIBUTE_DIRECTORY)) fileNames.add(file.getFileName());
                }
                return fileNames;
			}
		} catch (IOException ioe) {
			log.error("Error while getting file list:", ioe);
            return null;
		}
    }

    public static String getReportFilePath(String storageLocation, String tempLocation, String location, String currentDate, String domain, String userName, String password, boolean forAWBinvoiceReport) {
    	String smbPathUrl;
    	if(forAWBinvoiceReport) {
    		smbPathUrl = null == tempLocation ? (storageLocation + FILE_PATH_SEPARATOR + location + FILE_PATH_SEPARATOR + ReportConstant.AWBINV_REPORT_FOLDER_NAME) : tempLocation;
        }else {
        	smbPathUrl = null == tempLocation ? (storageLocation + FILE_PATH_SEPARATOR + location + FILE_PATH_SEPARATOR + currentDate) : tempLocation;
        }
    	
    	smbPathUrl = smbPathUrl + FILE_PATH_SEPARATOR;
        log.info("Loading report from path:"+smbPathUrl);
        
        String [] pathElements = extractServerAndShareFromUrl(smbPathUrl);

		try (Connection connection = getSmbClient().connect(pathElements[0])) {
            AuthenticationContext ac = getAuthContext(userName, password, domain);
            Session session = connection.authenticate(ac);
			
            try (DiskShare share = (DiskShare) session.connectShare(pathElements[1])) {
				if(share.folderExists(pathElements[2])) return smbPathUrl;
				else {
                    try {
                        new SmbFiles().mkdirs(share, pathElements[2]);
                    } catch (Exception e) {
                        log.error("Could not perform mkdirs for path"+ pathElements[2], e);
                    }
                    return smbPathUrl;
                }
			} 
		} catch (IOException ioe) {
			log.error("URL is malformed or error while connecting to drive:"+smbPathUrl, ioe);
			return null;
		}
    }

    public static Resource loadFileAsResource(String domain, String userName, String password, String ...filePaths) throws FileNotFoundException, IOException {
        String smbPathUrl = String.join(FILE_PATH_SEPARATOR, filePaths);
        log.info("in loadFileAsResource:"+smbPathUrl);
        String[] pathElements = extractServerAndShareFromUrl(smbPathUrl);
        log.info("pathelements:"+Arrays.toString(pathElements));
        Connection connection = getSmbClient().connect(pathElements[0]);
        File file = null;
        AuthenticationContext ac = getAuthContext(userName, password, domain);
        Session session = connection.authenticate(ac);
        
        DiskShare share = (DiskShare) session.connectShare(pathElements[1]);

        log.info(pathElements[2]);
        Resource fileResource = null;
        if(share.fileExists(pathElements[2])) {
            file = getFileForRead(share, pathElements[2]);

            fileResource = new InputStreamResource(new SmbInputStream(file, connection, session, share));
            return fileResource;
        } else throw new FileNotFoundException(CommonConstant.FILE_NOT_FOUND);
    }

    public static OutputStream createNewReportFile(String fileName, String domain, String userName, String password) throws IOException {
        String [] pathElements = extractServerAndShareFromUrl(fileName);
        Connection connection = getSmbClient().connect(pathElements[0]);
        
        AuthenticationContext ac = getAuthContext(userName, password, domain);
        Session session = connection.authenticate(ac);
        
        DiskShare share = (DiskShare) session.connectShare(pathElements[1]);
        String parentPath = getParentFolder(pathElements[2]);
        log.info("pathElements[2]:"+pathElements[2]);
        log.info(parentPath);
        if(!share.folderExists(parentPath)) new SmbFiles().mkdirs(share, parentPath);

        File file = getFileForWrite(share, pathElements[2]);
        return new SmbOutputStream(file, false, connection, session, share);
    }
}
