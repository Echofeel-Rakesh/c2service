package com.bluedart.cosmat.report.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bluedart.cosmat.commons.constants.CommonConstant;
import com.bluedart.cosmat.commons.exception.APIResponse;
import com.bluedart.cosmat.report.model.MisReportsConfigResponse;
import com.bluedart.cosmat.report.service.MisReportsService;

@RestController
@RequestMapping("/misreports")
public class MisReportsConfigController {
	
	@Autowired
	MisReportsService misReportsService;
	
	/**
	 * This function is used for fetching start date and end date for MIS Reports
	 * @param reportName
	 * @return
	 * 
	 * @author sourabh_mokashi
	 */
	@GetMapping("/dates/{ReportName}")
	public APIResponse<MisReportsConfigResponse> getMisReportDates(@PathVariable("ReportName") String reportName) {
		
		MisReportsConfigResponse response = misReportsService.getMisReportDates(reportName);
		if(response==null) {
			return new APIResponse<>(false, CommonConstant.BAD_REQUEST_CODE, CommonConstant.NO_RECORDS_FOUND_MESSAGE);
		}
		return new APIResponse<>(false, CommonConstant.OK_CODE, CommonConstant.SUCCESS, response);
		
	}

}
