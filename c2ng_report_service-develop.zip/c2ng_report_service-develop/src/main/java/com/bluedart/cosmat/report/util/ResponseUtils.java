package com.bluedart.cosmat.report.util;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ResponseUtils {

	private ResponseUtils() {	
	}
	
	public static ResponseEntity<Resource> generateHTMLForView(Resource fileResource, String htmlHeader, String htmlFooter)
			throws IOException {
		log.info("converting to HTML..");
		try (InputStream inputStream = fileResource.getInputStream();
				ByteArrayOutputStream outputStream = new ByteArrayOutputStream();) {

			outputStream.write(htmlHeader.getBytes());
			StreamUtils.copy(inputStream, outputStream); // FileCopyUtils closes stream on write, use StreamUtils
			outputStream.write(htmlFooter.getBytes());

			ByteArrayResource byteArrayResource = new ByteArrayResource(outputStream.toByteArray());
			log.info("converted..");

			return ResponseEntity.ok().contentType(MediaType.TEXT_HTML).body(byteArrayResource);

		} catch (IOException exception) {
			log.info("error in html generation {} ", exception.getMessage());
			throw exception;
		}
	}
}
