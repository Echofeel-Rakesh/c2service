package com.bluedart.cosmat.report.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.PositiveOrZero;

import com.bluedart.cosmat.commons.utils.BaseModelMapper;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "REPORT", schema = "BDDATA")
public class ReportEntity implements BaseModelMapper{
	@JsonProperty(value = "id", required = true)
	@PositiveOrZero
	@Id
	@Column(name = "REPORTTYPEID")
	private Long reportId;
	@Column(name = "REPORTNAME")
	private String name;
	@Column(name = "REPORTDESCRIPTION")
	private String description;
	@Column(name = "REPORTRPTFILEPATH")
	private String reportrptfilepath;
	@Column(name = "MAXROWS")
	private Integer maxrows;
//	@Column(name = "MAXCOLUMNS")
//	private Integer maxcolumns;
//	@Column(name = "GRIDLENGTH")
//	private Integer gridlength;
	@JsonProperty(value = "parameters", required = true)
	@OneToMany(targetEntity = ReportparameterEntity.class,cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinColumn(name = "reporttypeid",referencedColumnName = "reporttypeid")
	private List<ReportparameterEntity> reportParameter;
}
