package com.bluedart.cosmat.report.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

public interface StorageService {
    public List<String> getUserFolders(String userLocation, boolean sortDesc);
    public List<String> getUserFilesByFolder(String userLocation, String folderName, boolean sortDesc) throws IOException;
    public InputStream loadFileAsStream(String userLocation, String folderName, String fileName) throws FileNotFoundException;
    public OutputStream getNewReportStreamForWrite(String folderName, String fileName);
    default String getReportFileName(String ...paths) {
        return null;
    }
}
