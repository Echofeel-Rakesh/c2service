package com.bluedart.cosmat.report.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.springframework.core.io.Resource;
public interface PrintManagerService {
    public List<String> getFolders(boolean sort) throws IOException;
    public List<String> getFilesForFolder(String folderName) throws IOException;
    public Resource downloadFile(String ...filePaths) throws FileNotFoundException, IOException;
}