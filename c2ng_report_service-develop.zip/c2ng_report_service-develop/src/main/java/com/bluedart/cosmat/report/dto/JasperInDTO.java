package com.bluedart.cosmat.report.dto;

import java.io.Serializable;

import com.bluedart.cosmat.commons.utils.BaseModelMapper;

import lombok.Data;
@Data
public class JasperInDTO implements Serializable,BaseModelMapper{

	private static final long serialVersionUID = 1L;
	private String puArea;
	private String emplCode;
	private String custName;
	private String custAddress1;
	private String custAddress2;
	private String custAddress3;
	private String contact;
	private String remarks;
	private String custTel;
	private String mobileNo;
	private String puTime;
	private String officialTime;
	private String tokenNo;
	private String awbNo;
	private String status;
	private String region;
	private String compliance;
	private String refNumber;
}