package com.bluedart.cosmat.report.service;

import java.util.List;

public interface PrintPickupSheetService {
	
	public List<String> getPrinterType();
	
	//public List<ViewprinterdetailsResponse> viewPrinterDetails(String printerType);
}
