package com.bluedart.cosmat.report.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bluedart.cosmat.report.entity.ReportparameterEntity;

public interface ReportparameterRepository extends JpaRepository<ReportparameterEntity, Integer> {

}
