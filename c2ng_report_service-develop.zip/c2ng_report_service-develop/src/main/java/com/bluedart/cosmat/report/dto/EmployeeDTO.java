package com.bluedart.cosmat.report.dto;

import java.io.Serializable;

import com.bluedart.cosmat.commons.utils.BaseModelMapper;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class EmployeeDTO implements Serializable,BaseModelMapper {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonProperty("a")
	private Long employeeName;
	@JsonProperty("b")
	private String employeeCode;

}
