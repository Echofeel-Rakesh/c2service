package com.bluedart.cosmat.report.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bluedart.cosmat.commons.auth.utils.CommonAuthUtils;
import com.bluedart.cosmat.commons.auth.utils.User;
import com.bluedart.cosmat.commons.constants.CommonConstant;
import com.bluedart.cosmat.commons.exception.APICustomException;
import com.bluedart.cosmat.commons.exception.APIResponse;
import com.bluedart.cosmat.commons.utils.BaseApiResponse;
import com.bluedart.cosmat.commons.utils.CacheManagerUtils;
import com.bluedart.cosmat.commons.utils.CommonExcelExporter;
import com.bluedart.cosmat.report.constant.ReportConstant;
import com.bluedart.cosmat.report.dto.PrintPickupExceptionDto;
import com.bluedart.cosmat.report.dto.ReportCacheDTO;
import com.bluedart.cosmat.report.dto.ReportCommonInDTO;
import com.bluedart.cosmat.report.dto.ReportCommonOutDTO;
import com.bluedart.cosmat.report.dto.ReportCommonResponseDTO;
import com.bluedart.cosmat.report.model.ReportConfDetailsModel;
import com.bluedart.cosmat.report.model.ReportConfModel;
import com.bluedart.cosmat.report.model.StoreTemplateEdlPrintRequest;
import com.bluedart.cosmat.report.service.ReportCommonService;
import com.bluedart.cosmat.report.util.ReportUtils;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;

@Slf4j
@RestController
public class ReportCommonController {
	
	@Autowired
	private ReportCommonService reportCommonService;
	
	@Autowired
	private ReportConfModel reportConfModel;
	
	@Autowired
	private ReportUtils reportUtils;
	
	@Autowired
	CacheManagerUtils cacheManagerUtils;
	
    @Autowired
    private CommonAuthUtils commonAuthUtils;
	
	private ObjectMapper objectMapper = new ObjectMapper();
	
	public static final String REPORT_TYPE_KEY = "NormalRadioButton";
	public static final String APEX_SFC_BUTTON="ApexSFCRadioButton";
	
	public static final String EMPLOYEEWISE = "EmployeewiseReconRadioButton";
	public static final String FULLSERVICECENTREWISE= "FullServiceCentreRadioButton";
	
	public static final String PREALERTRADIOBUTTON = "PrealertRadioButton";
	public static final String INBOUNDDTMRADIOBUTTON = "InboundDTMRadioButton";
	public static final String OUTBOUNDRADIOBUTTON = "OutboundRadioButton";

	public static final String STATUSDOMESTICRADIOBUTTON = "StatusDomesticRadioButton";
	public static final String STATUSINTERNATIONALRADIOBUTTON = "StatusInternationalRadioButton";
	
	public static final String NORMAL_UNCONNECTED_SHIPMENTS = "NormalUnconnectedReportRadioButton";
	public static final String SHIPMENTS_ONLY = "ShipmentsOnlyUnconnectedReportRadioButton";
	
	public static final String  DP_HUB= "DPHubsRadioButton";
	public static final String GROUND_HUB= "GroundHubsRadioButton";
	public static final String  BDA_HUB= "BDAStationsRadioButton";
	
	public static final String  PINCODE_DETAILED= "PinDetailedRadioButton";
	public static final String PINCODE_PRINTER= "ReportTypePrinterRadioButton";
	public static final String  PINCODE_SUMMARY= "PinSummaryRadioButton";
	
	public static final String IBOB_DAYBUTTON= "rdDaywiseRadioButton";
	public static final String IBOB_DESTBUTTON= "rdDestinationwiseRadioButton";
	
	public static final String  REPORTOPTIONSCOMBOBOX= "ReportOptionsComboBox";
	public static final String FLEET_TALLY= "Fleet Tally Report";
	public static final String SHIPMENT_RECD= "Shipment Received, Paperwork Not Received";
	public static final String PAPERWORK_RECD= "Paperwork Received, Shipment Not Received";
	public static final String NO_OF_PCS= "No Of Pcs. OSG/SSG";
	public static final String DAMAGE_SHIPMENT= "Damage Shipment";
	public static final String SHIPMENT_OSGSSG= "Shipment OSG/SSG";
	public static final String INCOMPLETE_PAPERWORK= "Incomplete Paper Work";
	public static final String PAPERWORK_OSGSSG= "PaperWork OSG/SSG";
	
	public static final String CONTAINERCHECKBOX= "ContainerCheckBox";
	public static final String AUTOSCANFLAG= "AutoScanFlag";
	public static final String CONTAINERQUERYRADIOBUTTON = "ContainerQueryRadioButton";
	
	public static final String AWB_WISE_RADIOBTN= "AwbWiseRadioButton";
	public static final String MPS_WISE_RADIOBTN= "MpsWiseRadioButton";
	
	public static final String NO_RECORD_STRING= "No Record";
	public static final String IN_PROGRESS ="In Progress";
	public static final String ERROR ="Error";
	
	@PostMapping("/generatereport")
	public APIResponse<ReportCommonResponseDTO> generateReport(@Valid @RequestBody ReportCommonInDTO reportCommonInDTO,
	HttpServletRequest httpServletRequest)
			throws APICustomException, JRException, IOException, InterruptedException, ExecutionException {
		log.info("Generate report Request Started...");
		String userID = commonAuthUtils.getUserDetails().getUsername();
		User user = commonAuthUtils.getUserDetails();
		Cache reportCache = null;
		// To track parallel request for finally block and not clear error in that
		// scenario
		boolean parallelRequestsStatus = false;
		var reportConfDetailsModel = new ReportConfDetailsModel();
		var cacheDto = new ReportCacheDTO();
		try {
			if (reportConfModel != null && reportCommonInDTO != null
					&& reportConfModel.getReportMap().get(reportCommonInDTO.getReportId()) != null) {
				if (reportCommonInDTO.getQueryParam() != null) {
					reportCommonInDTO
							.setQueryParam(reportUtils.getCorrectedQueryParams(reportCommonInDTO.getQueryParam()));
				}
				getReportType(reportCommonInDTO);
				reportConfDetailsModel = reportConfModel.getReportMap().get(reportCommonInDTO.getReportId());

				cacheDto = new ReportCacheDTO().convert(reportCommonInDTO);

				cacheDto.setUserId(userID);

				reportCache = cacheManagerUtils.getCacheValues(userID);
				
				if (reportCache != null) {
					if (reportCache.get(userID) != null) {
						// throw new APICustomException(ReportConstant.ERRORCODE_0,
						// ReportConstant.PARALLEL_REQUEST_NOT_ALLOWED);
						// Dont throw exception instead set a flag to not clear userid cache and return
						// the error response directly
						parallelRequestsStatus = true;
						return new APIResponse<>(true, ReportConstant.ERRORCODE_0,
								ReportConstant.PARALLEL_REQUEST_NOT_ALLOWED);
					} else {
						reportCache.put(userID, cacheDto);
					}
				}
				var reportCommonOutDTO = new ReportCommonOutDTO();
				var reportCommonResponseDTO = new ReportCommonResponseDTO();
				if (!reportConfDetailsModel.isAsync()) {
					reportCommonOutDTO = reportCommonService.generateReport(reportCommonInDTO,
							httpServletRequest.getHeader(CommonConstant.AUTHORIZATION_CONST), reportConfModel);
					return reportCommonService.reportFileGeneration(reportCommonInDTO, reportCommonOutDTO,
							reportConfModel, cacheDto, user,reportConfDetailsModel,reportCache);
				} else {
					// Async call
					reportCommonService.generateReportForAsynch(reportCommonInDTO,
							httpServletRequest.getHeader(CommonConstant.AUTHORIZATION_CONST), reportConfModel,
							reportCache, cacheDto, user,reportConfDetailsModel);
					reportCommonResponseDTO = new ReportCommonResponseDTO();
					cacheDto.setUUId(UUID.randomUUID().toString());
					cacheDto.setAsync(reportConfDetailsModel.isAsync());
					cacheDto.setOnStatus(false);
					reportCache.put(userID, cacheDto);
					reportCommonResponseDTO.setUUId(cacheDto.getUUId());
					reportCommonResponseDTO.setAsync(cacheDto.isAsync());
					return new APIResponse<>(false, CommonConstant.OK_CODE, CommonConstant.API_RESPONSE_SUCCESS,
							reportCommonResponseDTO);
				}
			}
		}catch (ExecutionException | InterruptedException e) {
			// TODO Auto-generated catch block
			log.error("Async Exception {}", e);
			Thread.currentThread().interrupt();
			cacheDto.setOnStatus(true);
			reportCache.put(userID, cacheDto);
			if (e.getCause() instanceof APICustomException) {
				log.error("API Custom Exception...");
				throw (APICustomException) e;
			}
			throw (APICustomException) e;

		}finally {
			// Clear the user cache to enable new report generation also set
			// parallelRequestsStatus flag to false for only synchronous call's
			if (!reportConfDetailsModel.isAsync() && null != reportCache && !parallelRequestsStatus)
				cacheManagerUtils.evictSingleCacheValue(reportCache.getName(), userID);
			parallelRequestsStatus = false;
		}
		log.info("Generate report Request Finished...");
		return new APIResponse<>(true, CommonConstant.BAD_REQUEST_CODE, CommonConstant.BAD_REQUEST_MESSAGE);
	}
	
	@GetMapping("/asyncreportstatus")
	public APIResponse<ReportCommonResponseDTO> asyncReportStatus(@RequestParam(value="a") String uuid)
			throws APICustomException {
		log.info("Async Status Report Request Started...");
		User user = commonAuthUtils.getUserDetails();
		Cache reportCache = null;
		//boolean parallelRequestsStatus = false;
		var respOut = new ReportCommonResponseDTO();

		try {
			reportCache = cacheManagerUtils.getCacheValues(user.getUsername());
			
			if (reportCache != null && (reportCache.get(user.getUsername()) != null || reportCache.get(user.getUsername().concat(uuid)) != null)) {
				ReportCacheDTO finalCache = null;
				if(reportCache.get(user.getUsername()) != null )
				    finalCache = (ReportCacheDTO) reportCache.get(user.getUsername()).get();
				else if(reportCache.get(user.getUsername().concat(uuid)) !=null)
					finalCache = (ReportCacheDTO) reportCache.get(user.getUsername().concat(uuid)).get();
				
				if (uuid.equals(finalCache.getUUId())) {
					respOut.setUUId(finalCache.getUUId());
				}else {
					respOut.setUUId(StringUtils.EMPTY);
				}
				respOut.setAsync(finalCache.isAsync());
				respOut.setFolderName(finalCache.getFolderName());
				if(StringUtils.isNotBlank(finalCache.getReportFile()))
				   respOut.setReportFile(finalCache.getReportFile());
				if(StringUtils.isNotBlank(finalCache.getStatusMessage()))
					  respOut.setMessage(finalCache.getStatusMessage());
					
				respOut.setDone(finalCache.isOnStatus());
				return new APIResponse<>(false, CommonConstant.OK_CODE, CommonConstant.API_RESPONSE_SUCCESS,
						respOut);
			}else {
				respOut.setUUId(StringUtils.EMPTY);
				respOut.setAsync(false);
				return new APIResponse<>(false, CommonConstant.OK_CODE, CommonConstant.API_RESPONSE_SUCCESS,
						respOut);
			}

		} finally {
			// Clear the user cache to enable new report generation also set
			// parallelRequestsStatus flag to false for only synchronous call's 
			if (respOut.isDone() == true && null != reportCache) {
				cacheManagerUtils.evictSingleCacheValue(reportCache.getName(), user.getUsername());
				cacheManagerUtils.evictAllCacheValues(user.getUsername().concat(uuid));
			}
			//parallelRequestsStatus = false;
		}
	}
	
	public void getReportType(ReportCommonInDTO reportCommonInDTO) {
		if (reportCommonInDTO.getQueryParam() != null && null != reportCommonInDTO.getQueryParam().get(REPORT_TYPE_KEY)
				&& reportCommonInDTO.getQueryParam().get(REPORT_TYPE_KEY).toString()
						.equalsIgnoreCase(APEX_SFC_BUTTON)) {
			reportCommonInDTO.setReportId(618l);
		} else if (reportCommonInDTO.getReportId() == 51 && reportCommonInDTO.getQueryParam() != null
				&& null != reportCommonInDTO.getQueryParam().get(EMPLOYEEWISE) && reportCommonInDTO.getQueryParam()
						.get(EMPLOYEEWISE).toString().equalsIgnoreCase(FULLSERVICECENTREWISE)) {
			reportCommonInDTO.setReportId(619l);
		} else if (reportCommonInDTO.getReportId() == 39 && reportCommonInDTO.getQueryParam() != null
				&& null != reportCommonInDTO.getQueryParam().get(NORMAL_UNCONNECTED_SHIPMENTS)
				&& reportCommonInDTO.getQueryParam().get(NORMAL_UNCONNECTED_SHIPMENTS).toString()
						.equalsIgnoreCase(SHIPMENTS_ONLY)) {
			reportCommonInDTO.setReportId(621l);
		} else if (reportCommonInDTO.getReportId() == 148 && reportCommonInDTO.getQueryParam() != null
				&& null != reportCommonInDTO.getQueryParam().get(PREALERTRADIOBUTTON) && reportCommonInDTO.getQueryParam()
				.get(PREALERTRADIOBUTTON).toString().equalsIgnoreCase(INBOUNDDTMRADIOBUTTON)) {
			reportCommonInDTO.setReportId(702l);
		} else if (reportCommonInDTO.getReportId() == 148 && reportCommonInDTO.getQueryParam() != null
				&& null != reportCommonInDTO.getQueryParam().get(PREALERTRADIOBUTTON) && reportCommonInDTO.getQueryParam()
				.get(PREALERTRADIOBUTTON).toString().equalsIgnoreCase(OUTBOUNDRADIOBUTTON)) {
			reportCommonInDTO.setReportId(703l);
		} else if (reportCommonInDTO.getReportId() == 11 && reportCommonInDTO.getQueryParam() != null
				&& null != reportCommonInDTO.getQueryParam().get(STATUSDOMESTICRADIOBUTTON) && reportCommonInDTO.getQueryParam()
				.get(STATUSDOMESTICRADIOBUTTON).toString().equalsIgnoreCase(STATUSDOMESTICRADIOBUTTON)) {
			reportCommonInDTO.setReportId(708l);
		} else if (reportCommonInDTO.getReportId() == 11 && reportCommonInDTO.getQueryParam() != null
				&& null != reportCommonInDTO.getQueryParam().get(STATUSDOMESTICRADIOBUTTON) && reportCommonInDTO.getQueryParam()
				.get(STATUSDOMESTICRADIOBUTTON).toString().equalsIgnoreCase(STATUSINTERNATIONALRADIOBUTTON)) {
			reportCommonInDTO.setReportId(709l);
		} else if (reportCommonInDTO.getReportId() == 161 && reportCommonInDTO.getQueryParam() != null
				&& null != reportCommonInDTO.getQueryParam().get(IBOB_DAYBUTTON) && reportCommonInDTO.getQueryParam()
				.get(IBOB_DAYBUTTON).toString().equalsIgnoreCase(IBOB_DESTBUTTON)) {
			reportCommonInDTO.setReportId(717l);
		}
		
		else if (reportCommonInDTO.getReportId() == 14 && reportCommonInDTO.getQueryParam() != null
				&& null != reportCommonInDTO.getQueryParam().get(DP_HUB)
				&& reportCommonInDTO.getQueryParam().get(DP_HUB).toString()
						.equalsIgnoreCase(BDA_HUB)) {
			reportCommonInDTO.setReportId(706l);
		}
		else if (reportCommonInDTO.getReportId() == 14 && reportCommonInDTO.getQueryParam() != null
				&& null != reportCommonInDTO.getQueryParam().get(DP_HUB)
				&& reportCommonInDTO.getQueryParam().get(DP_HUB).toString()
						.equalsIgnoreCase(GROUND_HUB)) {
			reportCommonInDTO.setReportId(707l);
		}
		
		else if (reportCommonInDTO.getReportId() == 12 && reportCommonInDTO.getQueryParam() != null
				&& null != reportCommonInDTO.getQueryParam().get(PINCODE_PRINTER)
				&& reportCommonInDTO.getQueryParam().get(PINCODE_PRINTER).toString()
						.equalsIgnoreCase(PINCODE_PRINTER)) {
			reportCommonInDTO.setReportId(705l);
		}
		else if (reportCommonInDTO.getReportId() == 12 && reportCommonInDTO.getQueryParam() != null
				&& null != reportCommonInDTO.getQueryParam().get(PINCODE_PRINTER)
				&& reportCommonInDTO.getQueryParam().get(PINCODE_PRINTER).toString()
						.equalsIgnoreCase(PINCODE_SUMMARY)) {
			reportCommonInDTO.setReportId(704l);
		}
		
		else if (reportCommonInDTO.getReportId() == 135 && reportCommonInDTO.getQueryParam() != null
				&& null != reportCommonInDTO.getQueryParam().get(REPORTOPTIONSCOMBOBOX)
				&& reportCommonInDTO.getQueryParam().get(REPORTOPTIONSCOMBOBOX).toString()
				.equalsIgnoreCase(NO_OF_PCS)) {
			reportCommonInDTO.setReportId(713l);
		}
		else if (reportCommonInDTO.getReportId() == 135 && reportCommonInDTO.getQueryParam() != null
				&& null != reportCommonInDTO.getQueryParam().get(REPORTOPTIONSCOMBOBOX)
				&& reportCommonInDTO.getQueryParam().get(REPORTOPTIONSCOMBOBOX).toString()
				.equalsIgnoreCase(FLEET_TALLY)) {
			reportCommonInDTO.setReportId(714l);
		}
		else if (reportCommonInDTO.getReportId() == 135 && reportCommonInDTO.getQueryParam() != null
				&& null != reportCommonInDTO.getQueryParam().get(REPORTOPTIONSCOMBOBOX)
				&& (reportCommonInDTO.getQueryParam().get(REPORTOPTIONSCOMBOBOX).toString()
				.equalsIgnoreCase(PAPERWORK_OSGSSG) ||
				reportCommonInDTO.getQueryParam().get(REPORTOPTIONSCOMBOBOX).toString()
				.equalsIgnoreCase(INCOMPLETE_PAPERWORK) ||
				reportCommonInDTO.getQueryParam().get(REPORTOPTIONSCOMBOBOX).toString()
				.equalsIgnoreCase(SHIPMENT_OSGSSG) ||
				reportCommonInDTO.getQueryParam().get(REPORTOPTIONSCOMBOBOX).toString()
				.equalsIgnoreCase(DAMAGE_SHIPMENT) ||
				reportCommonInDTO.getQueryParam().get(REPORTOPTIONSCOMBOBOX).toString()
				.equalsIgnoreCase(PAPERWORK_RECD) ||
				reportCommonInDTO.getQueryParam().get(REPORTOPTIONSCOMBOBOX).toString()
				.equalsIgnoreCase(SHIPMENT_RECD))) {
			reportCommonInDTO.setReportId(712l);
		}
		else if(reportCommonInDTO.getReportId() == 36 && reportCommonInDTO.getQueryParam() != null) {
			reportCommonInDTO.getQueryParam().put(AUTOSCANFLAG, false);
			
			if(reportCommonInDTO.getQueryParam().containsKey(CONTAINERCHECKBOX)
				&& reportCommonInDTO.getQueryParam().get(CONTAINERCHECKBOX) != null
				&& reportCommonInDTO.getQueryParam().get(CONTAINERCHECKBOX).toString().equalsIgnoreCase("true")) {
				reportCommonInDTO.setReportId(716l);
			}
		}
		else if(reportCommonInDTO.getReportId() == 37 && reportCommonInDTO.getQueryParam() != null) {
			 reportCommonInDTO.getQueryParam().put(AUTOSCANFLAG, true);
		}
		
		else if(reportCommonInDTO.getReportId() == 99 && reportCommonInDTO.getQueryParam() != null 
				&& (reportCommonInDTO.getQueryParam().get("ShortReportCheckBox")!=null?reportCommonInDTO.getQueryParam().get("ShortReportCheckBox").toString():"").equalsIgnoreCase("true"))
		{
			reportCommonInDTO.setReportId(723l);
		}
		
		else if(reportCommonInDTO.getReportId() == 100 && reportCommonInDTO.getQueryParam() != null 
				&& (reportCommonInDTO.getQueryParam().get("ShortReportCheckBox")!=null?reportCommonInDTO.getQueryParam().get("ShortReportCheckBox").toString():"").equalsIgnoreCase("true"))
		{
			reportCommonInDTO.setReportId(724l);
		}
		else if(reportCommonInDTO.getReportId() == 101 && reportCommonInDTO.getQueryParam() != null 
				&& (reportCommonInDTO.getQueryParam().get("ShortReportCheckBox")!=null?reportCommonInDTO.getQueryParam().get("ShortReportCheckBox").toString():"").equalsIgnoreCase("true"))
		{
			reportCommonInDTO.setReportId(725l);
		}
		else if(reportCommonInDTO.getReportId() == 734 && reportCommonInDTO.getQueryParam() != null 
				&& (reportCommonInDTO.getQueryParam().get("ShortReportCheckBox")!=null?reportCommonInDTO.getQueryParam().get("ShortReportCheckBox").toString():"").equalsIgnoreCase("true"))
		{
			reportCommonInDTO.setReportId(725l);
		}
		else if(reportCommonInDTO.getReportId() == 102 && reportCommonInDTO.getQueryParam() != null 
				&& (reportCommonInDTO.getQueryParam().get("ShortReportCheckBox")!=null?reportCommonInDTO.getQueryParam().get("ShortReportCheckBox").toString():"").equalsIgnoreCase("true"))
		{
			reportCommonInDTO.setReportId(726l);
		}
		else if (reportCommonInDTO.getReportId() == 596 && reportCommonInDTO.getQueryParam() != null
				&& null != reportCommonInDTO.getQueryParam().get(AWB_WISE_RADIOBTN)
				&& reportCommonInDTO.getQueryParam().get(AWB_WISE_RADIOBTN).toString()
						.equalsIgnoreCase(MPS_WISE_RADIOBTN)) {
			reportCommonInDTO.setReportId(730l);
		}
		else if(reportCommonInDTO.getReportId() == 139 && reportCommonInDTO.getQueryParam() != null 
				&& reportCommonInDTO.getQueryParam().get("DetailedRadioButton").toString().equalsIgnoreCase("SingleLineRadioButton"))
		{
			reportCommonInDTO.setReportId(727l);
		}
		else if (reportCommonInDTO.getReportId() == 175 && reportCommonInDTO.getQueryParam() != null
				&& reportCommonInDTO.getQueryParam().get(CONTAINERQUERYRADIOBUTTON) != null 
				&& !reportCommonInDTO.getQueryParam().get(CONTAINERQUERYRADIOBUTTON).toString()
				.equalsIgnoreCase(CONTAINERQUERYRADIOBUTTON)) {
			reportCommonInDTO.setReportId(728l);
		}
		
		else if(reportCommonInDTO.getReportId() == 127 && reportCommonInDTO.getQueryParam() != null 
				&& reportCommonInDTO.getQueryParam().get("CBdestRadioButton").toString()
				.equalsIgnoreCase("PBdestRadioButton")) {
				reportCommonInDTO.setReportId(729l);
		}
	}
	
	@PostMapping("/exporttoexcel")
	public void exportLocation(@Valid @RequestBody ReportCommonInDTO reportCommonInDTO, HttpServletRequest httpServletRequest,HttpServletResponse response, JsonNode dataList)
			throws APICustomException, IOException {

		if (reportConfModel != null && reportCommonInDTO != null
				&& reportConfModel.getReportMap().get(reportCommonInDTO.getReportId()) != null) {
			reportCommonInDTO.setQueryParam(reportUtils.getCorrectedQueryParams(reportCommonInDTO.getQueryParam()));
			ReportConfDetailsModel reportConfDetailsModel = reportConfModel.getReportMap()
					.get(reportCommonInDTO.getReportId());

			ReportCommonOutDTO reportCommonOutDTO = reportCommonService.generateReport(reportCommonInDTO,
					httpServletRequest.getHeader(CommonConstant.AUTHORIZATION_CONST), reportConfModel);

			String json = objectMapper.writeValueAsString(reportCommonOutDTO.getReportResponse().getData());
		objectMapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);

		List<PrintPickupExceptionDto> list = objectMapper.readValue(json, new TypeReference<List<PrintPickupExceptionDto>>() {});

			ByteArrayInputStream byteArrayInputStream = CommonExcelExporter.writeToExcel(
					reportConfDetailsModel.getReportName(), /* exportYamlConfig.getLocations() */null, list);

			CommonExcelExporter.export(reportConfDetailsModel.getReportName(), response, byteArrayInputStream);
		}
		
	}
	
	
	 @PostMapping("/storesfilesafterprint")
		public APIResponse<BaseApiResponse> storeFilesAfterPrint(
				@RequestBody @Valid StoreTemplateEdlPrintRequest storeTemplateEdlPrintRequest) {
			var baseApiResponse = new BaseApiResponse();
			try {
				reportUtils.saveFileForPrint(storeTemplateEdlPrintRequest.getTemplateContent(),
						commonAuthUtils.getUserDetails().getUsername(), storeTemplateEdlPrintRequest.getFileName(),
						commonAuthUtils.getUserDetails().getLocation());
			} catch (Exception e) {
				log.error("Error in storeFilesAfterPrint", e);
				return new APIResponse<>(true, CommonConstant.RESPONSE_TEXT_9001, "Issue in path");
			}
			return new APIResponse<>(false, CommonConstant.RESPONSE_TEXT_9000, CommonConstant.SUCCESS, baseApiResponse);
		}

		

}