package com.bluedart.cosmat.report.dto;

import java.io.Serializable;
import java.util.List;

import com.bluedart.cosmat.commons.utils.BaseModelMapper;
import com.bluedart.cosmat.report.entity.ReportparameterEntity;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReportParameterDTO implements Serializable, BaseModelMapper {
	
	private static final long serialVersionUID = 1L;
	@JsonProperty(value = "id")
	private Long reportId;
	private String name;
	private String description;
	private String reportrptfilepath;
	@JsonProperty("async")
	private boolean async;
	private Integer maxrows;
	@JsonProperty(value = "parameters")
	private List<ReportparameterEntity> reportParameter;
	private Boolean isMultiServiceCenters;
	
}