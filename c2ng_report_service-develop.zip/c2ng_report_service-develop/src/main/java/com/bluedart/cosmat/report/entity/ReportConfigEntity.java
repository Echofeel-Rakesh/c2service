package com.bluedart.cosmat.report.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name ="MIS_REPORT_CONFIG")
public class ReportConfigEntity {

	@Id
	@Column(name="REPORT_ID")
	private Long reportId;
	
	@Column(name="REPORT_NAME")
	private String reportName;
	
	@Column(name="MV_USED")
	private String mvUsed;
	
	@Column(name="START_DATE")
	private Date startDate;
	
	@Column(name="END_DATE")
	private Date endDate;
}
