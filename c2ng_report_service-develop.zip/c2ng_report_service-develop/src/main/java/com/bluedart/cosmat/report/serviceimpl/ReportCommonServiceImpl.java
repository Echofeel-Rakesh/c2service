package com.bluedart.cosmat.report.serviceimpl;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.bluedart.cosmat.commons.auth.utils.User;
import com.bluedart.cosmat.commons.constants.CommonConstant;
import com.bluedart.cosmat.commons.exception.APICustomException;
import com.bluedart.cosmat.commons.exception.APIResponse;
import com.bluedart.cosmat.commons.utils.CacheManagerUtils;
import com.bluedart.cosmat.report.constant.ReportConstant;
import com.bluedart.cosmat.report.dto.ReportCacheDTO;
import com.bluedart.cosmat.report.dto.ReportCommonInDTO;
import com.bluedart.cosmat.report.dto.ReportCommonOutDTO;
import com.bluedart.cosmat.report.dto.ReportCommonResponseDTO;
import com.bluedart.cosmat.report.model.ReportConfDetailsModel;
import com.bluedart.cosmat.report.model.ReportConfModel;
import com.bluedart.cosmat.report.service.ReportCommonService;
import com.bluedart.cosmat.report.service.remoteimpl.PickupService;
import com.bluedart.cosmat.report.util.ReportConstants;
import com.bluedart.cosmat.report.util.ReportUtils;

import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;

@Slf4j
@Service
public class ReportCommonServiceImpl implements ReportCommonService{

	@Autowired
	private PickupService pickupService;
	
	@Autowired
	private ReportUtils reportUtils;
	
	@Autowired
	CacheManagerUtils cacheManagerUtils;
	
	public static final String NO_RECORD_STRING= "No Record";
	
	@Override
	public ReportCommonOutDTO generateReport(@Valid ReportCommonInDTO reportCommonInDTO,String httpServletRequest,
				ReportConfModel reportConfModel) throws APICustomException {

		ReportCommonOutDTO reportCommonOutDTO=new ReportCommonOutDTO();
		reportCommonOutDTO.setReportGenerationId(DateTimeFormatter.ofPattern(ReportConstant.REPORT_TIMESTAMP).format(LocalDateTime.now()));
		reportCommonOutDTO.setReportId(reportCommonInDTO.getReportId()); 
		if (reportCommonInDTO.getReportData() != null) {
			APIResponse<List<?>> apiResponse = new APIResponse<>(false, "200", "success", reportCommonInDTO.getReportData());
			reportCommonOutDTO.setReportResponse(apiResponse);
		}	
		else {
			reportCommonOutDTO.setReportResponse(this.getReportResponse(reportCommonInDTO,httpServletRequest,reportConfModel));	
		}
		return reportCommonOutDTO;
	}

	private APIResponse<List<?>> getReportResponse(ReportCommonInDTO reportCommonInDTO,String httpServletRequest,ReportConfModel reportConfModel) throws APICustomException{

		ReportConfDetailsModel reportConfDetailsModel = reportConfModel.getReportMap()
				.get(reportCommonInDTO.getReportId());

		if(reportConfDetailsModel != null && reportConfDetailsModel.getWebclient()!=null) {
			if(CommonConstant.GET.equalsIgnoreCase(reportConfDetailsModel.getWebclient().getMethodType())) {
				return pickupService.getReport(reportCommonInDTO, reportConfDetailsModel, httpServletRequest);
			} else if(CommonConstant.POST.equalsIgnoreCase(reportConfDetailsModel.getWebclient().getMethodType())) {
				return pickupService.getPostReport(reportCommonInDTO, reportConfDetailsModel, httpServletRequest);
			}
			else 
				return null;
		}
		return null;
	}
	
	@Async
	@Override
	public APIResponse<ReportCommonResponseDTO> generateReportForAsynch(@Valid ReportCommonInDTO reportCommonInDTO,
			String httpServletRequest, ReportConfModel reportConfModel,Cache reportCache,ReportCacheDTO cacheDto,User user,ReportConfDetailsModel reportConfDetailsModel)
			throws APICustomException, IOException,InterruptedException,JRException,ExecutionException {
		try {
			ReportCommonOutDTO reportCommonOutDTO=generateReport(reportCommonInDTO, httpServletRequest, reportConfModel);
			return reportFileGeneration(reportCommonInDTO, reportCommonOutDTO, reportConfModel, cacheDto, user,reportConfDetailsModel,reportCache);

		}catch (Exception e) {
			cacheDto.setOnStatus(true);
			reportCache.put(user.getUsername(), cacheDto);
			log.error(e.getMessage(),e);
		}finally {
			// Clear the user cache to enable new report generation also set
			if (null != reportCache) {
				ReportCacheDTO reportDto = (ReportCacheDTO) reportCache.get(user.getUsername()).get();
				reportCache.put(user.getUsername().concat(reportDto.getUUId()), reportDto);
				cacheManagerUtils.evictSingleCacheValue(reportCache.getName(), user.getUsername());
			}
		}
		return null;
	
	}
	@Override
	public APIResponse<ReportCommonResponseDTO> reportFileGeneration(@Valid ReportCommonInDTO reportCommonInDTO,ReportCommonOutDTO reportCommonOutDTO,ReportConfModel reportConfModel,ReportCacheDTO cacheDto,User user,ReportConfDetailsModel reportConfDetailsModel,Cache reportCache) throws JRException, IOException {
		var reportCommonResponseDTO = new ReportCommonResponseDTO();
		if (reportCommonOutDTO != null && reportCommonOutDTO.getReportResponse() != null) {
			getXlsxCommonData(reportCommonOutDTO, reportCommonInDTO);
			reportConfModel.getReportMap().get(reportCommonInDTO.getReportId()).isAsync();
			if (CommonConstant.OK_CODE.equalsIgnoreCase(reportCommonOutDTO.getReportResponse().getStatusCode())) {
				reportCommonResponseDTO = reportUtils.generateJasperReport(reportCommonOutDTO,
						reportConfModel.getReportMap()
						.get(reportCommonInDTO.getReportId()), reportCommonInDTO,cacheDto,user);
				if (reportCommonResponseDTO != null) {
					log.info("Generate report Request Finished Successfully...");
					asyncCacheDetails(reportCommonResponseDTO,cacheDto,reportConfDetailsModel,true,reportCache,user);//cachedto details
					return new APIResponse<>(false, CommonConstant.OK_CODE, CommonConstant.API_RESPONSE_SUCCESS,
							reportCommonResponseDTO);
				}
			} else if (StringUtils.containsIgnoreCase(reportCommonOutDTO.getReportResponse().getMessage(),
					NO_RECORD_STRING)) {
				reportCommonResponseDTO = new ReportCommonResponseDTO();
				reportCommonResponseDTO.setFolderName(ReportConstants.FILETYPE_TEMP);
				reportCommonResponseDTO.setMessage(reportCommonOutDTO.getReportResponse().getMessage());
				asyncCacheDetails(reportCommonResponseDTO,cacheDto,reportConfDetailsModel,true,reportCache,user);//cachedto details
				return new APIResponse<>(false, CommonConstant.OK_CODE, CommonConstant.API_RESPONSE_SUCCESS,
						reportCommonResponseDTO);
			} else {
				asyncCacheDetails(reportCommonResponseDTO,cacheDto,reportConfDetailsModel,true,reportCache,user);//cachedto details
				return new APIResponse<>(reportCommonOutDTO.getReportResponse().isError(),
						reportCommonOutDTO.getReportResponse().getStatusCode() != null
								? reportCommonOutDTO.getReportResponse().getStatusCode()
								: CommonConstant.BAD_REQUEST_CODE,
						reportCommonOutDTO.getReportResponse().getMessage() != null
								? reportCommonOutDTO.getReportResponse().getMessage()
								: CommonConstant.BAD_REQUEST_MESSAGE);
			}
		}
		
         log.info("Generate report Async Request Finished...");
        asyncCacheDetails(reportCommonResponseDTO,cacheDto,reportConfDetailsModel,true,reportCache,user);//cachedto details
		return new APIResponse<>(true, CommonConstant.BAD_REQUEST_CODE, CommonConstant.BAD_REQUEST_MESSAGE);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void getXlsxCommonData(ReportCommonOutDTO reportCommonOutDTO, ReportCommonInDTO reportCommonInDTO) {
		if (reportCommonOutDTO.getReportId() == 173
				&& CommonConstant.XLSX.equalsIgnoreCase(reportCommonInDTO.getFormat())) {
			Object res = reportCommonOutDTO.getReportResponse().getData().get(0);
			LinkedHashMap<String, Object> map = (LinkedHashMap<String, Object>) res;
			Object s = map.get(ReportConstant.DST_STOCK);
			reportCommonOutDTO
					.setReportResponse(new APIResponse<List<?>>(reportCommonOutDTO.getReportResponse().isError(),
							reportCommonOutDTO.getReportResponse().getStatusCode(),
							reportCommonOutDTO.getReportResponse().getMessage(), (List<?>) s));
		}

	}
	
	private void asyncCacheDetails(ReportCommonResponseDTO reportCommonResponseDTO,ReportCacheDTO cacheDto,ReportConfDetailsModel reportConfDetailsModel,boolean status,Cache reportCache,User user) {
		if (reportConfDetailsModel.isAsync()) {
			if(StringUtils.isNotBlank(reportCommonResponseDTO.getReportFile()))
			    cacheDto.setReportFile(reportCommonResponseDTO.getReportFile());
			else
				cacheDto.setStatusMessage(reportCommonResponseDTO.getMessage());
			
			cacheDto.setFolderName(reportCommonResponseDTO.getFolderName());
			cacheDto.setOnStatus(status);
			reportCache.put(user.getUsername(), cacheDto);
		}
	}
	
}