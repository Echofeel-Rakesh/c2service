package com.bluedart.cosmat.report.util;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

public class ReportCustomFunction {
	
	public static String secondaryHeader(String prodCode) {
		if(prodCode.equalsIgnoreCase("D")) {
			return "List Of Outstanding DOD Shipment";
		} else if(prodCode.equalsIgnoreCase("F")) {
			return "List Of Outstanding FOD Shipment";
		} else {
			return "List Of Outstanding DOD/FOD Shipment";
		}
	}

	public static String prodTitle(String prodCode) {
		if(prodCode.equalsIgnoreCase("D")) {
			return "DP Shpt";
		} else if(prodCode.equalsIgnoreCase("A")) {
			return "Apex Shpt";
		} else if(prodCode.equalsIgnoreCase("C")) {
			return "Surface/Apex Shpt";
		} else if(prodCode.equalsIgnoreCase("S")) {
			return "Surface Shpt";
		} else {
			return "";
		}
	}
	
	public static String groupTitle(String cpuType) {
		if (cpuType.equals("1")) {
			return "Field Pickups";
		}else if (cpuType.equals("2") || cpuType.equals("3") || cpuType.equals("4") ||cpuType.equals("5")) {
			return "Walkins";
		}else {
			return "";
		}

	}

	public static String pickupTypeTitle(String cpuType, String pickupEmplCode, String orgArea) {
		if (cpuType.equals("1"))
			return pickupEmplCode;
		else if (cpuType.equals("2"))
			return orgArea + "/" + pickupEmplCode;
		else if (cpuType.equals("3"))
			return "Counter Shpts";
		else if (cpuType.equals("4"))
			return "Redirect/RTOs";
		else if (cpuType.equals("5"))
			return "FOC AWBs/Comail";
		else
			return "";
	}

	public static String empCustName(String cpuType, String employeeName) {
		if (cpuType.equals("1"))
			return employeeName;
		else if (cpuType.equals("2"))
			return employeeName;
		else
			return "";
	}

	public static Integer sum(Integer a, Integer b) {
		return a + b;
	}

	/*
	 * Command Method for calculate TotalManualANDEntryAWBsPerGroup /
	 * ManualTotalAWBs
	 */
	public static Integer totalManualANDEntryAWBsPerGroup(Integer first, Integer second, Integer third, Integer fourth,
			Integer fifth, Integer sixth) {
		Integer totalDataEntryAWBs = 0;

		if (first != null)
			totalDataEntryAWBs = totalDataEntryAWBs + first;

		if (second != null)
			totalDataEntryAWBs = totalDataEntryAWBs + second;

		if (third != null)
			totalDataEntryAWBs = totalDataEntryAWBs + third;

		if (fourth != null)
			totalDataEntryAWBs = totalDataEntryAWBs + fourth;

		if (fifth != null)
			totalDataEntryAWBs = totalDataEntryAWBs + fifth;

		if (sixth != null)
			totalDataEntryAWBs = totalDataEntryAWBs + sixth;

		return totalDataEntryAWBs;
	}

	/*
	 * Command Method for calculate TotalManualANDEntryPcsPerGroup / ManualTotalPcs
	 */
	public static Integer totalManualANDEntryPcsPerGroup(Integer first, Integer second, Integer third) {
		Integer totaldataentrypcs = 0;

		if (first != null)
			totaldataentrypcs = totaldataentrypcs + first;

		if (second != null)
			totaldataentrypcs = totaldataentrypcs + second;

		if (third != null)
			totaldataentrypcs = totaldataentrypcs + third;

		return totaldataentrypcs;
	}

	/* Command Method for calculate Manual-(DataEntry + Unbooked) */
	public static Integer calculateDiffABC(Integer a, Integer b, Integer c) {
		Integer A = 0;
		Integer B = 0;
		Integer C = 0;

		if (a != null)
			A = A + a;

		if (b != null)
			B = B + b;

		if (c != null)
			C = C + c;

		return A - (B + C);

	}

	/* Command Method for calculate ALL Bal On Hand C+D */
	public static Integer calculateBalance(Integer first, Integer second) {
		if (first == null && second == null)
			return 0;
		else if (first == null)
			return second;
		else if (second == null)
			return first;
		else
			return (first + second);

	}

	public static boolean subReportShowFunction(String cpuType, String first, Integer second, Integer third,
			Integer fourth, Integer fifth) {
		if (first.equals("WithAWBDetailsRadioButton")) {
			if ((Integer.parseInt(cpuType) > 0 && Integer.parseInt(cpuType) < 6)) {
				if ((second == 0 && third == 0 && fourth == 0 && fifth == 0)) {
					return false;
				} else {
					return true;
				}
			} else {
				return false;

			}
		} else {
			return false;
		}
	}

	public static boolean pickupTallyGroupValidation(String cpuType, String summaryOnlyRadioButton) {

		if (cpuType==null) {

			return false;

		}else if (summaryOnlyRadioButton.equals("WithAWBDetailsRadioButton") && Integer.parseInt(cpuType) > 0
				&& Integer.parseInt(cpuType) < 6) {
			return true;

		}else if (summaryOnlyRadioButton.equals("SummaryOnlyRadioButton") && Integer.parseInt(cpuType) > 0
				&& Integer.parseInt(cpuType) < 6) {
			return true;

		}else {
			return false;
		}
	}

	public static Integer pickupTallyGroupSum(String cpuType, Integer first) {

		if (cpuType == null)
			return 0;
		else if (Integer.parseInt(cpuType) > 0 && Integer.parseInt(cpuType) < 6)
			return first;
		else
			return 0;
	}

	public static Integer pickupTallySubReportAWBDetails(String awbNo) {
		if (awbNo == null || awbNo.isEmpty()) {
			return 0;
		} else {
			return Integer.parseInt(awbNo);
		}
	}

	public static String pickupTimeAnalysisCalPercent(Integer first, Integer second) {
		if (first == null || first == 0 || second == null || second == 0) {
			return "0.00";
		} else {
			DecimalFormat df=new DecimalFormat("#.00");
			double firstVal = first;
			double secondVal = second;
			return df.format((secondVal / firstVal) * 100);
		}
	}

	public static String pickupTypeAndNameValue(String cpuType, Integer first) {
		if ((cpuType.equals("1") ||cpuType.equals("2")) && first == 0) {
			return "";
		}
		return first.toString();
	}

	public static String pickupTypeAndNameValueShowEmpty(String cpuType, Integer first) {
		if ((cpuType.equals("2")|| cpuType.equals("3") || cpuType.equals("4") || cpuType.equals("5"))&& first == 0) {
			return "";
	    }
		return first.toString();
	}

	public static boolean pickupTypeSubReport(Integer awbnumber) {
		if (awbnumber == 0)
			return true;
		else
			return false;
	}

	public static String pickupTypeDateFormat() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		return dtf.format(now);
	}

	public static String pickupTypeDateSubReport(String date) {
		if (date != null) {
			StringBuilder buff = new StringBuilder(date);
			return buff.substring(8, 10) + "/" + buff.substring(5, 7);
		} else {
			return "";
		}
	}

	public static boolean pickupTypeSubReportValidateLine(Integer awbnumber) {
		if (awbnumber != 0)
			return true;
		else
			return false;
	}

	public static String groupByForSecurityException(String awbNo, String orgArea, String prodCode, String mpsNo) {
		String result = awbNo;

		if (StringUtils.isNotEmpty(orgArea)) {
			result = result + orgArea;
		}

		if (StringUtils.isNotEmpty(prodCode)) {
			result = result + prodCode;
		}

		if (StringUtils.isNotEmpty(mpsNo)) {
			result = result + mpsNo;
		}
		return result;
	}

	public static String getFormateDateForExcel(String date) throws ParseException
	{
		DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy"); 
		Date dates = formatter.parse(date);

		SimpleDateFormat newFormat = new SimpleDateFormat("dd/MM/yyyy");
		return  newFormat.format(dates);
	
	}
	
	public static String get24HrsformatDate(String str) throws ParseException {
		
		String formatedTime = StringUtils.EMPTY; 
		if(StringUtils.isNotBlank(str)) {
			String time = StringUtils.substring(str, 11, 16)+StringUtils.substring(str, 19, 23);
			SimpleDateFormat displayFormat = new SimpleDateFormat("HH:mm");
			SimpleDateFormat parseFormat = new SimpleDateFormat("hh:mm a");
			Date date = parseFormat.parse(time);
			formatedTime = displayFormat.format(date);
		}
		return formatedTime;
	}
	
	public static String groupByForPreAlertWiseReport(String flightNumber,String vehicleNumber, String runCode, String flightDate) {

		return (flightNumber + vehicleNumber + runCode + StringUtils.substring(flightDate, 0, 11).replace('/', '-') );
	}
}