package com.bluedart.cosmat.report.util;

import org.apache.commons.lang3.StringUtils;

import com.bluedart.cosmat.report.constant.ReportConstant;

public class UnconnectedContainersConditions {

	public static boolean displayPBheader(String ncType) {
		if("101".equals(ncType))
			return true;
		else
		return false;
	}
	
	public static boolean displayCBheader(String ncType) {
		if("102".equals(ncType))
			return true;
		else
		return false;
	}
	
	public static boolean displayVanheader(String ncType) {
		if("103".equals(ncType))
			return true;
		else
				return false;
	}
	
	public static boolean displayULDheader(String ncType) {
		if("104".equals(ncType))
			return true;
		else
			return false;
	}
	
	public static String convertDateTodDdMm(String date) {
		if (date != null) {
			String[] aa = date.split("-");
			return aa[2]+"/"+aa[1];
		} else {
			return "";
		}
	}
	
	public static String getWeight(Double weight) {
		if (weight != null && weight!= 0.0) {
			return String.valueOf(String.format("%.2f", weight));
		} else {
			return "";
		}
	}
	
	public static String getIncludeExcludeDetailsRegions(String regionFlag , String regions) {
		
		String dstRegions = "";
		
		if(StringUtils.isNotEmpty(regionFlag)) {
			regions = getCommaSepratedValues(regions);
			if(regionFlag.equals("E")) {
				dstRegions = "Excluding Regions "+regions;
			} else if(regionFlag.equals("I")) {
				dstRegions = "Including Regions "+regions;
			}
		}
		return dstRegions;
	}
	
	public static String getIncludeExcludeDetailsAreas(String areaFlag , String areas) {
		
		String dstAreas = "";
		
		if(StringUtils.isNotEmpty(areaFlag)) {
			areas = getCommaSepratedValues(areas);
			if(areaFlag.equals("E")) {
				dstAreas = "Excluding Areas "+areas;
			} else if(areaFlag.equals("I")) {
				dstAreas = "Including Areas "+areas;
			}
		}
		return dstAreas;
	}
	
	public static String getCommaSepratedValues(String rawString) {
		
		String formatedString = "";
		
		if (StringUtils.isNotBlank(rawString)) {
			StringBuilder value = new StringBuilder();
			String[] s1 = rawString.split(",");			
			for (String str : s1) {
				if (StringUtils.isNotBlank(str)) {
					value = value.append(str.trim()+",");
				}
			}
			
			formatedString = StringUtils.substring(value.toString(), 0, value.length()-1);
		}
			return formatedString;
	}
	
	public static String getHighPriorityDetails(String priority) {
		String details = StringUtils.EMPTY;
		if (priority.equalsIgnoreCase(ReportConstant.SHORTKEY_F)) {
			details = ReportConstant.NON_PRIORITY_SHIPMENTS;
		} else if(priority.equalsIgnoreCase(ReportConstant.SHORTKEY_T)) {
			details = ReportConstant.HIGH_PRIORITY_SHIPMENTS;
		} 
		return details;
	}
	
	public static String getDoxsDutsDetails(String type) {
		String details = StringUtils.EMPTY;
		if (type.equalsIgnoreCase(ReportConstant.SHORTKEY_1)) {
			details = ReportConstant.ONLY_DOXS;
		} else if(type.equalsIgnoreCase(ReportConstant.SHORTKEY_2)) {
			details = ReportConstant.ONLY_DUTS;
		} 
		return details;
	}

	public static String getCustCodeDetails(String flag , String value, String orgArea) {

		String custCodes = "";

		if(StringUtils.isNotEmpty(flag)) {
			value = getCommaSepratedValues(orgArea) + " " + getCommaSepratedValues(value);
			if(flag.equals(ReportConstant.SHORTKEY_E)) {
				custCodes = "Excluding Customer Codes "+value;
			} else if(flag.equals(ReportConstant.SHORTKEY_I)) {
				custCodes = "Including Customer Codes "+value;
			}
		}
		return custCodes;
	}

	public static String getEmployeeCodeDetails(String flag , String value) {

		String empCodes = "";

		if(StringUtils.isNotEmpty(flag)) {
			value = getCommaSepratedValues(value);
			if(flag.equals(ReportConstant.SHORTKEY_E)) {
				empCodes = "Excluding Emp Codes "+value;
			} else if(flag.equals(ReportConstant.SHORTKEY_I)) {
				empCodes = "Including Emp Codes "+value;
			}
		}
		return empCodes;
	}

	public static String getScanTimeDetails(String time) {

		String str = "";

		if(StringUtils.isNotEmpty(time)) {
			str = "Time " + time;
		}
		return str;
	}

	public static String getScanDateDetails(String date) {

		String str = "";

		if(StringUtils.isNotEmpty(date)) {
			str = "Inscan Date " + date.replace('-', '/');
		}
		return str;
	}
}