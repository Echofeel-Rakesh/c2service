package com.bluedart.cosmat.report.util;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;

import java.util.Optional;
import java.util.Set;

import org.apache.commons.io.IOUtils;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bluedart.cosmat.commons.auth.entity.CommonWsUserMstEntity;
import com.bluedart.cosmat.commons.auth.entityview.WsUserMstView;
import com.bluedart.cosmat.commons.auth.repository.CommonWsUserMstRepository;
import com.bluedart.cosmat.commons.auth.service.CommonAuthService;
import com.bluedart.cosmat.commons.auth.utils.User;
import com.bluedart.cosmat.commons.constants.CommonConstant;
import com.bluedart.cosmat.commons.utils.BaseApiResponse;
import com.bluedart.cosmat.commons.utils.CommonExcelExporter;
import com.bluedart.cosmat.commons.utils.CommonUtils;
import com.bluedart.cosmat.report.constant.ReportConstant;
import com.bluedart.cosmat.report.dto.ReportCacheDTO;
import com.bluedart.cosmat.report.dto.ReportCommonInDTO;
import com.bluedart.cosmat.report.dto.ReportCommonOutDTO;
import com.bluedart.cosmat.report.dto.ReportCommonResponseDTO;
import com.bluedart.cosmat.report.model.ReportConfDetailsModel;
import com.bluedart.cosmat.report.service.PrintManagerService;

import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRParameter;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.export.JRTextExporter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.engine.fill.JRAbstractLRUVirtualizer;
import net.sf.jasperreports.engine.fill.JRGzipVirtualizer;
import net.sf.jasperreports.engine.fill.JRSwapFileVirtualizer;
import net.sf.jasperreports.engine.util.JRSwapFile;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleTextReportConfiguration;
import net.sf.jasperreports.export.SimpleWriterExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;

@Component
@Slf4j
public class ReportUtils {

	@Value("${report.storage-location}")
	String reportStorageLocation;

	@Value("${report.report-temp-location}")
	String reportTempLocation;

	@Value("${report.storage-domain}")
    String storageDomain;

    @Value("${report.storage-username}")
    String storageUserName;

    @Value("${report.storage-password}")
    String storagePassword;
    
    @Value("${version.application-version}")
   	String version;
    
    @Value("${report.virtualizer}")
    String virtualizerName;

	@Autowired
	private CommonAuthService userManagementService;

	@Autowired
	private CommonWsUserMstRepository commonWsUserMstRepository;
	
	@Autowired
	private PrintManagerService printManagerService;

	public ReportCommonResponseDTO generateJasperReport(ReportCommonOutDTO reportCommonOutDTO,
			ReportConfDetailsModel reportConfDetailsModel, ReportCommonInDTO reportCommonInDTO,ReportCacheDTO cacheDto,User user)
			throws JRException, IOException {

		List<?> jasperInDTOList = reportCommonOutDTO.getReportResponse().getData();
		boolean forAWBinvoiceReport = false;
		log.info("Report Id: "+reportCommonInDTO.getReportId());
		log.error("Report Id: "+reportCommonInDTO.getReportId());
        if (jasperInDTOList != null && !jasperInDTOList.isEmpty() || reportCommonInDTO.getReportId()==147) {
			//User user = commonAuthUtils.getUserDetails();
			WsUserMstView wsUserMstView = userManagementService.findByCloginId(cacheDto.getUserId());

			String currentDate = getCurrentDateFolder();
			String folderPath = "";
			
			if (ReportConstant.AWBINV_REPORT_ID.equals(reportCommonInDTO.getReportId())) {
				forAWBinvoiceReport = true;
				folderPath = getReportFilePath(reportCommonInDTO.isSaveReport(), wsUserMstView.getLocation(),
						currentDate, forAWBinvoiceReport);
			} else {
				folderPath = getReportFilePath(reportCommonInDTO.isSaveReport(), wsUserMstView.getLocation(),
						currentDate, forAWBinvoiceReport);
			}
			String fileName = "";
			if(ReportConstant.AWBINV_REPORT_ID.equals(reportCommonInDTO.getReportId())) {
				fileName = createFileNameForAWBGstInvoiceReport(reportConfDetailsModel.getReportName(), reportCommonInDTO);
			} else if(ReportConstant.ONE_DELIVERY_EMPLOYEE_REPORT_ID.equals(reportCommonInDTO.getReportId())) {
				fileName = createFileNameForOneDeliveryEmployeeReport(reportConfDetailsModel.getReportName(),
						reportCommonInDTO, reportCommonOutDTO);
			} else if(ReportConstant.SERVICE_CENTRE_DETAILS_REPORT_ID.equals(reportCommonInDTO.getReportId())) {
				fileName = createFileNameForServiceCentreDetailsReport(wsUserMstView, reportCommonInDTO,
						reportCommonOutDTO);
			} else {
				fileName = createFileName(wsUserMstView, reportCommonOutDTO, reportConfDetailsModel.getReportName());
			}
			String filePath = null;
			//User loggedInUser = commonAuthUtils.getUserDetails();

			if (CommonConstant.PDF.equalsIgnoreCase(reportCommonInDTO.getFormat())) {
				fileName = fileName + CommonConstant.DOT + CommonConstant.PDF;
				filePath = folderPath + fileName;
				log.info("Report generated at path:"+filePath);
				generatePdfFile(jasperInDTOList, reportConfDetailsModel, filePath, user, reportCommonInDTO);
				return getReportCommonResponseDTO(reportCommonInDTO.isSaveReport(), fileName, currentDate, null, forAWBinvoiceReport);
			} else if (CommonConstant.XLSX.equalsIgnoreCase(reportCommonInDTO.getFormat())) {

				fileName = fileName + CommonConstant.DOT + CommonConstant.XLSX;
				filePath = folderPath + fileName;
				log.info("Report being generated at path:"+filePath);
				if (reportConfDetailsModel.isJasperExcel()) {
					generateXlsxFile(jasperInDTOList, reportConfDetailsModel, filePath, user,
							reportCommonInDTO);
				} else {
					this.generateReportExcel(reportConfDetailsModel.getReportName(), filePath, jasperInDTOList);
				
					/*filterKeys(reportConfDetailsModel.getReportName(),
							(List<LinkedHashMap<String, Object>>) (jasperInDTOList));
					ByteArrayInputStream byteArrayInputStream = CommonExcelExporter.writeToExcel(
							reportConfDetailsModel.getReportName(),
							(List<LinkedHashMap<String, Object>>) (jasperInDTOList));
					try (OutputStream out = getNewReportFile(filePath)) {
						IOUtils.copy(byteArrayInputStream, out/* new FileOutputStream(filePath) *//*);
					} catch (IOException e) {
						log.error("Error while creating Xlsx (simple) report", e);
					}*/
				}
				log.info("Report generated at path:"+filePath);
				return getReportCommonResponseDTO(reportCommonInDTO.isSaveReport(), fileName, currentDate, null, forAWBinvoiceReport);
			} else if (CommonConstant.TEXT.equalsIgnoreCase(reportCommonInDTO.getFormat())) {

				fileName = fileName + CommonConstant.DOT + CommonConstant.TEXT;
				filePath = folderPath + fileName;
				log.info("Report generated at path:"+filePath);
				generateTextFile(jasperInDTOList, reportConfDetailsModel, filePath, user, reportCommonInDTO);
				return getReportCommonResponseDTO(reportCommonInDTO.isSaveReport(), fileName, currentDate, null, forAWBinvoiceReport);
			}
		}

		return getReportCommonResponseDTO(reportCommonInDTO.isSaveReport(), null, null,
				ReportConstants.NO_RECORDS_TO_GENERATE_REPORT, forAWBinvoiceReport);
	}

	private void filterKeys(String reportName, List<LinkedHashMap<String, Object>> jasperInDTOList) {

		if (ReportConstant.SECURITY_REPORT.equals(reportName)) {
			List<String> list = Arrays.asList(ReportConstant.EXCLUDE_KEYS.split(","));
			LinkedHashMap<String, Object> map = jasperInDTOList.get(0);
			for (String key : list) {
				map.remove(key);
			}
			List<LinkedHashMap<String, Object>> listElement = (List<LinkedHashMap<String, Object>>) map
					.get(ReportConstant.GET_KEY);
			for (int i = 0; i < listElement.size(); i++) {
				LinkedHashMap<String, Object> listElement1 = listElement.get(i);
				listElement1.remove(ReportConstant.EXCLUDE_INTERNAL_KEYS.split(",")[0]);
				listElement1.remove(ReportConstant.EXCLUDE_INTERNAL_KEYS.split(",")[1]);

				String value = (String) listElement1.get(ReportConstant.DATE_FORMAT);
				listElement1.put(ReportConstant.DATE_FORMAT_DSTAT, getFormattedDate(value));
				listElement1.remove(ReportConstant.EXCLUDE_INTERNAL_KEYS.split(",")[2]);
				jasperInDTOList.add(i, listElement.get(i));
			}
		}

	}
	
	private String getFormattedDate(String inputDate) {
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a", Locale.US);
		String formattedDate = "";
		try {
			java.util.Date temp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse(inputDate);
			formattedDate = format.format(temp);
		} catch (ParseException e) {
			log.error("Invalid Date Format" + e.getMessage());
		}
		return formattedDate;
	}

	private ReportCommonResponseDTO getReportCommonResponseDTO(boolean isSaveReport, String fileName,
			String currentDate, String message, boolean forAWBinvoiceReport) {
		ReportCommonResponseDTO reportCommonResponseDTO = new ReportCommonResponseDTO();
		reportCommonResponseDTO.setReportFile(fileName);
		if(forAWBinvoiceReport) {
			reportCommonResponseDTO.setFolderName(isSaveReport ? ReportConstant.AWBINV_REPORT_FOLDER_NAME : ReportConstants.FILETYPE_TEMP);
		}else {
			reportCommonResponseDTO.setFolderName(isSaveReport ? currentDate : ReportConstants.FILETYPE_TEMP);
		}
		
		reportCommonResponseDTO.setMessage(message);

		return reportCommonResponseDTO;
	}

	private void generateTextFile(List<?> jasperInDTOList, ReportConfDetailsModel reportConfDetailsModel,
			String filePath, User loggedInUser, ReportCommonInDTO reportCommonInDTO) throws JRException {

		JasperPrint jasperPrint = getJasperPrint(jasperInDTOList, reportConfDetailsModel, loggedInUser,
				reportCommonInDTO);
		JRTextExporter exporter = new JRTextExporter();
		final SimpleTextReportConfiguration txtConfiguration = new SimpleTextReportConfiguration();
		txtConfiguration.setCharWidth(CommonConstant.JASPER_TXT_REPORT_CHAR_WIDTH);
		txtConfiguration.setCharHeight(CommonConstant.JASPER_TXT_REPORT_CHAR_HEIGHT);
		if(reportConfDetailsModel.getReportName().equals("PickupSheetApexSFC") ||reportConfDetailsModel.getReportName().equals("PickupSheetNormal"))
		{
			txtConfiguration.setCharWidth(14f);
			txtConfiguration.setCharHeight(26f);
		}
		exporter.setConfiguration(txtConfiguration);

		exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
		try (OutputStream out = getNewReportFile(filePath)) {
			SimpleWriterExporterOutput exporterOutput = new SimpleWriterExporterOutput(out);
			exporter.setExporterOutput(exporterOutput);
			exporter.exportReport();
		} catch (IOException e) {
			log.error("Error while creating Text report", e);
		}
	}

	private JasperPrint getJasperPrint(List<?> jasperInDTOList, ReportConfDetailsModel reportConfDetailsModel,
			User loggedInUser, ReportCommonInDTO reportCommonInDTO) throws JRException {

		JRAbstractLRUVirtualizer virtualizer = null;

		if (ReportConstant.virtualizer.equals(virtualizerName)) {
			virtualizer = new JRGzipVirtualizer(2);
			virtualizer.setReadOnly(true);
		} else {
			virtualizer = new JRSwapFileVirtualizer(3, new JRSwapFile(null, 2048, 1024), false);
		}
		InputStream employeeReportStream = getClass()
				.getResourceAsStream(reportConfDetailsModel.getOutput().getJrxmlTemplate());
		log.info("Compiling report");
		JasperReport jasperReport = JasperCompileManager.compileReport(employeeReportStream);

		JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(jasperInDTOList);
		Map<String, Object> parameters = new HashMap<>();
		if (reportConfDetailsModel.getOutput().getSubReportTemplate() != null) {
			log.info("Compiling subreports");
			for (Entry<String, String> entry : reportConfDetailsModel.getOutput().getSubReportTemplate().entrySet()) {
				InputStream subReportStream = getClass().getResourceAsStream(entry.getValue());
				JasperDesign subReportTemplate = JRXmlLoader.load(subReportStream);
				JasperReport subReport = JasperCompileManager.compileReport(subReportTemplate);
				parameters.put(entry.getKey(), subReport);
			}
		}
		parameters.put(ReportConstants.CREATED_BY, loggedInUser.getUsername());

		parameters.put(ReportConstants.USER_LOCATION, loggedInUser.getLocation());
		parameters.put(ReportConstants.APPLICATION_VERSION, version);

		parameters.put(JRParameter.REPORT_VIRTUALIZER, virtualizer);
		Optional<CommonWsUserMstEntity> commonWsUserMst = commonWsUserMstRepository
				.findByLoginId(loggedInUser.getUsername());
		if (commonWsUserMst.isPresent()) {
			parameters.put(ReportConstants.USER_ID, commonWsUserMst.get().getEmpCode());
			parameters.put(ReportConstants.EMPLOYEE_NAME, commonWsUserMst.get().getName());
		}
		if (reportCommonInDTO.getQueryParam() != null ) {
			parameters.putAll(reportCommonInDTO.getQueryParam());
		}
		return JasperFillManager.fillReport(jasperReport, parameters, dataSource);
	}

	private void generateXlsxFile(List<?> jasperInDTOList, ReportConfDetailsModel reportConfDetailsModel,
			String filePath, User loggedInUser, ReportCommonInDTO reportCommonInDTO) throws JRException {
		JasperPrint jasperPrint = getJasperPrint(jasperInDTOList, reportConfDetailsModel, loggedInUser,
				reportCommonInDTO);
		JRXlsxExporter exporter = new JRXlsxExporter();
		exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
		try (OutputStream out = getNewReportFile(filePath)) {
			exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(out));
			SimpleXlsxReportConfiguration configXlsx = new SimpleXlsxReportConfiguration();
			configXlsx.setShowGridLines(false);
			configXlsx.setRemoveEmptySpaceBetweenRows(true);
			exporter.setConfiguration(configXlsx);
			exporter.exportReport();
		} catch (IOException e) {
			log.error("Error while creating Xlsx report", e);
		}
	}

	private void generatePdfFile(List<?> jasperInDTOList, ReportConfDetailsModel reportConfDetailsModel,
			String filePath, User loggedInUser, ReportCommonInDTO reportCommonInDTO) throws JRException {
		JasperPrint jasperPrint = getJasperPrint(jasperInDTOList, reportConfDetailsModel, loggedInUser,
				reportCommonInDTO);
		try (OutputStream out = getNewReportFile(filePath)) {
			JasperExportManager.exportReportToPdfStream(jasperPrint, out);
		} catch (IOException e) {
			log.error("Error while creating Pdf report", e);
		}
	}

	private String getReportFilePath(boolean isSaveReport, String location, String currentDate, boolean forAWBinvoiceReport) {
		String reportTempPath = (isSaveReport ? null : reportTempLocation);
		if(null != reportTempPath) {
			reportTempPath = (reportTempPath.startsWith(ReportConstant.CIFS_PREFIX) || Paths.get(reportTempPath).normalize().isAbsolute()) ? reportTempPath : Paths.get(reportStorageLocation , reportTempPath).normalize().toString();
		}
		log.info("reportTempPath:"+reportTempPath);
		String pathToCheck = isSaveReport ? reportStorageLocation : reportTempPath;
		if( null == pathToCheck ) pathToCheck = reportStorageLocation;
		log.info("pathToCheck:"+pathToCheck);
		if(null == pathToCheck) return null;
		return pathToCheck.startsWith(ReportConstant.CIFS_PREFIX) ? CIFSStorageUtils.getReportFilePath(reportStorageLocation, reportTempPath, location, currentDate, storageDomain, storageUserName, storagePassword, forAWBinvoiceReport) : getLocalReportFilePath(isSaveReport, pathToCheck, location, currentDate, forAWBinvoiceReport);
	}
	
	private String getLocalReportFilePath(boolean isSaveReport, String basePath, String location, String currentDate, boolean forAWBinvoiceReport) {
		Path reportPath;
		if (forAWBinvoiceReport) {
			reportPath = isSaveReport
					? Paths.get(reportStorageLocation, location, ReportConstant.AWBINV_REPORT_FOLDER_NAME).normalize()
					: Paths.get(basePath).normalize();
		} else {
			reportPath = isSaveReport ? Paths.get(reportStorageLocation, location, currentDate).normalize() : Paths.get(basePath).normalize();
		}
		
		Path newReportPath = null;
		try {
			newReportPath = Files.createDirectories(reportPath);
		} catch (IOException e) {
			log.error("getReportFilePath:unable to create path"+newReportPath, e);
			newReportPath = null;
		}
		log.info("newReportPath:"+newReportPath);
		return (null == newReportPath ? null : newReportPath.toString() + "/" );
	}

	private String getCurrentDateFolder() {
		return LocalDate.now().format(DateTimeFormatter.ofPattern(CommonConstant.DDMMMYYYY_FORMAT));
	}

	private String createFileName(WsUserMstView wsUserMstView, ReportCommonOutDTO reportCommonOutDTO,
			String reportName) {
		return wsUserMstView.getName() + CommonConstant.UNDERSCORE + reportName + CommonConstant.UNDERSCORE
				+ reportCommonOutDTO.getReportGenerationId();
	}
	
	private String createFileNameForAWBGstInvoiceReport(String reportName, ReportCommonInDTO reportCommonInDTO)
			throws IOException {
		String fileName = reportName + CommonConstant.UNDERSCORE + reportCommonInDTO.getQueryParam().get("awbNumber");
		List<String> list = printManagerService.getFilesForFolder(ReportConstant.AWBINV_REPORT_FOLDER_NAME);
		Optional<String> fileSet = list.stream().filter(file -> file.startsWith(fileName)).findFirst();
		if (fileSet.isPresent()) {
			return fileName + CommonConstant.UNDERSCORE
					+ DateTimeFormatter.ofPattern(ReportConstant.AWBINV_REPORT_TIMESTAMP).format(LocalDateTime.now());
		}

		return fileName;
	}
	
	private String createFileNameForOneDeliveryEmployeeReport(String reportName, ReportCommonInDTO reportCommonInDTO,
			ReportCommonOutDTO reportCommonOutDTO) {
		return reportCommonInDTO.getQueryParam().get("EmployeeCodeTextbox") + CommonConstant.UNDERSCORE + reportName
				+ CommonConstant.UNDERSCORE + reportCommonOutDTO.getReportGenerationId();
	}
	
	private String createFileNameForServiceCentreDetailsReport(WsUserMstView wsUserMstView,
			ReportCommonInDTO reportCommonInDTO, ReportCommonOutDTO reportCommonOutDTO) {

		String reportName = "ServiceCentreDetailsList";
		String reportType = reportCommonInDTO.getQueryParam().containsKey("ReportTypePrinterRadioButton")
				&& reportCommonInDTO.getQueryParam().get("ReportTypePrinterRadioButton") != null
						? reportCommonInDTO.getQueryParam().get("ReportTypePrinterRadioButton").toString()
						: "";

		if (reportType.equals("ReportTypePrinterRadioButton")) {
			reportName = "ServiceCentreDetailsRegionwise";
		} else if (reportType.equals("SCDRegionWiseRadioButton")) {
			reportName = "ServiceCentreDetailsRegionwise";
		} else if (reportType.equals("SCDAllIndiaRadioButton")) {
			reportName = "ServiceCentreDetailsAllIndia";
		}

		return wsUserMstView.getName() + CommonConstant.UNDERSCORE + reportName + CommonConstant.UNDERSCORE
				+ reportCommonOutDTO.getReportGenerationId();
	}

	public Map<String, Object> getCorrectedQueryParams(Map<String, Object> queryParams) {
		Map<String, Object> filteredMap = new HashMap<>();
		for (Entry<String, Object> entry : queryParams.entrySet()) {
			if (entry.getValue() != null && !entry.getValue().toString().isEmpty())
				filteredMap.put(entry.getKey(), entry.getValue());
		}
		return filteredMap;
	}

	private OutputStream getNewReportFile(String filePath) {
		try {
			return filePath.startsWith(ReportConstant.CIFS_PREFIX) ? CIFSStorageUtils.createNewReportFile(filePath, storageDomain, storageUserName, storagePassword) : Files.newOutputStream(Paths.get(filePath).normalize());
		} catch (IOException e) {
			log.error("Error in getNewReportFile", e);
			return null;
		}
	}
	
	public BaseApiResponse saveFileForPrint(String template, String name, String fileName, String location)
			throws IOException {

		var baseApiResponse = new BaseApiResponse();
		String currentDate = getCurrentDateFolder();
		String folderPath = getReportFilePath(true, location, currentDate, false);
		if(null != folderPath) {
		String filePath = pathForEdpPrint(folderPath, fileName);
		log.info("<-------->" + filePath + "<-------------->");
		
			if (reportStorageLocation.startsWith(ReportConstant.CIFS_PREFIX)) {
				try (OutputStream fos = CIFSStorageUtils.createNewReportFile(filePath, storageDomain, storageUserName,
						storagePassword)) {
					fos.write(template.getBytes());
					log.info("File writing complete");
				} catch (IOException e) {
					log.error("Error File created for edp", e);
				}
			} else {
				Files.write(Paths.get(filePath).normalize(), template.getBytes());
			}
		}
		return baseApiResponse;
	}
	
	public static String pathForEdpPrint(String fileLocation, String fileName) {
		String filePath = "";
		if (fileLocation.startsWith(ReportConstant.CIFS_PREFIX)) {
			filePath = fileLocation + CommonConstant.SINGLE_FORWARD_SLASH + fileName;
		} else {
			filePath = fileLocation + File.separator + fileName;
		}
		return filePath;
	}
	
	@SuppressWarnings("unchecked")
	private void generateReportExcel(String reportName, String filePath,
			List<?> jasperInDTOList) {

		try (var streamOut = getNewReportFile(filePath);
				var streamWorkbook = new SXSSFWorkbook()) {

			SXSSFSheet sheet1 = CommonExcelExporter.createStreamSheet(streamWorkbook, reportName);

			Set<String> fieldNames = new HashSet<>();
			if (!CommonUtils.isNullOrBlankList(jasperInDTOList)) {
				fieldNames = ((List<LinkedHashMap<String, Object>>) (jasperInDTOList)).get(0).keySet();
			}

			List<String> fieldNamesList = new ArrayList<>();
			List<String> columnHeaderList = new ArrayList<>();
			fieldNames.forEach((String fileName)->{
				columnHeaderList.add(fileName.toUpperCase());
				fieldNamesList.add(fileName);
			});

			CommonExcelExporter.writeHeadersRow(sheet1, columnHeaderList);

			var rowCount1 = new AtomicInteger();
			rowCount1.incrementAndGet();
			
			for (LinkedHashMap<String, Object> row : (List<LinkedHashMap<String, Object>>) (jasperInDTOList)) {
				CommonExcelExporter.writeSingleRowToExcel(sheet1, rowCount1, fieldNamesList, row);
			}

			CommonExcelExporter.writeStreamWorkbookToExcel(streamOut, streamWorkbook);
			

		} catch (Exception e) {
			log.info("Exception", e);
		}

	}
}
