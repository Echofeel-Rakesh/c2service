package com.bluedart.cosmat.report.dto;

import java.util.List;

import com.bluedart.cosmat.commons.utils.BaseApiResponse;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Data
@EqualsAndHashCode(callSuper=false)
@Setter
@Getter
public class PrintPickupSheetResponse extends BaseApiResponse {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1274864008253276031L;
	@JsonProperty("d")
	private List<String> printerTypes;
	
}
