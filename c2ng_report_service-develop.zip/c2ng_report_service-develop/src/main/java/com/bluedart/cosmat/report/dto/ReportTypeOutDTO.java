package com.bluedart.cosmat.report.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.AllArgsConstructor;
import com.bluedart.cosmat.commons.utils.BaseModelMapper;

@Setter
@Getter
@AllArgsConstructor
public class ReportTypeOutDTO implements BaseModelMapper{
	Long id;
	Integer reportId;
	String name;
	String description;
	String caption;
	String uiType;
	Integer tabOrder;
	Integer grouping;
	String binding;
	String value;
	Integer row;
	Integer column;
	String dataType;
	String maskValue;
	Integer width;
} 

