package com.bluedart.cosmat.report.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Paths;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bluedart.cosmat.commons.auth.utils.CommonAuthUtils;
import com.bluedart.cosmat.commons.constants.CommonConstant;
import com.bluedart.cosmat.commons.exception.APIResponse;
import com.bluedart.cosmat.report.constant.ReportConstant;
import com.bluedart.cosmat.report.service.PrintManagerService;
import com.bluedart.cosmat.report.util.ReportConstants;
import com.bluedart.cosmat.report.util.ResponseUtils;
import com.bluedart.cosmat.report.util.StorageUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Validated
@RestController
public class PrintManagerController {
    @Autowired
    PrintManagerService printManagerService;
    
    @Autowired
    private CommonAuthUtils commonAuthUtils;
    
    @Value("${report.storage-location}")
    String reportStorageLocation;

    @Value("${report.report-temp-location}")
    String reportTempLocation;
    
	@Value("${report.html.header}")
	String htmlHeader;

	@Value("${report.html.footer}")
	String htmlFooter;
    
    @GetMapping("/print-manager/folders")
    public ResponseEntity<APIResponse<List<String>>> getAllFolders(@RequestParam(defaultValue = "false") boolean sort) {
        APIResponse<List<String>> response = new APIResponse<>();
		List<String> folders = null;
        try {
            folders = printManagerService.getFolders(sort);
        } catch (IOException e) {
            log.error("Error in getting folders", e);
        }
		
		if (null == folders || folders.isEmpty()) {
			response.setError(true);
			response.setMessage(CommonConstant.RECORDS_NOT_FOUND);
			response.setStatusCode(CommonConstant.NOT_FOUND_CODE);
		} else {
			response.setError(false);
			response.setData(folders);
		}
		return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/print-manager/files/{folderName}")
    public ResponseEntity<APIResponse<List<String>>> getFilesForFolder(@PathVariable("folderName") @NotBlank String folderName) {
        APIResponse<List<String>> response = new APIResponse<>();
		List<String> folders = null;
        try {
            folders = printManagerService.getFilesForFolder(folderName);
        } catch (IOException e) {
            log.error("Error in getting folders", e);
        }
		
		if (null == folders || folders.isEmpty()) {
			response.setError(true);
			response.setMessage(CommonConstant.RECORDS_NOT_FOUND);
			response.setStatusCode(CommonConstant.NOT_FOUND_CODE);
		} else {
			response.setError(false);
			response.setData(folders);
		}
		return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/download-report")
    public ResponseEntity<Resource> downloadFile(@RequestParam(value="file",required=false) String fileName,
    		@RequestParam(value ="folder",required=false) String folderName,
    		@RequestParam(value="loc",required=false) String loc,
    		@RequestParam(value="download",required=false) boolean isDownload,
    		HttpServletResponse httpServletResponse) throws IOException {
    	Resource fileResource = null;
    	try {
    		if(ReportConstants.FILETYPE_TEMP.equalsIgnoreCase(folderName)) {
				reportTempLocation = (reportTempLocation.startsWith(ReportConstant.CIFS_PREFIX) || Paths.get(reportTempLocation).normalize().isAbsolute()) ? reportTempLocation : Paths.get(reportStorageLocation , reportTempLocation).normalize().toString();
    			log.info("Download file called for report with path:"+reportTempLocation);
				fileResource = printManagerService.downloadFile( reportTempLocation, 
    					fileName);
    		}else {
    			fileResource = printManagerService.downloadFile(reportStorageLocation, 
    					loc!=null ? loc:commonAuthUtils.getUserDetails().getLocation(), 
    					folderName, 
    					fileName);
    		}
    	} catch (FileNotFoundException e) {
    		log.error("Error in downloading file", e);
    	}

    	if(null != fileResource && fileResource.exists() ) {
    		if(isDownload) {
    			HttpHeaders headers = new HttpHeaders();
    			headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
    			httpServletResponse.setHeader(CommonConstant.HEADERKEY_CONTENT_DISPOSITION, CommonConstant.HEADERVALUE_ATTACHMENT + fileName);
    			if(fileResource.isFile()) {
    				return ResponseEntity.ok().headers(headers)
        				.contentType(MediaType.parseMediaType(StorageUtils.getFileContentType(fileResource.getFilename())))
        				.body(fileResource);
				} else {
					try (OutputStream outputStream = httpServletResponse.getOutputStream();
					InputStream inputStream = fileResource.getInputStream(); ) {
						byte[] buff = new byte[2048];
						int length = 0;
						while ((length = inputStream.read(buff)) > 0) {
								outputStream.write(buff, 0, length);
								outputStream.flush();
						}
						httpServletResponse.setHeader("Cache-Control", "private");
						httpServletResponse.setDateHeader("Expires", 0);
						return null;
					}
				}
    		}else {
    			return ResponseUtils.generateHTMLForView(fileResource, htmlHeader, htmlFooter);
    		}    		
    	} else return ResponseEntity.notFound().build();
    }
}