package com.bluedart.cosmat.report.dto;

import java.io.Serializable;

import com.bluedart.cosmat.commons.utils.BaseModelMapper;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class LocationTypeDTO implements Serializable, BaseModelMapper {
	private static final long serialVersionUID = 1L;

	@JsonProperty("a")
	private String LocationCode;
	@JsonProperty("b")
	private String LocationName;
}
