package com.bluedart.cosmat.report.utility;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.bluedart.cosmat.report.constant.ReportConstant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CommonUtility {
	private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	private final DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
	private static final DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MMM-yy");

	/**
	 * Description: This method is validate the current date and previous date
	 * 
	 * @param value
	 * @return
	 */

	public static boolean validateCurrentDateFormate(String value) {
		boolean flag = true;
		String datePattern = "\\d{1,2}/\\d{1,2}/\\d{4}";
		boolean dateFormate = value.matches(datePattern);
		if (!dateFormate) {
			flag = false;
		}

		return flag;
	}

	/**
	 * Description: This method is used to validate registration date
	 * 
	 * @param value
	 * @return
	 */
	public static boolean validateDateForCurrentDate(String value) {
		boolean flag = false;
		try {
			LocalDateTime now = LocalDateTime.now();
			String date = formatter.format(now);
			LocalDate date1 = LocalDate.parse(date, formatter);
			String dateValue = value.replace("/", "-");
			LocalDate date2 = LocalDate.parse(dateValue, formatter);
			int a = date2.compareTo(date1);
			if (a <= 0) {
				flag = true;
			}
		} catch (Exception e) {
			throw new IllegalArgumentException(ReportConstant.INVALID_DATE_FORMAT);
		}
		return flag;
	}

}
