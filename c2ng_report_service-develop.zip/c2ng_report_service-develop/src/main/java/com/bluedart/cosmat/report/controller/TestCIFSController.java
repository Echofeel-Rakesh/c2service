package com.bluedart.cosmat.report.controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.Properties;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.mssmb2.SMB2Dialect;
import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.SmbConfig;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;

import jcifs.Address;
import jcifs.CIFSContext;
import jcifs.CIFSException;
import jcifs.DfsReferralData;
import jcifs.DfsResolver;
import jcifs.SmbResource;
import jcifs.SmbTransport;
import jcifs.config.PropertyConfiguration;
import jcifs.context.BaseContext;
import jcifs.smb.NtlmPasswordAuthenticator;
import jcifs.smb.SmbFile;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TestCIFSController {
    //private static Properties props = new Properties();
    //private static CIFSContext cachedContext = null;
    private String testUser = "pslyogeshwar";
    private String testDomain = "KUL-DC";
    @Value("${report.storage-location}")
    private String baseStoragePath;

    @GetMapping("/test/dfs-cifs-list")
    public ResponseEntity<String[]> testCifsList(@RequestParam(value="a",required=false) String userName,
    		@RequestParam(value ="b",required=false) String password,
    		@RequestParam(value="c",required=false) String domain,
    		@RequestParam(value="d",required=false) String basePath,
            @RequestParam(value="e",required=false) String relativePath,
    		HttpServletResponse httpServletResponse) throws IOException {
        
        if(null == domain || domain.isEmpty()) domain = testDomain;
        if(null == userName || userName.isEmpty()) userName = testUser;
        if(null == basePath || basePath.isEmpty()) basePath = baseStoragePath;
        if(null == relativePath || relativePath.isEmpty()) relativePath = "";
        log.info("domain:"+domain);
        log.info("userName:"+userName);
        log.info("basePath:"+basePath);
        log.info("relativePath:"+relativePath);
        
        CIFSContext cachedContext = getBaseContext(domain, userName, password);
        //CIFSContext context = cachedContext.withAnonymousCredentials();
        DfsResolver dfs = cachedContext.getDfs();
        
        try ( SmbTransport dc = dfs.getDc(cachedContext, domain) ) {
            if(null != dc) {
                Address addr = dc.getRemoteAddress();
                String remoteHostName = dc.getRemoteHostName();
                log.info("addr:"+addr);
                log.info("remoteHostName:"+remoteHostName);
            }
        } catch (Exception e) {
            log.error("Error in getDc",e);
        }

        CIFSContext contextWithCreds = cachedContext;
        contextWithCreds = cachedContext.withCredentials(new NtlmPasswordAuthenticator(domain, userName, password));
        DfsResolver dfs1 = contextWithCreds.getDfs();

        DfsReferralData ref = dfs1.resolve(contextWithCreds, domain, basePath, relativePath);
        if(null != ref) {
            log.info("DFS ref:"+ref.getLink());
        }

        try ( SmbFile res1 = new SmbFile(basePath, cachedContext) ) {
            SmbFile[] files = res1.listFiles();
            log.info("canRead:"+res1.canRead());
            log.info("canWrite:"+res1.canWrite());
            log.info("dfsPath:"+res1.getDfsPath());
            log.info("getServerWithDfs:"+res1.getServerWithDfs());
            log.info("files:"+Arrays.toString(files));
            
            SmbResource path = res1.resolve(relativePath);
            if (null != path) {
                log.info("relative path accessed:"+path.exists());
                if(path.isDirectory()) log.info("Relative path is a directory");
                if(path instanceof SmbFile) {
                    SmbFile pathFile = (SmbFile)path;
                    if(pathFile.isDirectory()) log.info("files:"+Arrays.toString(pathFile.list()));
                }
                return ResponseEntity.ok(res1.list());
            }
        } catch (Exception e) {
            log.error("Error in SmbFile 1",e);
        }
        return null;
    }

    @GetMapping("/test/dfs-cifs-smbj")
    public ResponseEntity<String[]> testCifsSmbj(@RequestParam(value="a",required=false) String userName,
    		@RequestParam(value ="b",required=false) String password,
    		@RequestParam(value="c",required=false) String domain,
    		@RequestParam(value="d",required=false) String serverName,
            @RequestParam(value="e",required=false) String sharePath,
            @RequestParam(value="f",required=false) String pathToResolve,
    		HttpServletResponse httpServletResponse) throws IOException {

        if(null == domain || domain.isEmpty()) domain = testDomain;
        if(null == userName || userName.isEmpty()) userName = testUser;
        if(null == serverName || serverName.isEmpty()) serverName = "kul-dc.dhl.com";
        if(null == sharePath || sharePath.isEmpty()) sharePath = "";
        if(null == pathToResolve || pathToResolve.isEmpty()) pathToResolve = "";
        log.info("domain:"+domain);
        log.info("userName:"+userName);
        log.info("serverName:"+serverName);
        log.info("sharePath:"+sharePath);
        log.info("pathToResolve:"+pathToResolve);

        
        SmbConfig config = SmbConfig.builder().withDfsEnabled(true).withDialects(SMB2Dialect.SMB_2_1).build();
        SMBClient client = new SMBClient(config);

        try (Connection connection = client.connect(serverName)) {
            AuthenticationContext ac = new AuthenticationContext(userName, password.toCharArray(), domain);
            Session session = connection.authenticate(ac);
    
            // Connect to Share
            try (DiskShare share = (DiskShare) session.connectShare(sharePath)) {
                for (FileIdBothDirectoryInformation f : share.list(pathToResolve)) {
                    log.info("File : " + f.getFileName());
                }
            }
        }
        return ResponseEntity.ok(null);
    }

    private CIFSContext  getBaseContext(String domain, String userName, String password) throws CIFSException {
        //if(cachedContext == null) {
            Properties props = new Properties();
            props.put("jcifs.resolveOrder", "BCAST,DNS");
            return new BaseContext(new PropertyConfiguration(props)).withCredentials(new NtlmPasswordAuthenticator(domain, userName, password));
        //}
        //return cachedContext;
    }

    private CIFSContext getBaseContextWithProps(String domain, String userName, String password, Properties props) throws CIFSException {
        return new BaseContext(new PropertyConfiguration(props)).withCredentials(new NtlmPasswordAuthenticator(domain, userName, password));
    }

}
