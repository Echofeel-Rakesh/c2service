package com.bluedart.cosmat.report.model;
import java.io.Serializable;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Component
@ConfigurationProperties(prefix = "report-config")
@JsonInclude(Include.NON_EMPTY)
@Data
public class ReportConfModel implements Serializable{

	private static final long serialVersionUID = 1L;
	private String authServiceAddress; 
	private Map<Long,ReportConfDetailsModel> reportMap;
}