package com.bluedart.cosmat.report.dto;

import java.io.Serializable;
import java.util.Map;

import lombok.Data;

@Data
public class DodFodComboBoxResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9043672206421033293L;
	
	private Map<String,String> dodFodType;

}
