package com.bluedart.cosmat.report.serviceimpl;

import java.text.SimpleDateFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bluedart.cosmat.report.constant.ReportConstant;
import com.bluedart.cosmat.report.model.MisReportsConfigResponse;
import com.bluedart.cosmat.report.repository.ReportConfigRepository;
import com.bluedart.cosmat.report.service.MisReportsService;
import com.bluedart.cosmat.report.view.MisReportsConfigView;

@Service
public class MisReportsServiceImpl implements MisReportsService {

	@Autowired
	ReportConfigRepository reportConfigRepository;
	
	@Override
	public MisReportsConfigResponse getMisReportDates(String reportName) {
		MisReportsConfigView view = reportConfigRepository.getMisReportsConfigDates(reportName);
		MisReportsConfigResponse response = null;
		if(view!=null) {
			response = new MisReportsConfigResponse();
			String endDate = new SimpleDateFormat(ReportConstant.STRING_DATE_FORMAT).format(view.getEndDate());
			response.setEndDate(endDate);
			String startDate = new SimpleDateFormat(ReportConstant.STRING_DATE_FORMAT).format(view.getStartDate());
			response.setStartDate(startDate);
		}
		return response;
	}

}
