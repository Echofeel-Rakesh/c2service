package com.bluedart.cosmat.report.service;

import com.bluedart.cosmat.report.model.MisReportsConfigResponse;

public interface MisReportsService {

	public MisReportsConfigResponse getMisReportDates(String reportName);
	
}
