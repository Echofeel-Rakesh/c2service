/**
 * 
 */
package com.bluedart.cosmat.report.dto;

import java.util.Map;

import lombok.Data;

/**
 * @author aditi_pramanik
 *
 */

@Data
public class ProductDropDownResponse {
	
	private Map<String,String> productDropDownType;

}
