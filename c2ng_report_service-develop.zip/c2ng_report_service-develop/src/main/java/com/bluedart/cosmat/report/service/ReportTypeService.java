package com.bluedart.cosmat.report.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.bluedart.cosmat.report.dto.LocationTypeDTO;
import com.bluedart.cosmat.report.dto.ReportParameterDTO;

public interface ReportTypeService {

	public List<ReportParameterDTO> findByReportId(Long l);

	public List<LocationTypeDTO> getLocationType(String reportName, HttpServletRequest request);

	Object getDodFodComboBox();

	Object getProductDropDown();

	Object getRunDestType();

	Object getStausComboBox();

	/*
	 * Specific POD/Status Report:- creditCardsDropDown
	 */
	Object getCreditCardsDropDown();

	/*
	 * Specific POD/Status Report:- priorityShipmentsComboBox
	 */
	Object getPriorityShipmentsComboBox();

	/*
	 * POD Report:- podTypeDropDown
	 */
	Object getPodTypeDropDown();

	/*
	 * POD/DC connected but No Image Report:- linkToDropDown
	 */
	Object getLinkToDropDown();

	/*
	 * Sub Product or Modewise AWB Report / Sub-Prod Details Report:-
	 * featureDropDown
	 */
	Object getFeatureDropDown();

	/*
	 * Sub Product or Modewise AWB Report / Sub-Prod Details Report:-
	 * labelSizeDropDown
	 */
	Object getLabelSizeDropDown();

	/*
	 * Generate STM Screen :- vehicleTrainTypeComboBox
	 */
	Object getVehicleTrainTypeComboBox();

	/*
	 * POD/DC Control Report :- reportForOneComboBox
	 */
	Object getReportForOneComboBox();

	/*
	 * POD/DC Control Report :- reportForTwoComboBox
	 */
	Object getReportForTwoComboBox();

	/*
	 * Not Connected(NEW) Report :- productComboBox
	 */
	Object getNotConnectedProductComboBox();
	
	/*
	 * AgentWise-Delivery Report :- AgentDropDown
	 */
	Object getReportForAgentDropDown();	
	
	/*
	 * AgentWise-Delivery Report :- ReportDropDown
	 */
	Object getReportDropDown();
	

     /*
	 * Delivery Vs POD Entry Time Report :- statusCodesDropDown
	 */
	Object getStatusCodesDropDown();
	
	
	/*
	 * DodFodUndeliveredShipmentReport :- select
	 */
	Object getReportDropDownselect();
	
	/*
	 * DodFodUndeliveredShipmentReport :- product
	 */
	Object getReportDropDownproduct();
	
	
	Object getSfcApexProductivity();
	
	Object getNotConnectedProductComboBoxA();
	
	Object getNotConnectedProductComboBoxS();
	
	Object getNotConnectedProductComboBoxD();

}
