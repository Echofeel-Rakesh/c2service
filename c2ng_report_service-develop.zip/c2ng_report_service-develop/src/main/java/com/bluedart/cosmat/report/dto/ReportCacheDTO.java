/**
 * 
 */
package com.bluedart.cosmat.report.dto;

import java.io.Serializable;

import com.bluedart.cosmat.commons.utils.BaseModelMapper;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * @author shivkumar_singh
 *
 */
@Data
public class ReportCacheDTO implements BaseModelMapper,Serializable{
	
private static final long serialVersionUID = 1L;
	
	@JsonProperty("a")
	private Long reportId;
	@JsonProperty("b")
	private String operation;
	@JsonProperty("c")
	private String format;
	@JsonProperty("d")
	private String userId;
	@JsonProperty("e")
	private String reportFile;
	@JsonProperty("f")
	private String folderName;
	@JsonProperty("g")
	private boolean onStatus;
	@JsonProperty("h")
	private String uUId;
	@JsonProperty("i")
	private boolean async;
	@JsonProperty("j")
	private String statusMessage;

}
