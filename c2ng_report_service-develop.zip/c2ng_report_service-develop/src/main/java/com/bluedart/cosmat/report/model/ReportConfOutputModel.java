package com.bluedart.cosmat.report.model;

import java.util.Map;

import lombok.Data;

@Data
public class ReportConfOutputModel {
	private String jrxmlTemplate;
	private Map<String,String> subReportTemplate;
}