package com.bluedart.cosmat.report.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(Include.NON_NULL) 
@Data
public class ReportCommonResponseDTO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@JsonProperty("a")
	private String reportFile;
	@JsonProperty("b")
	private String folderName;
	@JsonProperty("c")
	private String message;
	@JsonProperty("e")
	private String uUId;
	@JsonProperty("f")
	private boolean async;
	@JsonProperty("g")
	private boolean isDone;
	
}