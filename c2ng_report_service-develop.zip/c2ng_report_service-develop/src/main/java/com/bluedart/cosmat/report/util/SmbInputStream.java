package com.bluedart.cosmat.report.util;

import java.io.IOException;
import java.io.InputStream;

import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.share.File;

/**
 * This class represents a decorated input stream that respects the reference counting close mechanism of the file.
 */
public class SmbInputStream extends InputStream {

    /**
     * File that provides the input stream.
     */
    private final File file;

    /**
     * Input stream of the file that will be decorated.
     */
    private final InputStream inputStream;
    private final Connection connection;
    private final Session session;
    private final DiskShare diskShare;

    /**
     * Create a new decorated input stream that respects the reference counting close mechanism of the file.
     *
     * @param file File that will provide the input stream
     */
    public SmbInputStream(File file, Connection conn, Session sess, DiskShare share) {
        this.file = file;
        this.inputStream = file.getInputStream();
        this.connection = conn;
        this.session = sess;
        this.diskShare = share;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int read() throws IOException {
        return inputStream.read();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void close() throws IOException {
        inputStream.close();
        file.close();
        diskShare.close();
        session.close();
        connection.close();
    }
}
