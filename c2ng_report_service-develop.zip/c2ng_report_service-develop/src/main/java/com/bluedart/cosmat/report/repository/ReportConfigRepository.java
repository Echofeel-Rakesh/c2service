package com.bluedart.cosmat.report.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bluedart.cosmat.report.entity.ReportConfigEntity;
import com.bluedart.cosmat.report.view.MisReportsConfigView;

@Repository
public interface ReportConfigRepository extends JpaRepository<ReportConfigEntity, Long> {
	
	@Query("SELECT startDate as startDate, endDate as endDate FROM ReportConfigEntity WHERE reportName = ?1")
	MisReportsConfigView getMisReportsConfigDates(String reportName);

}
