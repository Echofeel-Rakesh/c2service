package com.bluedart.cosmat.report.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ViewprinterdetailsResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3917662332030035140L;
	
	@JsonProperty("a")
	private String printerType;
	
	@JsonProperty("b")
	private String mpsCodes;
	
	@JsonProperty("c")
	String singleCodes;
	
	@JsonProperty("d")
	String dualCodes;
	
	@JsonProperty("e")
	String tripleCodes;
	
	@JsonProperty("f")
	String singleCodes55_30;
	
	@JsonProperty("g")
	String codcodes;
	
	@JsonProperty("h")
	String smartTruckCodes;

}
