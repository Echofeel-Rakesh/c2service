package com.bluedart.cosmat.report.util;

public class ReportConstants {

	public static final String OK_CODE = "200";
	public static final String SUCCESS = "Success";
	public static final String CREATED_BY = "createdBy";
	public static final String USER_LOCATION = "LOGGEDIN_USERLOCATION";
	public static final String SUBREPORT_PARAM = "subReportParam";
	
	public static final String FILETYPE_TEMP = "temp";
	public static final String OPERATION_VIEW = "view";
	public static final String OPERATION_DOWNLOAD = "download";
	public static final String NO_RECORDS_TO_GENERATE_REPORT = "No records to generate report";
	
	public static final String USER_ID = "USER_ID";
	
	public static final String APPLICATION_VERSION = "Version";
	public static final String EMPLOYEE_NAME = "employeeName";
}
