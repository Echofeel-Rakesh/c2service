package com.bluedart.cosmat.report.service.remoteimpl;

import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.bluedart.cosmat.commons.config.RequestBean;
import com.bluedart.cosmat.commons.constants.CommonConstant;
import com.bluedart.cosmat.commons.exception.APIResponse;
import com.bluedart.cosmat.report.constant.ReportConstant;
import com.bluedart.cosmat.report.model.ValidateServiceCenterResponse;

@Service
public class LocationService {
	@Value("${Service.locationserviceurl}")
	private String locationServiceUrl;
	
	public String getLocationBaseUrl() {
		return locationServiceUrl;
	}
	
	@Autowired
	private RequestBean requestBean;

	/**
	 * Description: This method is used to get area details by service center
	 * 
	 * @param serviceCenter
	 * @param httpServletRequest
	 * @return
	 */

	public String getAreadetail(String serviceCenter, HttpServletRequest httpServletRequest) {
		return WebClient.builder().baseUrl(ReportConstant.LOCATION_SERVICE_URL).build().get()
				.uri(ReportConstant.AREA_DETAIL_URI, serviceCenter)
				.header(CommonConstant.AUTHORIZATION_CONST,
						httpServletRequest.getHeader(CommonConstant.AUTHORIZATION_CONST))
				.retrieve().bodyToMono(String.class).block();

	}
	
	/**
	 * Description: This method is used to validate service center
	 * 
	 * @param area
	 * @param serviceCenter
	 * @param httpServletRequest
	 * @return
	 */
	public ValidateServiceCenterResponse isvalidateservicecenter(String area, String serviceCenter,
			HttpServletRequest httpServletRequest) {
		return WebClient.builder().baseUrl(ReportConstant.LOCATION_SERVICE_URL).build().get()
				.uri(ReportConstant.IS_VALIDATE_SERVICECENTER_URI, area, serviceCenter)
				.header(CommonConstant.AUTHORIZATION_CONST,
						httpServletRequest.getHeader(CommonConstant.AUTHORIZATION_CONST))
				.retrieve().bodyToMono(ValidateServiceCenterResponse.class).block();

	}
	
	/**This Method is to get multiple service centers by resource name
	 * @param httpRequest
	 * @param resourceName
	 * @return
	 */
	public APIResponse<Set<String>> getSecondaryServiceCenters(String resourceName) {
		return WebClient.builder().baseUrl(ReportConstant.LOCATION_SERVICE_URL).build()
				.get()
				.uri(uriBuilder->uriBuilder.path(ReportConstant.GET_MULTIPLE_SERVICE_CENTERS_URL).build(resourceName))
				.header(CommonConstant.AUTHORIZATION_CONST, requestBean.getJwtToken())
				.retrieve()
				.bodyToMono(new ParameterizedTypeReference<APIResponse<Set<String>>>() {})
				.block();
	}
}
