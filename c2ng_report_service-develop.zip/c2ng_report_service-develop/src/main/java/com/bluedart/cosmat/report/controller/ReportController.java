package com.bluedart.cosmat.report.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bluedart.cosmat.commons.constants.CommonConstant;
import com.bluedart.cosmat.commons.exception.APIResponse;
import com.bluedart.cosmat.commons.utils.SecurityManagerUtils;
import com.bluedart.cosmat.report.config.YAMLConfig;
import com.bluedart.cosmat.report.dto.LocationTypeDTO;
import com.bluedart.cosmat.report.dto.LocationTypeResponse;
import com.bluedart.cosmat.report.dto.ReportParameterDTO;
import com.bluedart.cosmat.report.model.ReportConfDetailsModel;
import com.bluedart.cosmat.report.model.ReportConfModel;
import com.bluedart.cosmat.report.service.ReportTypeService;
import com.bluedart.cosmat.report.util.ReportConstants;

@RestController
public class ReportController {
	@Autowired
	ReportTypeService reportService;

	@Autowired
	YAMLConfig yamlConfig;

	@Autowired
	SecurityManagerUtils scManagerUtils;
	
	@Autowired
	private ReportConfModel reportConfModel;

	@GetMapping("/report-parameter/{id}")
	public ResponseEntity<APIResponse<List<ReportParameterDTO>>> getReportType(@Valid @PathVariable("id") Long reportId) {

		APIResponse<List<ReportParameterDTO>> response = new APIResponse<>();
		var reportConfDetailsModel = new ReportConfDetailsModel();
		
		List<ReportParameterDTO> resultData = reportService.findByReportId(reportId);
		if(reportConfModel != null)
		    reportConfDetailsModel = reportConfModel.getReportMap().get(reportId);
		if(reportConfDetailsModel != null && reportConfModel != null) {
			resultData.get(0).setAsync(reportConfDetailsModel.isAsync());
		}		
		if (resultData.isEmpty()) {
			response.setError(true);
			response.setStatusCode(CommonConstant.NOT_FOUND_CODE);
		} else {
			response.setError(false);
			response.setData(resultData);
		}

		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	@GetMapping("/locationtype")
	public ResponseEntity<LocationTypeResponse> getLocationType(@RequestParam("a") String reportName,
			HttpServletRequest request) {
		LocationTypeResponse response = new LocationTypeResponse();
		List<LocationTypeDTO> locationType = reportService.getLocationType(reportName, request);
		response.setLocationTypes(locationType);
		response.setError(false);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@GetMapping("/dodFodComboBox")
	public APIResponse<Object> getDodFodComboBox() {

		Object dodFodType = reportService.getDodFodComboBox();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, dodFodType);
	}

	@GetMapping("/productDropDown")
	public APIResponse<Object> getProductDropDown() {

		Object productDropDown = reportService.getProductDropDown();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, productDropDown);
	}

	@GetMapping("/rundesttype")
	public APIResponse<Object> getRunDestType() {

		Object runDestType = reportService.getRunDestType();
		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, runDestType);

	}

	@GetMapping("/statuscombobox")
	public APIResponse<Object> getStausComboBox() {

		Object statusComboBox = reportService.getStausComboBox();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, statusComboBox);
	}

	/*
	 * Specific POD/Status Report:- creditCardsDropDown
	 */
	@GetMapping("/creditcardsdropdown")
	public APIResponse<Object> getCreditCardsDropDown() {

		Object creditCardsDropDown = reportService.getCreditCardsDropDown();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, creditCardsDropDown);
	}

	/*
	 * Specific POD/Status Report:- priorityShipmentsComboBox
	 */

	@GetMapping("/priorityshipmentscombobox")
	public APIResponse<Object> getPriorityShipmentsComboBox() {

		Object priorityShipmentsComboBox = reportService.getPriorityShipmentsComboBox();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, priorityShipmentsComboBox);
	}

	/*
	 * POD Report:- podTypeDropDown
	 */

	@GetMapping("/podtypedropdown")
	public APIResponse<Object> getPodTypeDropDown() {

		Object podTypeDropDown = reportService.getPodTypeDropDown();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, podTypeDropDown);
	}

	/*
	 * POD/DC connected but No Image Report:- linkToDropDown
	 */

	@GetMapping("/linktodropdown")
	public APIResponse<Object> getLinkToDropDown() {

		Object linkToDropDown = reportService.getLinkToDropDown();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, linkToDropDown);
	}

	/*
	 * Sub Product or Modewise AWB Report / Sub-Prod Details Report:-
	 * featureDropDown
	 */

	@GetMapping("/featuredropdown")
	public APIResponse<Object> getFeatureDropDown() {

		Object featureDropDown = reportService.getFeatureDropDown();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, featureDropDown);
	}

	/*
	 * Sub Product or Modewise AWB Report / Sub-Prod Details Report:-
	 * labelSizeDropDown
	 */

	@GetMapping("/labelsizedropdown")
	public APIResponse<Object> getLabelSizeDropDown() {

		Object labelSizeDropDown = reportService.getLabelSizeDropDown();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, labelSizeDropDown);
	}

	/*
	 * Generate STM Screen :- vehicleTrainTypeComboBox
	 */

	@GetMapping("/vehicletraintypecombobox")
	public APIResponse<Object> getVehicleTrainTypeComboBox() {

		Object vehicleTrainTypeComboBox = reportService.getVehicleTrainTypeComboBox();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, vehicleTrainTypeComboBox);
	}

	/*
	 * POD/DC Control Report :- reportForOneComboBox
	 */

	@GetMapping("/reportforonecombobox")
	public APIResponse<Object> getReportForOneComboBox() {

		Object reportForOneComboBox = reportService.getReportForOneComboBox();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, reportForOneComboBox);
	}

	/*
	 * POD/DC Control Report :- reportForTwoComboBox
	 */

	@GetMapping("/reportfortwocombobox")
	public APIResponse<Object> getReportForTwoComboBox() {

		Object reportForTwoComboBox = reportService.getReportForTwoComboBox();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, reportForTwoComboBox);
	}
	
	/*
	 * Not Connected(NEW) Report :- productComboBox
	 */

	@GetMapping("/notconnectedproductcombobox")
	public APIResponse<Object> getNotConnectedProductComboBox() {

		Object productComboBox = reportService.getNotConnectedProductComboBox();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, productComboBox);
	}
	
	/*
	 * AgentWise-Delivery Report :- AgentDropDown
	 */
	@GetMapping("/agentdropdown")
	public APIResponse<Object> getAgentDropDown() {

		Object reportForTwoComboBox = reportService.getReportForAgentDropDown();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, reportForTwoComboBox);
	}

	/*
	 * AgentWise-Delivery Report :- ReportDrpodown
	 */
	@GetMapping("/agentforreportdropdown")
	public APIResponse<Object> getReportDrpodown() {

		Object reportForTwoComboBox = reportService.getReportDropDown();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, reportForTwoComboBox);
	}
	

	/*
	 * Delivery Vs POD Entry Time Report :- statusCodesDropDown
	 */
	@GetMapping("/statuscodesdropdown")
	public APIResponse<Object> getStatusCodesDropDown() {

		Object statusCodesDropDown = reportService.getStatusCodesDropDown();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, statusCodesDropDown);
	}
	
	/*
	 * DodFodUndeliveredShipmentReport :- ReportDrpodown
	 */
	@GetMapping("/select")
	public APIResponse<Object> getReportDrpodownselect() {

		Object reportForTwoComboBox = reportService.getReportDropDownselect();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, reportForTwoComboBox);
	}
	
	
	/*
	 * DodFodUndeliveredShipmentReport :- ReportDrpodown
	 */
	@GetMapping("/product")
	public APIResponse<Object> getReportDrpodownproduct() {

		Object reportForTwoComboBox = reportService.getReportDropDownproduct();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, reportForTwoComboBox);
	}
	
	@GetMapping("/sfcApexProductivity")
	public APIResponse<Object> getSfcApexProductivity() {

		Object reportForTwoComboBox = reportService.getSfcApexProductivity();

		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, reportForTwoComboBox);
	}
	
	@GetMapping("/notconnectedsubproductcombobox")
	public APIResponse<Object> getNotConnectedSubProductComboBox(@RequestParam("a") String a) {
		Object productComboBox=new Object();
		if(a.equals("A"))
		{
			 productComboBox = reportService.getNotConnectedProductComboBoxA();
		}
		else if(a.equals("S"))
		{
			 productComboBox = reportService.getNotConnectedProductComboBoxS();
		}
		else if(a.equals("D"))
		{
			productComboBox=reportService.getNotConnectedProductComboBoxD();
		}
		
		return new APIResponse<>(false, ReportConstants.OK_CODE, ReportConstants.SUCCESS, productComboBox);
	}
}
