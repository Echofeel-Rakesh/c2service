package com.bluedart.cosmat.report.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LocationTypeResponse {
	@JsonProperty("data")
	private List<LocationTypeDTO> locationTypes;

	@JsonProperty("error")
	private boolean error;
}
