package com.bluedart.cosmat.report;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.bluedart")
public class ReportServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReportServicesApplication.class, args);
	}

}
