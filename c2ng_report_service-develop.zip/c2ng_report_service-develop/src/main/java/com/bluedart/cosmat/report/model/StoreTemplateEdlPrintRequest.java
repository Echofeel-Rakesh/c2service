package com.bluedart.cosmat.report.model;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class StoreTemplateEdlPrintRequest implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3044089983815425018L;
	
	@NotBlank
	@JsonProperty("a")
	private String templateContent;
	
	@NotBlank
	@JsonProperty("b")
	private String fileName;

}
