package com.bluedart.cosmat.report.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "THERMALPRINTER", schema = "BDDATA")
public class ThermalPrinterEntity {
	
	@Id
	@Column(name="CPRINTERTYPE")
	private String printerType;
	@Column(name="CMPSCODES")
	private String mpsCodes;
	@Column(name="CSINGLECODES")
	private String singleCodes;
	@Column(name="CDUALCODES")
	private String dualCodes;
	@Column(name="CTRIPLECODES")
	private String tripleCodes;
	@Column(name="CSINGLECODES55_30")
	private String singleCodes55_30;
	@Column(name="CCODCODES")
	private String codcodes;
	@Column(name="CSMARTTRUCKCODES")
	private String smartTruckCodes;

}