package com.bluedart.cosmat.report.service;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

import javax.validation.Valid;

import org.springframework.cache.Cache;

import com.bluedart.cosmat.commons.auth.utils.User;
import com.bluedart.cosmat.commons.exception.APICustomException;
import com.bluedart.cosmat.commons.exception.APIResponse;
import com.bluedart.cosmat.report.dto.ReportCacheDTO;
import com.bluedart.cosmat.report.dto.ReportCommonInDTO;
import com.bluedart.cosmat.report.dto.ReportCommonOutDTO;
import com.bluedart.cosmat.report.dto.ReportCommonResponseDTO;
import com.bluedart.cosmat.report.model.ReportConfDetailsModel;
import com.bluedart.cosmat.report.model.ReportConfModel;

import net.sf.jasperreports.engine.JRException;

public interface ReportCommonService {

	ReportCommonOutDTO generateReport(@Valid ReportCommonInDTO reportCommonInDTO, String httpServletRequest,ReportConfModel reportConfModel) throws APICustomException;

	APIResponse<ReportCommonResponseDTO> generateReportForAsynch(@Valid ReportCommonInDTO reportCommonInDTO,
			String httpServletRequest, ReportConfModel reportConfModel, Cache reportCache, ReportCacheDTO cacheDto,
			User user, ReportConfDetailsModel reportConfDetailsModel)
			throws APICustomException,IOException, JRException, InterruptedException, ExecutionException;

	void getXlsxCommonData(ReportCommonOutDTO reportCommonOutDTO, ReportCommonInDTO reportCommonInDTO);

	APIResponse<ReportCommonResponseDTO> reportFileGeneration(@Valid ReportCommonInDTO reportCommonInDTO,
			ReportCommonOutDTO reportCommonOutDTO, ReportConfModel reportConfModel, ReportCacheDTO cacheDto, User user,
			ReportConfDetailsModel reportConfDetailsModel,Cache reportCache) throws JRException, IOException;

}
