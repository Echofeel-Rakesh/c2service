package com.bluedart.cosmat.report.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@Configuration
@EnableConfigurationProperties
@ConfigurationProperties
@Getter
@Setter
public class YAMLConfig {
	Map<String, String> LocationType = new HashMap<>();

	private List<Map<String, String>> dodFodComboBox;

	private List<Map<String, String>> productDropDown;

	private List<Map<String, String>> runDestType;

	private List<Map<String, String>> statusComboBox;

	/*
	 * Specific POD/Status Report:- creditCardsDropDown,priorityShipmentsComboBox
	 */
	private List<Map<String, String>> creditCardsDropDown;
	private List<Map<String, String>> priorityShipmentsComboBox;

	/*
	 * POD Report:- podTypeDropDown
	 */
	private List<Map<String, String>> podTypeDropDown;

	/*
	 * POD/DC connected but No Image Report:- linkToDropDown
	 */
	private List<Map<String, String>> linkToDropDown;

	/*
	 * Sub Product or Modewise AWB Report / Sub-Prod Details Report:-
	 * featureDropDown,labelSizeDropDown
	 */
	private List<Map<String, String>> featureDropDown;
	private List<Map<String, String>> labelSizeDropDown;
	
	/*
	 * Generate STM Screen :- vehicleTrainTypeComboBox
	 */
	private List<Map<String, String>> vehicleTrainTypeComboBox;
	
	/*
	 * POD/DC Control Report :- reportForOneComboBox,reportForTwoComboBox
	 */
	private List<Map<String, String>> reportForOneComboBox;
	private List<Map<String, String>> reportForTwoComboBox;
	
	/*
	 * Not Connected(NEW) Report :- productComboBox
	 */
	private List<Map<String, String>> notConnectedProductComboBox;
	
	/*
	 * AgentWise-Delivery Report :- AgentDropDown
	 */
	private List<Map<String, String>> reportAgentComboBox;

	/*
	 * AgentWise-Delivery Report :- ReportDrpodown
	 */
	private List<Map<String, String>> reportForComboBox;
	
     /*
	 * Delivery Vs POD Entry Time Report :- statusCodesDropDown
	 */
	private List<Map<String, String>> statusCodesDropDown;
	
	/*
	 * DodFodUndeliveredShipmentReport :- reportForOneComboBox,reportForTwoComboBox
	 */
	private List<Map<String, String>> reportForComboBoxselect;
	
	/*
	 * DodFodUndeliveredShipmentReport :- reportForOneComboBox,reportForTwoComboBox
	 */
	private List<Map<String, String>> reportForComboBoxproduct;
	
	
	private List<Map<String, String>> sfcApexProductivity;
	
	private List<Map<String, String>> notConnectedProductComboBoxA;
	
	private List<Map<String, String>> notConnectedProductComboBoxS;
	
	private List<Map<String, String>> notConnectedProductComboBoxD;

}
