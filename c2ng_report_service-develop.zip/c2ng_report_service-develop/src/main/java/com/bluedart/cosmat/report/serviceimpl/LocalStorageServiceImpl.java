package com.bluedart.cosmat.report.serviceimpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.bluedart.cosmat.report.service.StorageService;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class LocalStorageServiceImpl implements StorageService {
    @Value("${report.storage-location}")
    String storageLocation;

    @Override
    public List<String> getUserFolders(String userLocation, boolean sortDesc) {
        File dir = Paths.get(storageLocation, userLocation).normalize().toFile();
        File[] files = dir.listFiles();
        
        Arrays.sort(files, sortDesc ? LastModifiedFileComparator.LASTMODIFIED_COMPARATOR : LastModifiedFileComparator.LASTMODIFIED_REVERSE);
        return Arrays.stream(files).filter(p -> !p.isFile()).map(File::getName).collect(Collectors.toList());
    }

    @Override
    public List<String> getUserFilesByFolder(String userLocation, String folderName, boolean sortDesc) throws IOException {
        Path dir = Paths.get(storageLocation, userLocation, folderName).normalize();
        if (Files.exists(dir)) {
            try (Stream<Path> stream = Files.list(dir)) {
                return stream
                .filter(Files::isRegularFile)
                .sorted((p1, p2)-> Long.compare(p2.toFile().lastModified(), p1.toFile().lastModified()))
                .map(Path::getFileName)
                .map(Path::toString)
                .collect(Collectors.toList());
            }
        } else return Collections.emptyList();
    }

    @Override
    public InputStream loadFileAsStream(String userLocation, String folderName, String fileName) throws FileNotFoundException {
        Path filePath = Paths.get(storageLocation, userLocation, folderName, fileName).normalize();
        return new FileInputStream(filePath.toFile());
    }

    @Override
    public OutputStream getNewReportStreamForWrite(String folderName, String fileName) {
        try {
            return Files.newOutputStream(Paths.get(folderName, fileName).normalize());
        } catch (IOException e) {
            log.error("Error while create new report file for writing", e);
            return null;
        }
    }
}
