package com.bluedart.cosmat.report.constant;

public class ReportConstant {
	
	private ReportConstant() {
	    throw new IllegalStateException("Utility class");
	  }

	public static final String INVALID_SERVICE_CENTER_CODE_MESSAGE = "Invalid service center code";
	public static final String INVALID_PICKUP_DATE_FORMAT = "Invalid Pickup date";
	public static final String INVALID_PICKUP_DATE ="('*' indicates mandatory filed) Pickup Date cannot be blank";
	public static final String DATE_GREATER_CURRENT_DATE = "Pickup date cannot be greater then today's date.";
	public static final String SELECT_OPTION = "Please select option Missed, Delayed or Both";
	public static final String  INVALID_OPTION_SELECTED = "Invalid option selected";
	public static final String  INVALID_EXCLUDE_OPTION = "Exclude option value is invalid expecting either 'Y' or 'N'";
	public static final String NO_PRINTER_TYPE_FOUND = "No printer type found";
	public static final String PICKUP_SERVICE_URL = "http://pickup-service:8090";
	public static final String REPORT_DETAILS_URI="/report/missdetailreport?a={date}&b={serviceCenter}&c={isRegionOrServiceCenter}&d={selectedOption}&e={exclude}";
	public static final String LOCATION_SERVICE_URL = "http://location-service:8085";
	public static final String AREA_DETAIL_URI = "/location/areadetail/{srccd}";
	public static final String IS_VALIDATE_SERVICECENTER_URI = "/location/isvalidateservicecenter?a={routecode}&b={srccd}";
	public static final String OPTION_TWO="2";
	public static final String INVALID_DATE_FORMAT = "Invalid Date format";
	public static final String ERRORCODE_0 = "0";
	public static final String PARALLEL_REQUEST_NOT_ALLOWED = "Max 1 Report can be generated in parallel. Please wait till earlier requests are completed";

	public static final String LOCATION_CODE_A="A";
	public static final String LOCATION_CODE_S="S";
	public static final String LOCATION_CODE_R="R";
	public static final String LOCATION_CODE_I="I";
	public static final String LOCATION_NAME_I="I - AIN";
	public static final String LOCATION_NAME_R="R - Region";
	public static final String LOCATION_NAME_S="S - Service Centre";
	public static final String LOCATION_NAME_A="A - Area";

	public static final String GET_MULTIPLE_SERVICE_CENTERS_URL = "/location/servicecenters/{resourceName}";
	
	public static final String SECURITY_REPORT= "SecurityException";
	public static final String EXCLUDE_KEYS ="optionFormula,fromDate,toDate";
	public static final String EXCLUDE_INTERNAL_KEYS="fromDate,toDate,excelDstatDate";
	public static final String DATE_FORMAT="excelDstatDate";
	public static final String DATE_FORMAT_DSTAT="dstatDate";
	public static final String GET_KEY ="accDetails";

	public static final String CIFS_PREFIX = "smb://";

	public static final String SHORTKEY_F = "F";
	public static final String NON_PRIORITY_SHIPMENTS = "Non-Priority Shipments";
	public static final String SHORTKEY_T = "T";
	public static final String HIGH_PRIORITY_SHIPMENTS = "High Priority Shipments";
	public static final String SHORTKEY_1 = "1";
	public static final String ONLY_DOXS = "Only Doxs";
	public static final String ONLY_DUTS = "Only Duts";
	public static final String SHORTKEY_2 = "2";
	public static final String SHORTKEY_I = "I";
	public static final String SHORTKEY_E = "E";
	public static final String virtualizer = "gZip";
	
	public static final String REPORT_TIMESTAMP = "MMddHHmmss";
	public static final String DST_STOCK = "bayslaw";
	
	public static final String STRING_DATE_FORMAT = "dd/MM/yyyy";
	
	public static final Long AWBINV_REPORT_ID = 721l;
	public static final String AWBINV_REPORT_FOLDER_NAME = "AWB_Invoice_Print";
	public static final String AWBINV_REPORT_TIMESTAMP = "yyyyMMdd_hhmmss";

	public static final Long ONE_DELIVERY_EMPLOYEE_REPORT_ID = 101l;
	public static final Long SERVICE_CENTRE_DETAILS_REPORT_ID = 13l;
	
}
