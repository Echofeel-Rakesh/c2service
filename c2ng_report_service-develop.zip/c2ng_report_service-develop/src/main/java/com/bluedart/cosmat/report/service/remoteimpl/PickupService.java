package com.bluedart.cosmat.report.service.remoteimpl;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;

import com.bluedart.cosmat.commons.constants.CommonConstant;
import com.bluedart.cosmat.commons.exception.APIResponse;
import com.bluedart.cosmat.report.dto.ReportCommonInDTO;
import com.bluedart.cosmat.report.model.ReportConfDetailsModel;

import reactor.core.publisher.Mono;


@Service
public class PickupService {
	
	@Value("${webclient.memory-size}")
	private Integer memorySize;
	
	public APIResponse<List<?>> getReport(ReportCommonInDTO reportCommonInDTO, ReportConfDetailsModel reportConfDetailsModel, 
			String request) {

		MultiValueMap<String, String> queryParams =new LinkedMultiValueMap<>();
		for (Entry<String, Object> entry : reportCommonInDTO.getQueryParam().entrySet()) {
			queryParams.add(entry.getKey() ,entry.getValue().toString());
		}

		return
				WebClient.builder().exchangeStrategies(ExchangeStrategies.builder()
				        .codecs(clientCodecConfigurer -> clientCodecConfigurer
				                .defaultCodecs()
				                .maxInMemorySize(memorySize)
				        )
				        .build()).baseUrl(reportConfDetailsModel.getWebclient().getServiceUrl()).build()
				.get()
				.uri(uriBuilder->uriBuilder
						.path(reportConfDetailsModel.getWebclient().getPath())
						.queryParams(queryParams)
						.build())
				.header(CommonConstant.AUTHORIZATION_CONST, request)
				.retrieve()
				.onStatus(HttpStatus::isError, response -> Mono.empty())
				.bodyToMono(new ParameterizedTypeReference<APIResponse<List<?>>>() {})
				.block();
	}
	
	public APIResponse<List<?>> getPostReport(ReportCommonInDTO reportCommonInDTO, ReportConfDetailsModel reportConfDetailsModel, 
			String request) {
		Map<String, Object> queryParams =new HashMap<>();
		for (Entry<String, Object> entry : reportCommonInDTO.getQueryParam().entrySet()) {
			queryParams.put(entry.getKey() ,entry.getValue());
		}
		
		
		return
				WebClient.builder().exchangeStrategies(ExchangeStrategies.builder()
				        .codecs(clientCodecConfigurer -> clientCodecConfigurer
				                .defaultCodecs()
				                .maxInMemorySize(memorySize)
				        )
				        .build()).baseUrl(reportConfDetailsModel.getWebclient().getServiceUrl()).build()
				.post()
				.uri(reportConfDetailsModel.getWebclient().getPath())
				.contentType(MediaType.APPLICATION_JSON)
				.header(CommonConstant.AUTHORIZATION_CONST, request)
				.body(Mono.just(queryParams),Map.class)
				.retrieve()
				.onStatus(HttpStatus::isError, response -> Mono.empty())
				.bodyToMono(new ParameterizedTypeReference<APIResponse<List<?>>>() {})
				.block();
	}
}
