package com.bluedart.cosmat.report.model;

public class PrintManagerFolderReponse {

}
