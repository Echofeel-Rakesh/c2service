package com.bluedart.cosmat.report.model;

import lombok.Data;

@Data
public class ReportConfDetailsModel {

	private String reportName;
	private ReportConfOutputModel output;
	private ReportConfWebClientModel webclient;
	private boolean jasperExcel;
	private boolean async;
}