package com.bluedart.cosmat.report.dto;



import java.io.Serializable;

import com.bluedart.cosmat.commons.utils.BaseModelMapper;

import lombok.Getter;
import lombok.Setter;
@SuppressWarnings("serial")
@Setter
@Getter
public class PrintPickupExceptionDto implements Serializable,BaseModelMapper{
	
private String dlvPuRtCd;

private String puDate;

private String carea;

private String scrcd;
	
private String tokenNo;

private String custCode;

private String custName;

private String cemplcode;
	
private String custTel;
	
private String contact;

private String mobileNo;
	
private String puTime;
	
private String cregtime;

private String prodCode;

private String remarks;

private String weight;

private String cid;

private String statType;

private String statCode;

private String crem;

private String rawbNo;

private String routName;

private String statDesc;

private String cemplname;

private String exception;
}
