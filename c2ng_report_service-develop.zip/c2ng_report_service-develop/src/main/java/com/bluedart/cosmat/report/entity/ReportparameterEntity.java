package com.bluedart.cosmat.report.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonRawValue;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "REPORTPARAMETER", schema = "BDDATA")
public class ReportparameterEntity {
	@Id
	@Column(name="PARAMETERID")
	Long id;
	
	@Column(name="REPORTTYPEID")
	Integer reportId;
	
	@Column(name="PARAMETERNAME")
	String name;
	
	@Column(name="PARAMETERDESCRIPTION")
	String description;
	
	@Column(name="CAPTION") 
	String caption;
     
	@Column(name="PARAMETERUITYPE")
	String uiType;
	
	@Column(name="TABORDER") 
	Integer tabOrder;
	
	@Column(name="GROUPING") 
	Integer grouping;
	
	@Column(name="BINDING") 
	String binding;
	
	@Column(name="PARAMETERVALUE") 
	String value;
	
	@Column(name="PARAMETERROW") 
	Integer row;
	
	@Column(name="PARAMETERCOLUMN") 
	Integer column;
	
	@Column(name="PARAMETERDATATYPE") 
	String dataType;
	
	@Column(name="MASKVALUE") 
	String maskValue;
	
	@Column(name="WIDTH") 
	Integer width;
	
	@Column(name="URIMAPPING") 
	String uri;
	
	@Column(name="ISREQUIRED") 
	String isRequired;
	
	@Column(name="COMBOURIPARAM") 
	@JsonRawValue
	String comboUriParam;
	
	@Column(name="MINLENTH") 
	Integer minLength;
	
	@Column(name="MAXLENTH") 
	Integer maxLength;
	
	@Column(name="DEFAULTVALUE") 
	String defaultValue;
	
	@Column(name="HELPICONCONFIG") 
	@Lob
	@JsonRawValue
	String helpIconConfig;
	
	@Column(name="ISAUTOCAPS") 
	String isautocaps;
	
	
}
