package com.bluedart.cosmat.report.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ReportCommonInDTO implements Serializable{

	private static final long serialVersionUID = 1L;
	@JsonProperty("a")
	private Long reportId;
	@JsonProperty("b")
	private String operation;
	@JsonProperty("c")
	private String format;
	@JsonProperty("d")
	private boolean saveReport;
	@JsonProperty("e")
	private Map<String, Object> queryParam;
	
	@JsonProperty("p")
	private ReportParameterInDTO parameterInDTO; 
	
	// This property has been introduced for those reports that get called from another service, instead of getting called from the UI. 
	// The data will be set in this optional parameter and report will be generated directly, report service will not call any other service for data. 
	@JsonProperty(value ="q", required = false )
	private List<?> reportData;
		
}