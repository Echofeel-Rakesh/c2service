package com.bluedart.cosmat.report.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bluedart.cosmat.report.constant.ReportConstant;
import com.bluedart.cosmat.report.dto.PrintPickupSheetResponse;
import com.bluedart.cosmat.report.service.PrintPickupSheetService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Validated
@RestController
@RequestMapping("/pickupreports")
public class PrintPickupSheetController {

    @Autowired
    PrintPickupSheetService printPickupSheetService;
      
    @GetMapping("/print-pickupsheet")
    public ResponseEntity<PrintPickupSheetResponse> getPrinterType() {
        PrintPickupSheetResponse response=new PrintPickupSheetResponse();
		List<String> printerTypes =  printPickupSheetService.getPrinterType();
		if (null == printerTypes || printerTypes.isEmpty()) {
			response.setError(true);
			response.setErrorCode(ReportConstant.NO_PRINTER_TYPE_FOUND);
		} else {
			response.setError(false);
			response.setPrinterTypes(printerTypes);
		}
		return new ResponseEntity<>(response, HttpStatus.OK);
    }  

}