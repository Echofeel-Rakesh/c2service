package com.bluedart.cosmat.report.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.activation.MimetypesFileTypeMap;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;

import com.bluedart.cosmat.commons.constants.CommonConstant;

public class StorageUtils {
    private StorageUtils() {
    }

    public static List<String> getUserFoldersByDateDesc(String storageLocation, String location,boolean sort) throws IOException {
        File dir = Paths.get(storageLocation, location).normalize().toFile();
        File[] files = dir.listFiles();
        if(sort)
        	 Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_COMPARATOR);
        else
        	 Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
        
        return Arrays.stream(files).filter(p -> !p.isFile()).map(File::getName).collect(Collectors.toList());
    }

    public static List<String> getUserFilesByFolderByDateDesc(String storageLocation, String location, String folderName) throws IOException {
        Path dir = Paths.get(storageLocation, location, folderName).normalize();
        if (Files.exists(dir)) {
            try (Stream<Path> stream = Files.list(dir)) {
                return stream
                .filter(Files::isRegularFile)
                .sorted((p1, p2)-> Long.compare(p2.toFile().lastModified(), p1.toFile().lastModified()))
                .map(Path::getFileName)
                .map(Path::toString)
                .collect(Collectors.toList());
            }
        } else return Collections.emptyList();
    }

    public static String[] getUpdatedPaths(String ...filePaths) {
        if(null != filePaths && filePaths.length > 1) {
            String tempLocation = filePaths[1];
            if(Paths.get(tempLocation).normalize().isAbsolute()) {
                return Arrays.copyOfRange(filePaths, 1, filePaths.length);
            }
        }
        return filePaths;
    }

    public static Resource loadFileAsResource(String ...filePaths) throws FileNotFoundException {
        try {
            Path filePath = Paths.get(CommonConstant.EMPTY_STRING,filePaths).normalize();
            Resource resource = new UrlResource(filePath.toUri());
            if(resource.exists()) {
                return resource;
            } else {
                throw new FileNotFoundException("File not found ");
            }
        } catch (MalformedURLException ex) {
            throw new FileNotFoundException("File not found ");
        }
    }

    public static String getFileContentType(String fileName) {
        if( null != fileName) {
            Optional<String> getExtension = getExtensionByStringHandling(fileName);
            if(getExtension.isPresent()) {
                String extension = getExtension.get();
                if("pdf".equalsIgnoreCase(extension)) {
                    return "application/pdf";
                } else if("xlsx".equalsIgnoreCase(extension)) {
                    return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                } else if("xls".equalsIgnoreCase(extension)) {
                    return "application/vnd.ms-excel";
                }
            }
        }
        MimetypesFileTypeMap fileTypeMap = new MimetypesFileTypeMap();
        return fileTypeMap.getContentType(fileName);
    }

    private static Optional<String> getExtensionByStringHandling(String filename) {
        return Optional.ofNullable(filename)
          .filter(f -> f.contains("."))
          .map(f -> f.substring(filename.lastIndexOf(".") + 1));
    }
}
