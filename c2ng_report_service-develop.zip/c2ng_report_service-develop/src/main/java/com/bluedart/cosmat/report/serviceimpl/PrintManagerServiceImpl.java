package com.bluedart.cosmat.report.serviceimpl;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.bluedart.cosmat.commons.auth.utils.CommonAuthUtils;
import com.bluedart.cosmat.commons.auth.utils.User;
import com.bluedart.cosmat.report.constant.ReportConstant;
import com.bluedart.cosmat.report.service.PrintManagerService;
import com.bluedart.cosmat.report.util.CIFSStorageUtils;
import com.bluedart.cosmat.report.util.StorageUtils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

@Service
public class PrintManagerServiceImpl implements PrintManagerService {
    @Value("${report.storage-location}")
    String reportStorageLocation;

    @Autowired
    private CommonAuthUtils commonAuthUtils;
    
    @Value("${report.storage-domain}")
    String storageDomain;

    @Value("${report.storage-username}")
    String storageUserName;

    @Value("${report.storage-password}")
    String storagePassword;

    @Override
    public List<String> getFolders(boolean sort) throws IOException {
        return reportStorageLocation.startsWith(ReportConstant.CIFS_PREFIX) ? CIFSStorageUtils.getUserFoldersByDateDesc(reportStorageLocation, getUserDetails().getLocation(),sort, storageDomain, storageUserName, storagePassword) : StorageUtils.getUserFoldersByDateDesc(reportStorageLocation, getUserDetails().getLocation(),sort);
    }

    @Override
    public List<String> getFilesForFolder(String folderName) throws IOException {
    	 return reportStorageLocation.startsWith(ReportConstant.CIFS_PREFIX) ? CIFSStorageUtils.getUserFilesByFolderByDateDesc(reportStorageLocation, getUserDetails().getLocation(), folderName, storageDomain, storageUserName, storagePassword)  : StorageUtils.getUserFilesByFolderByDateDesc(reportStorageLocation, getUserDetails().getLocation(), folderName);
    }

    @Override
    public Resource downloadFile(String ...filePaths) throws FileNotFoundException, IOException {
        String[] updatedPaths = StorageUtils.getUpdatedPaths(filePaths);
        String pathToCheck = null;
        pathToCheck = (null != updatedPaths && updatedPaths.length > 0) ? updatedPaths[0] : reportStorageLocation;
    	return pathToCheck.startsWith(ReportConstant.CIFS_PREFIX) ? CIFSStorageUtils.loadFileAsResource(storageDomain, storageUserName, storagePassword, updatedPaths) : StorageUtils.loadFileAsResource(updatedPaths);
    }
    
    private User getUserDetails() {
        return commonAuthUtils.getUserDetails();
    }
}
