package com.bluedart.cosmat.report.model;


import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ValidateServiceCenterResponse {

	@JsonProperty("a")
	private boolean isError;

	@JsonProperty("b")
	private String errorMessage;

	@JsonProperty("c")
	private int apiTime;

	@JsonProperty("d")
	private String destinationServiceCenter;
}
