package com.bluedart.cosmat.report.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bluedart.cosmat.report.repository.ThermalPrinterRepository;
import com.bluedart.cosmat.report.service.PrintPickupSheetService;

@Service
public class PrintPickupSheetServiceImpl implements PrintPickupSheetService {
	
	@Autowired
	ThermalPrinterRepository thermalPrinterRepository;

	@Override
	public List<String> getPrinterType() {
		return thermalPrinterRepository.getPrinterTypes();
	}
	
//	public List<ViewprinterdetailsResponse> viewPrinterDetails(String printerType){
//		List<PrinterDetailsView> printerDetailsList = 	thermalPrinterRepository.getPrinterDetails(printerType);
//		List<ViewprinterdetailsResponse> response = new ArrayList<>();
//		printerDetailsList.forEach(item->{
//			var viewprinterdetailsResponse = new ViewprinterdetailsResponse();
//			viewprinterdetailsResponse.setPrinterType(item.getPrinterType());
//			viewprinterdetailsResponse.setMpsCodes(item.getMpsCodes());
//			viewprinterdetailsResponse.setSingleCodes(item.getSingleCodes());
//			viewprinterdetailsResponse.setDualCodes(item.getDualCodes());
//			viewprinterdetailsResponse.setTripleCodes(item.getTripleCodes());
//			viewprinterdetailsResponse.setSingleCodes55_30(item.getSingleCodes55_30());
//			response.add(viewprinterdetailsResponse);
//		});		
//		return response;
//	}
//   
}
