package com.bluedart.cosmat.report.dto;

import java.io.Serializable;
import java.util.List;
import com.bluedart.cosmat.commons.exception.APIResponse;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ReportCommonOutDTO implements Serializable{

	private static final long serialVersionUID = 1L;
	@JsonProperty("a")
	private String reportGenerationId;
	@JsonProperty("b")
	private Long reportId;
	@JsonProperty("c")
	private APIResponse<List<?>> reportResponse;
}