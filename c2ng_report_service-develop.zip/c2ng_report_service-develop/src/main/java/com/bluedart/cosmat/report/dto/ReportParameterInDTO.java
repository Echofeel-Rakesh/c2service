package com.bluedart.cosmat.report.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ReportParameterInDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@JsonProperty("pa")
	private String serviceCentreTextBox;
	@JsonProperty("pb")
	private String pikcupDatePicker;
	@JsonProperty("pc")
	private String oneRouteRadioButton;
	@JsonProperty("pd")
	private String routeComboBox;
	@JsonProperty("pe")
	private String routeWiseRadioButton;
	@JsonProperty("pf")
	private String employeeComboBox;
	@JsonProperty("pg")
	private String nonPrinterPURadioButton;
	@JsonProperty("ph")
	private String calledPUOnly;
	@JsonProperty("pi")
	private String normalRadioButton;
}