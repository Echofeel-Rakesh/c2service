package com.bluedart.cosmat.report.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bluedart.cosmat.commons.auth.entity.CommonWsUserMstEntity;
import com.bluedart.cosmat.commons.auth.repository.CommonWsUserMstRepository;
import com.bluedart.cosmat.commons.auth.utils.CommonAuthUtils;
import com.bluedart.cosmat.commons.constants.CommonConstant;
import com.bluedart.cosmat.commons.exception.APIResponse;
import com.bluedart.cosmat.commons.permissions.UserPermissionValidator;
import com.bluedart.cosmat.commons.utils.CommonUtils;
import com.bluedart.cosmat.commons.utils.SecurityManagerUtils;
import com.bluedart.cosmat.report.config.YAMLConfig;
import com.bluedart.cosmat.report.constant.ReportConstant;
import com.bluedart.cosmat.report.dto.LocationTypeDTO;
import com.bluedart.cosmat.report.dto.ReportParameterDTO;
import com.bluedart.cosmat.report.entity.ReportEntity;
import com.bluedart.cosmat.report.repository.ReportRepository;
import com.bluedart.cosmat.report.service.ReportTypeService;
import com.bluedart.cosmat.report.service.remoteimpl.LocationService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class ReportTypeServiceImpl implements ReportTypeService {

	@Autowired
	ReportRepository reportRepository;
	
	@Autowired
	YAMLConfig yamlConfig;

	@Autowired

	SecurityManagerUtils scManagerUtils;

	@Autowired
	private LocationService locationService;
	
	@Autowired
	CommonWsUserMstRepository commonWsUserMstRepository;
	
	@Autowired
	UserPermissionValidator userPermissionValidator;

    @Autowired
    private CommonAuthUtils commonAuthUtils;
	
	@Override
	public List<ReportParameterDTO> findByReportId(Long l) {
		
		List<ReportParameterDTO> reportParameterDTOList = new ArrayList<>();
		List<ReportEntity> reportEntityList = reportRepository.findByReportId(l);
		for(ReportEntity reportEntity:reportEntityList) {
			ReportParameterDTO reportParameterDTO = new ReportParameterDTO();
			reportParameterDTO=reportParameterDTO.convert(reportEntity);
			reportParameterDTO.getReportParameter().forEach(r -> {
				if (r.getHelpIconConfig() != null && r.getHelpIconConfig().isBlank()) {
					r.setHelpIconConfig(null);
				}
				if(l==144 && r.getName().equalsIgnoreCase("dtpickupdate") && r.getDataType().equalsIgnoreCase("datetime"))
					r.setMaxLength(360);
			});
			reportParameterDTOList.add(reportParameterDTO);
		}
		//condition check added for report name: EcomContainerStatusReport id: 569 
		//condition check added for report name: BaySlahReport id: 173 
		//condition check added for report name: GetContainerSlahReport id: 573 
		//condition check added for report name: DailyCanvasBagReport id: 579
		//condition check added for report name: BatchControlStatusReport id: 93
		//condition check added for report name: SlahReportWithException id: 119
		//condition check added for report name: SlahReportWithoutException id: 120
		//condition check added for report name: SlahExceptionReport id: 121
		//condition check added for report name: SlahDetailsReport id: 568
		//condition check added for report name: NotOutScannedReport id: 43
		//condition check added for report name: OtherReport id: 581
		//condition check added for report name: SpecificPodStatusReport id: 98
		if(l==194 || l==569 || l==173 || l== 573 || l==579 || l==93 || l==119 || l==120 || l==121 || l==568 || l==43 || l==581 || l==98) {
			setForMultiServiceCenters(reportParameterDTOList); 
		}
		return reportParameterDTOList;
	}


	/**This method sets MultiServiceCenters for report parameters
	 * @param reportParameterDTOList
	 */
	private void setForMultiServiceCenters(List<ReportParameterDTO> reportParameterDTOList) {

		if(reportParameterDTOList!=null && !reportParameterDTOList.isEmpty()) {
			ReportParameterDTO reportParameterDTO = reportParameterDTOList.get(0);
			String resourceName = reportParameterDTO.getName();
			APIResponse<Set<String>> response = locationService.getSecondaryServiceCenters(resourceName);
			Set<String> multipleSrviceCentersSet = response.getData(); 
			if (multipleSrviceCentersSet != null && !multipleSrviceCentersSet.isEmpty()
					&& (multipleSrviceCentersSet.size()>1 || multipleSrviceCentersSet.contains(CommonConstant.STAR))) {
				reportParameterDTO.setIsMultiServiceCenters(true);
			}else {
				reportParameterDTO.setIsMultiServiceCenters(false); 
			}
		}
	}

	@Override
	public List<LocationTypeDTO> getLocationType(String reportName,HttpServletRequest httpServletRequest) {

		List<LocationTypeDTO> dataList = new ArrayList<>();

		if (scManagerUtils.isAllIndiaAccess(reportName)) {

			populateList(dataList, ReportConstant.LOCATION_CODE_I, ReportConstant.LOCATION_NAME_I);
			populateList(dataList, ReportConstant.LOCATION_CODE_R, ReportConstant.LOCATION_NAME_R);
			populateList(dataList, ReportConstant.LOCATION_CODE_A, ReportConstant.LOCATION_NAME_A);
			populateList(dataList, ReportConstant.LOCATION_CODE_S, ReportConstant.LOCATION_NAME_S);

		} else if (scManagerUtils.isRegionAccess(reportName)) {
			
			populateList(dataList, ReportConstant.LOCATION_CODE_R, ReportConstant.LOCATION_NAME_R);
			populateList(dataList, ReportConstant.LOCATION_CODE_A, ReportConstant.LOCATION_NAME_A);
			populateList(dataList, ReportConstant.LOCATION_CODE_S, ReportConstant.LOCATION_NAME_S);

		} else if (scManagerUtils.isAreaAccess(reportName)) {
			
			populateList(dataList, ReportConstant.LOCATION_CODE_A, ReportConstant.LOCATION_NAME_A);
			populateList(dataList, ReportConstant.LOCATION_CODE_S, ReportConstant.LOCATION_NAME_S);

		} else {
			Optional<CommonWsUserMstEntity> commonWsUserMst = commonWsUserMstRepository.findByLoginId(commonAuthUtils.getUserDetails().getUsername());
			String locCode = "";
			if(commonWsUserMst.isPresent()) {
				locCode = commonWsUserMst.get().getLocation();
			}
			boolean isAuthorize=false;
			try {
			    userPermissionValidator.validatePermissionForSvc(reportName,
					CommonUtils.stringToUpeerCase(locCode), 0, httpServletRequest);
			}catch(Exception e){
				isAuthorize=true;
			}
			if(!isAuthorize) {
			 populateList(dataList, ReportConstant.LOCATION_CODE_S, ReportConstant.LOCATION_NAME_S);
			}
		}

		return dataList;
	}
	
	private void populateList(List<LocationTypeDTO> dataList,String locCode,String locName) {
		LocationTypeDTO dto=new LocationTypeDTO();
		dto.setLocationCode(locCode);
		dto.setLocationName(locName);
		dataList.add(dto);
	}
	
	@Override
	public Object getDodFodComboBox() { 
		return yamlConfig.getDodFodComboBox();
	}
	
	@Override
	public Object getProductDropDown(){
		return yamlConfig.getProductDropDown();
	}
	
	@Override
	public Object getRunDestType() {

		return yamlConfig.getRunDestType();

	}
	
	@Override
	public Object getStausComboBox() {
		return yamlConfig.getStatusComboBox();
	}
	
	@Override
	public Object getCreditCardsDropDown() {
		return yamlConfig.getCreditCardsDropDown();
	}
	
	@Override
	public Object getPriorityShipmentsComboBox() {
		return yamlConfig.getPriorityShipmentsComboBox();
	}
	
	@Override
	public Object getPodTypeDropDown() {
		return yamlConfig.getPodTypeDropDown();
	}
	
	@Override
	public Object getLinkToDropDown() {
		return yamlConfig.getLinkToDropDown();
	}
	
	@Override
	public Object getFeatureDropDown() {
		return yamlConfig.getFeatureDropDown();
	}

	@Override
	public Object getLabelSizeDropDown() {
		return yamlConfig.getLabelSizeDropDown();
	}

	@Override
	public Object getVehicleTrainTypeComboBox() {
		return yamlConfig.getVehicleTrainTypeComboBox();
	}

	@Override
	public Object getReportForOneComboBox() {
		return yamlConfig.getReportForOneComboBox();
	}

	@Override
	public Object getReportForTwoComboBox() {
		return yamlConfig.getReportForTwoComboBox();
	}
	
	@Override
	public Object getNotConnectedProductComboBox() {
		return yamlConfig.getNotConnectedProductComboBox();
	}

	@Override
	public Object getReportForAgentDropDown() {
		return yamlConfig.getReportAgentComboBox();
	}

	@Override
	public Object getReportDropDown() {
		return yamlConfig.getReportForComboBox();
	}
	
	@Override
	public Object getReportDropDownselect() {
		return yamlConfig.getReportForComboBoxselect();
	}
	
	@Override
	public Object getReportDropDownproduct() {
		return yamlConfig.getReportForComboBoxproduct();
	}

	@Override
	public Object getStatusCodesDropDown() {
		return yamlConfig.getStatusCodesDropDown();
	}


	@Override
	public Object getSfcApexProductivity() {
		
		return yamlConfig.getSfcApexProductivity();
	}
	
	@Override
	public Object getNotConnectedProductComboBoxA() {
		
		return yamlConfig.getNotConnectedProductComboBoxA();
	}


	@Override
	public Object getNotConnectedProductComboBoxS() {
		
		return yamlConfig.getNotConnectedProductComboBoxS();
	}


	@Override
	public Object getNotConnectedProductComboBoxD() {
		return yamlConfig.getNotConnectedProductComboBoxD();
	}

}
