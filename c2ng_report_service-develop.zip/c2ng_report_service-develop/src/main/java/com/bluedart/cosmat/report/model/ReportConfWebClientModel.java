package com.bluedart.cosmat.report.model;

import lombok.Data;

@Data
public class ReportConfWebClientModel {

	private String serviceUrl;
	private String methodType;
	private String path;
}