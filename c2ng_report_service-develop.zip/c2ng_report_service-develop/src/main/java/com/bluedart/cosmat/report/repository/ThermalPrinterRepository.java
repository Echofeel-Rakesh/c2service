package com.bluedart.cosmat.report.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.bluedart.cosmat.report.entity.ThermalPrinterEntity;

public interface ThermalPrinterRepository extends JpaRepository<ThermalPrinterEntity, Integer> {

	@Query("select distinct t.printerType from ThermalPrinterEntity t order by t.printerType")
	List<String> getPrinterTypes();

}
