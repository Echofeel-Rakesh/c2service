package com.bluedart.cosmat.report.view;

import java.util.Date;

public interface MisReportsConfigView {

	Date getStartDate();
	Date getEndDate();
	
}
