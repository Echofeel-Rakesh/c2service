package com.bluedart.cosmat.report.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.bluedart.cosmat.commons.auth.entityview.WsUserMstView;
import com.bluedart.cosmat.commons.auth.repository.CommonWsUserMstRepository;
import com.bluedart.cosmat.commons.auth.service.CommonAuthService;
import com.bluedart.cosmat.commons.auth.utils.User;
import com.bluedart.cosmat.report.dto.ReportCacheDTO;
import com.bluedart.cosmat.report.dto.ReportCommonInDTO;
import com.bluedart.cosmat.report.dto.ReportCommonOutDTO;
import com.bluedart.cosmat.report.model.ReportConfDetailsModel;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(SpringExtension.class)
class ReportUtilsTest {

	@InjectMocks
	ReportUtils reportUtils;

	@Mock
	private CommonAuthService userManagementService;
	
	@Mock
	private CommonWsUserMstRepository commonWsUserMstRepository;

	private ObjectMapper objectMapper = new ObjectMapper();

	@TempDir
	File temporaryDirectory;
	
	@Mock
	HttpServletResponse response;

	/*
	 * Mock SecurityContextHolder
	 */
	@BeforeEach
	void init() {

		User user = mock(User.class);
		when(user.getUsername()).thenReturn("BLUEDART\\86366");

		Authentication authentication = mock(Authentication.class);
		SecurityContext securityContext = mock(SecurityContext.class);
		when(securityContext.getAuthentication()).thenReturn(authentication);

		SecurityContextHolder.setContext(securityContext);
		when(SecurityContextHolder.getContext().getAuthentication().getPrincipal()).thenReturn(user);
	}

	@Disabled
	@ParameterizedTest
	@CsvFileSource(resources = "/testdata/generateJasperReportUtilsTest.csv", delimiterString = "|||", maxCharsPerColumn = 999999999)
	void generateJasperReportTest(String reportCommonInJson, String reportCommonOutJson, String reportConfDetailsJson)
			throws Exception {

		ReflectionTestUtils.setField(reportUtils, "reportStorageLocation", temporaryDirectory.getAbsolutePath());
		ReflectionTestUtils.setField(reportUtils, "reportTempLocation", "temp");
		
		ReportCommonInDTO reportCommonInDTO = objectMapper.readValue(reportCommonInJson, ReportCommonInDTO.class);
		ReportCommonOutDTO reportCommonOutDTO = objectMapper.readValue(reportCommonOutJson, ReportCommonOutDTO.class);
		ReportConfDetailsModel reportConfDetailsModel = objectMapper.readValue(reportConfDetailsJson,
				ReportConfDetailsModel.class);
		

		WsUserMstView wsUserMstView = new WsUserMstView() {

			@Override
			public String getOplocation() {
				return null;
			}

			@Override
			public String getName() {
				return "Harshada Khetale";
			}

			@Override
			public String getLoginId() {
				return "BLUEDART\\86366";
			}

			@Override
			public String getLocked() {
				return null;
			}

			@Override
			public String getLocation() {
				return "ADR";
			}

			@Override
			public String getDeleted() {
				return null;
			}

			@Override
			public String getEmpCode() {
				return null;
			}
		};
		User user = new User();
		user.setUsername(wsUserMstView.getLoginId());
		ReportCacheDTO cacheDto =new ReportCacheDTO();
		cacheDto.setUserId(wsUserMstView.getLoginId());
		log.trace("{} {} {} {}", wsUserMstView.getLoginId(), wsUserMstView.getOplocation(), wsUserMstView.getLocked(),
				wsUserMstView.getDeleted());

		when(userManagementService.findByCloginId(Mockito.anyString())).thenReturn(wsUserMstView);

		reportUtils.generateJasperReport(reportCommonOutDTO, reportConfDetailsModel, reportCommonInDTO,cacheDto,user);

		assertTrue(true);
	}

	@ParameterizedTest
	@CsvFileSource(resources = "/testdata/getCorrectedQueryParams.csv", delimiterString = "|||")
	void getCorrectedQueryParamsTest(String inputJson, String expectedJson) throws Exception {
		TypeReference<HashMap<String, Object>> typeReference = new TypeReference<>() {
		};
		HashMap<String, Object> inputQueryParams = objectMapper.readValue(inputJson, typeReference);
		HashMap<String, Object> expectedQueryParams = objectMapper.readValue(expectedJson, typeReference);

		Map<String, Object> result = reportUtils.getCorrectedQueryParams(inputQueryParams);
		assertEquals(expectedQueryParams, result);
	}
}
