package com.bluedart.cosmat.report.serviceimpl;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.bluedart.cosmat.report.repository.ReportRepository;

@ExtendWith(SpringExtension.class)
class ReportTypeServiceImplTest {
	@InjectMocks
	ReportTypeServiceImpl reportTypeServiceImpl;
	@Mock
	ReportRepository reportRepository = Mockito.mock(ReportRepository.class);

	@Test
	void testFindByReportId() {
		reportRepository.findByReportId(22l);
		assertNotNull(reportTypeServiceImpl.findByReportId(22l));
	}

}
