package com.bluedart.cosmat.report.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

class ResponseUtilsTest {

	@TempDir
	File temporaryDirectory;

	@ParameterizedTest
	@CsvFileSource(resources = "/testdata/generateHTMLForView.csv", delimiterString = "|||")
	void generateHTMLForViewTest(String fileName, String fileContent, String htmlHeader, String htmlFooter,
			String expectedContent) throws Exception {
		Path filePath = Path.of(temporaryDirectory.getAbsolutePath(), fileName);
		Files.createFile(filePath).toFile();

		Files.write(filePath, List.of(fileContent));

		FileSystemResource fileSystemResource = new FileSystemResource(filePath);

		ResponseEntity<Resource> responseEntity = ResponseUtils.generateHTMLForView(fileSystemResource, htmlHeader,
				htmlFooter);
		assertEquals(MediaType.TEXT_HTML, responseEntity.getHeaders().getContentType());

		// @formatter:off
		
		/*
		 * new line
		byte[] expectedBodyResponse = expectedContent.getBytes();
		byte[] actualBodyResponse = new BufferedInputStream(responseEntity.getBody().getInputStream()).readAllBytes();
		
		log.info("Ex {} ", new String(expectedBodyResponse));
		log.info("Ac {} ", new String(actualBodyResponse));
		
		assertEquals(expectedBodyResponse, actualBodyResponse);
		*/ 
		
		// @formatter:on

	}

	@ParameterizedTest
	@CsvFileSource(resources = "/testdata/generateHTMLForView.csv", delimiterString = "|||")
	void generateHTMLForViewFailTest(String fileName, String fileContent, String htmlHeader, String htmlFooter,
			String expectedContent) throws Exception {
		/*
		 * Non existent File
		 */
		Path filePath = Path.of(temporaryDirectory.getAbsolutePath(), fileName);
		FileSystemResource fileSystemResource = new FileSystemResource(filePath);
		
		assertThrows(Exception.class, () -> ResponseUtils.generateHTMLForView(fileSystemResource, htmlHeader, htmlFooter));
	}
}
