package com.bluedart.cosmat.report.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import java.util.HashMap;

import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.bluedart.cosmat.commons.constants.CommonConstant;
import com.bluedart.cosmat.commons.exception.APIResponse;
import com.bluedart.cosmat.report.dto.ReportCommonInDTO;
import com.bluedart.cosmat.report.dto.ReportCommonOutDTO;
import com.bluedart.cosmat.report.model.ReportConfDetailsModel;
import com.bluedart.cosmat.report.model.ReportConfModel;
import com.bluedart.cosmat.report.service.remoteimpl.PickupService;
import com.bluedart.cosmat.report.serviceimpl.ReportCommonServiceImpl;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
class ReportCommonServiceTest {

	@InjectMocks
	ReportCommonServiceImpl reportCommonService;

	@Mock
	private PickupService pickupService;

	@Mock
	private MockHttpServletRequest httpServletRequest;

	private ObjectMapper objectMapper = new ObjectMapper();

	@ParameterizedTest
	@CsvFileSource(resources = "/testdata/generateReportServiceTest.csv", delimiterString = "|||", maxCharsPerColumn = 999999999)
	void generateReportTest(String reportCommonInJson, String reportMapJson, boolean reportResponseIsNull) throws Exception {

		ReportCommonInDTO reportCommonInDTO = objectMapper.readValue(reportCommonInJson, ReportCommonInDTO.class);

		APIResponse<String> reportResponse = new APIResponse<>();
		ReportCommonOutDTO reportCommonOutDTO = new ReportCommonOutDTO();
//		reportCommonOutDTO.setReportResponse(reportResponse);

		TypeReference<HashMap<Long, ReportConfDetailsModel>> typeReference = new TypeReference<>() {};
		HashMap<Long, ReportConfDetailsModel> reportMap = objectMapper.readValue(reportMapJson, typeReference);

		ReportConfModel reportConfModel = new ReportConfModel();
		reportConfModel.setReportMap(reportMap);

		when(pickupService.getReport(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new APIResponse<>());
		when(pickupService.getPostReport(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new APIResponse<>());
		
		reportCommonOutDTO = reportCommonService.generateReport(reportCommonInDTO, httpServletRequest.getHeader(CommonConstant.AUTHORIZATION_CONST), reportConfModel);
		
		APIResponse<?> apiResponse = reportCommonOutDTO.getReportResponse();
		
		if (reportResponseIsNull) {
			assertNull(apiResponse);
		} else {
			assertNotNull(apiResponse);
		}
	}
}
