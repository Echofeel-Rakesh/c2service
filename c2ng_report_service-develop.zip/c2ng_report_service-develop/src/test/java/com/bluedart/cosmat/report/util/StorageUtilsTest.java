package com.bluedart.cosmat.report.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.core.io.Resource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Disabled
class StorageUtilsTest {
	/*
	 * Since Most Functions Tested Require OS interaction via file, When the test
	 * method finishes, JUnit automatically deletes all files and directories in and
	 * including the TemporaryFolder. JUnit guarantees to delete the resources,
	 * whether the test passes or fails.
	 */
	@TempDir
	File temporaryDirectory; // cannot be private, junit req.

	@ParameterizedTest
	@CsvSource("var,temp,reports")
	void getUserFoldersByDateDescTest(String storageLocation, String location, String directory) throws Exception {
		Path path = Paths.get(temporaryDirectory.getAbsolutePath(), storageLocation, location, directory);

		/*
		 * storagelocation is offsetted to focus on temporary directory only
		 */
		storageLocation = Path.of(temporaryDirectory.getAbsolutePath(), storageLocation).toFile().getAbsolutePath();

		/*
		 * Create Temporary Directory /temporaryDirectory/storageLocation/location
		 */
		Files.createDirectories(path);

		List<String> directoryList = StorageUtils.getUserFoldersByDateDesc(storageLocation, location, true);
		assertEquals(directory, directoryList.get(0));
	}

	/*
	 * @ParameterizedTest
	 * 
	 * @CsvSource("var,temp,reports, TSRWiseCallAnalysis") void
	 * getUserFilesByFolderByDateDesc(String storageLocation, String location,
	 * String folderName, String fileName) throws Exception { Path path =
	 * Paths.get(temporaryDirectory.getAbsolutePath(), storageLocation, location,
	 * folderName); storageLocation = Path.of(temporaryDirectory.getAbsolutePath(),
	 * storageLocation).toFile().getAbsolutePath();
	 * 
	 * Files.createDirectories(path);
	 * 
	 * List<String> expectedFileList = new ArrayList<>(); for (int i = 0; i < 2;
	 * i++) { expectedFileList.add(String.format("%s-%d", fileName, i)); }
	 * 
	 * expectedFileList.forEach(arg -> { Path filePath =
	 * Path.of(path.toFile().getAbsolutePath(), arg); try { log.info("File Name {}",
	 * filePath.toFile().getAbsolutePath()); Files.createFile(filePath); } catch
	 * (IOException e) { log.info("error creating file {}", e.getMessage()); } });
	 * 
	 * List<String> actualfileList =
	 * StorageUtils.getUserFilesByFolderByDateDesc(storageLocation, location,
	 * folderName);
	 * 
	 * assertEquals("TSRWiseCallAnalysis-1", actualfileList.get(0)); }
	 */

	@Test
	void loadFileAsResourceTest() throws Exception {
		Resource resource = StorageUtils.loadFileAsResource(temporaryDirectory.getAbsolutePath());
		assertNotNull(resource);
	}

	@ParameterizedTest
	@CsvSource({ "non_existend_file" })
	void loadFileAsResourceFailTest(String resourceName) {
		assertThrows(FileNotFoundException.class, () -> StorageUtils.loadFileAsResource(resourceName));
	}

	@ParameterizedTest
	@CsvFileSource(resources = "/testdata/getFileContentType.csv", delimiterString = "|||")
	void getFileContentType(String fileName, String expectedContentType) {
		String actualFileType = StorageUtils.getFileContentType(fileName);
		assertEquals(expectedContentType, actualFileType);
	}
}
