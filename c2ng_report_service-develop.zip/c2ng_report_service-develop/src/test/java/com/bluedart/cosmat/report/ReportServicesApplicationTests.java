package com.bluedart.cosmat.report;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.bluedart.cosmat.commons.permissions.UserPermissions;
import com.bluedart.cosmat.report.service.remoteimpl.LocationService;

@Disabled //Need to change as per SSO implementations
@SpringBootTest
@AutoConfigureMockMvc
class ReportServicesApplicationTests {
	@Autowired
	private MockMvc mockmvc;
	
	@MockBean
	private UserPermissions userPermissions;
	
	@MockBean
	private LocationService locationService;

	String jwtToken = null;
	
	@BeforeEach
	public void initEach() throws Exception {
		JSONObject loginJsonObject = new JSONObject();
		loginJsonObject.put("a", "BLUEDART\\32787");
		loginJsonObject.put("b", "password");
		Mockito.doNothing().when(userPermissions).populateUserPermissions(Mockito.anyString());
		MvcResult result = mockmvc
				.perform(
						post("/auth/login").contentType(MediaType.APPLICATION_JSON).content(loginJsonObject.toString()))
				.andReturn();
		String res = result.getResponse().getContentAsString();
		jwtToken = new JSONObject(res).getJSONObject("data").getString("a");
	}

	
	@Test
	void test_loadReportParameters_ForReportId_2() throws Exception {
		HttpHeaders header = new HttpHeaders();
		header.setBearerAuth(jwtToken);
		
		mockmvc.perform(get("/report-parameter/2").headers(header)
	    	      .contentType(MediaType.APPLICATION_JSON))
	    	      .andExpect(status().isOk())
	    	      .andExpect(content()
	    	      .contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
	    	      .andExpect(jsonPath("error", is(false)));
	}

}
