//package com.bluedart.cosmat.report.controller;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.mockito.Mockito.doNothing;
//import static org.mockito.Mockito.when;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//
//import java.util.HashMap;
//
//import org.json.JSONObject;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.junit.jupiter.params.ParameterizedTest;
//import org.junit.jupiter.params.provider.CsvFileSource;
//import org.mockito.Mockito;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.MediaType;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.test.web.servlet.MvcResult;
//
//import com.bluedart.cosmat.commons.exception.APIResponse;
//import com.bluedart.cosmat.commons.permissions.UserPermissions;
//import com.bluedart.cosmat.report.dto.ReportCommonOutDTO;
//import com.bluedart.cosmat.report.dto.ReportCommonResponseDTO;
//import com.bluedart.cosmat.report.model.ReportConfDetailsModel;
//import com.bluedart.cosmat.report.model.ReportConfModel;
//import com.bluedart.cosmat.report.service.ReportCommonService;
//import com.bluedart.cosmat.report.util.ReportUtils;
//import com.fasterxml.jackson.core.type.TypeReference;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//import lombok.extern.slf4j.Slf4j;
//
//@Slf4j
//@SpringBootTest
//@AutoConfigureMockMvc
//@ExtendWith(SpringExtension.class)
//class ReportCommonControllerTest {
//
//	@Autowired
//	private MockMvc mockMvc;
//
//	@MockBean
//	private ReportCommonService reportCommonService;
//
//	@MockBean
//	private ReportConfModel reportConfModel;
//
//	@MockBean
//	private ReportUtils reportUtils;
//
//	@MockBean
//	private UserPermissions userPermissions;
//
//	private ObjectMapper objectMapper = new ObjectMapper();
//
//	private String jwtToken = null;
//
//	@BeforeEach
//	void init() throws Exception {
//		JSONObject jsonObject = new JSONObject();
//		jsonObject.put("a", "BLUEDART\\32787");
//		jsonObject.put("b", "password");
//
//		doNothing().when(userPermissions).populateUserPermissions(anyString());
//
//		MvcResult mvcResult = mockMvc
//				.perform(post("/auth/login").contentType(MediaType.APPLICATION_JSON).content(jsonObject.toString()))
//				.andExpect(status().isOk()).andReturn();
//
//		String response = mvcResult.getResponse().getContentAsString();
//		jwtToken = new JSONObject(response).getJSONObject("data").getString("a");
//	}
//
//	@ParameterizedTest
//	@CsvFileSource(resources = "/testdata/generateReportControllerTest.csv", delimiterString = "|||", maxCharsPerColumn = 999999999)
//	void generateReportTest(String requestJson, String reportMapJson, String statusCode, String statusMessage,
//			String expectedStatusCode, String expectedStatusMessage) throws Exception {
//		HttpHeaders headers = new HttpHeaders();
//		headers.setBearerAuth(jwtToken);
//
//		TypeReference<HashMap<Long, ReportConfDetailsModel>> typeReference = new TypeReference<>() {};
//		HashMap<Long, ReportConfDetailsModel> reportMap = objectMapper.readValue(reportMapJson, typeReference);
//		when(reportConfModel.getReportMap()).thenReturn(reportMap);
//
//		when(reportUtils.getCorrectedQueryParams(Mockito.anyMap())).then(arg -> {
//			log.info("mocked method invoked...");
//			/*
//			 * original function removes null, empty from parameters, return original map
//			 * without changes
//			 */
//			return arg.getArgument(0);
//		});
//
//		APIResponse<String> reportResponse = new APIResponse<>(false, statusCode, statusMessage);
//		ReportCommonOutDTO reportCommonOutDTO = new ReportCommonOutDTO();
//		reportCommonOutDTO.setReportResponse(reportResponse);
//		when(reportCommonService.generateReport(Mockito.any(), Mockito.any(), Mockito.any()))
//				.thenReturn(reportCommonOutDTO);
//
//		ReportCommonResponseDTO reportCommonResponseDTO = new ReportCommonResponseDTO();
//		when(reportUtils.generateJasperReport(Mockito.any(), Mockito.any(), Mockito.any()))
//				.thenReturn(reportCommonResponseDTO);
//
//		MvcResult mvcResult = mockMvc.perform(
//				post("/generatereport").headers(headers).content(requestJson).contentType(MediaType.APPLICATION_JSON))
//				.andReturn();
//
//		String response = mvcResult.getResponse().getContentAsString();
//		TypeReference<APIResponse<ReportCommonResponseDTO>> apiTypeReference = new TypeReference<>() {};
//		APIResponse<ReportCommonResponseDTO> apiResponse = objectMapper.readValue(response, apiTypeReference);
//		assertEquals(apiResponse.getStatusCode(), expectedStatusCode);
//	}
//}
