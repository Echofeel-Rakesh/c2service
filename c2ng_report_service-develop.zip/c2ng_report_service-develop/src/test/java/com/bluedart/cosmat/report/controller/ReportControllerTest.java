package com.bluedart.cosmat.report.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.bluedart.cosmat.commons.exception.APIResponse;
import com.bluedart.cosmat.report.dto.ReportParameterDTO;
import com.bluedart.cosmat.report.entity.ReportparameterEntity;
import com.bluedart.cosmat.report.service.ReportTypeService;

@ExtendWith(SpringExtension.class)
class ReportControllerTest {
	@InjectMocks
	ReportController reportController;
	@Mock
	ReportTypeService reportService;
	@Test
	void testGetReportType()
	{
		List<ReportparameterEntity> reportParameter=new ArrayList<>();
		boolean isMultiServiceCenters= false;
		List<ReportParameterDTO> resultData=new ArrayList<>();
		ResponseEntity<APIResponse<List<ReportParameterDTO>>> res = reportController.getReportType(22l);
		assertEquals( HttpStatus.OK,res.getStatusCode());
		when(reportService.findByReportId(22l)).thenReturn(resultData).thenReturn(resultData);
		resultData.add(new ReportParameterDTO(22l,"","","",false,0,reportParameter,isMultiServiceCenters));
		ResponseEntity<APIResponse<List<ReportParameterDTO>>> res1 = reportController.getReportType(22l);
		assertEquals( HttpStatus.OK,res1.getStatusCode());
	}
}
