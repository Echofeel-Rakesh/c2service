package com.bluedart.cosmat.report.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.util.List;

import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.bluedart.cosmat.commons.exception.APIResponse;
import com.bluedart.cosmat.commons.permissions.UserPermissions;
import com.bluedart.cosmat.report.service.PrintManagerService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
@AutoConfigureMockMvc
@ExtendWith(SpringExtension.class)
@Disabled
class PrintManagerControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private PrintManagerService printManagerService;

	@MockBean
	private MockHttpServletResponse httpServletResponse;
	
	@MockBean
	private UserPermissions userPermissions;

	private ObjectMapper objectMapper = new ObjectMapper();

	private String jwtToken = null;

	@BeforeEach
	void init() throws Exception {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("a", "BLUEDART\\32787");
		jsonObject.put("b", "password");

		doNothing().when(userPermissions).populateUserPermissions(anyString());

		MvcResult mvcResult = mockMvc
				.perform(post("/auth/login").contentType(MediaType.APPLICATION_JSON).content(jsonObject.toString()))
				.andExpect(status().isOk()).andReturn();

		String response = mvcResult.getResponse().getContentAsString();
		jwtToken = new JSONObject(response).getJSONObject("data").getString("a");
	}

//	@ParameterizedTest
//	@Disabled
//	@CsvFileSource(resources = "/testdata/getFilesForFolder.csv", delimiterString = "|||", maxCharsPerColumn = 9999999)
//	void controllerTest() throws Exception {
//		HttpHeaders httpHeaders = new HttpHeaders();
//		httpHeaders.setBearerAuth(jwtToken);
//
//		TypeReference<List<String>> typeReference = new TypeReference<>() {};
//		List<String> folderList = objectMapper.readValue(folderJson, typeReference) : null;
//		
//		MvcResult mvcResult = mockMvc.perform(get("").headers(httpHeaders)).andReturn();
//		String response = mvcResult.getResponse().getContentAsString();
//	}

	@ParameterizedTest
	@CsvFileSource(resources = "/testdata/getAllFolder.csv", delimiterString = "|||", maxCharsPerColumn = 9999999)
	void getAllFoldersTest(String folderJson, boolean isError) throws Exception {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setBearerAuth(jwtToken);

		TypeReference<List<String>> typeReference = new TypeReference<>() {};
		List<String> folderList = folderJson != null ? objectMapper.readValue(folderJson, typeReference) : null;

		if(folderJson == null) {
			when(printManagerService.getFolders(true)).thenThrow(new IOException());
		}else {
			when(printManagerService.getFolders(true)).thenReturn(folderList);			
		}

		MvcResult mvcResult = mockMvc.perform(get("/print-manager/folders/").headers(httpHeaders)).andReturn();
		String response = mvcResult.getResponse().getContentAsString();
		APIResponse<?> apiResponse = objectMapper.readValue(response, APIResponse.class);
		assertEquals(true, apiResponse.isError());
	}
	
	@ParameterizedTest
	@CsvFileSource(resources = "/testdata/getAllFolder.csv", delimiterString = "|||", maxCharsPerColumn = 9999999)
	void getFilesForFolderTest(String folderJson, boolean isError, String folderName) throws Exception {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setBearerAuth(jwtToken);

		TypeReference<List<String>> typeReference = new TypeReference<>() {};
		List<String> folderList = folderJson != null ? objectMapper.readValue(folderJson, typeReference) : null;

		if(folderJson == null) {
			when(printManagerService.getFilesForFolder(anyString())).thenThrow(new IOException());
		}else {
			when(printManagerService.getFilesForFolder(anyString())).thenReturn(folderList);			
		}

		MvcResult mvcResult = mockMvc.perform(get("/print-manager/files/{folderName}", folderName).headers(httpHeaders)).andReturn();
		String response = mvcResult.getResponse().getContentAsString();
		APIResponse<?> apiResponse = objectMapper.readValue(response, APIResponse.class);
		assertEquals(isError, apiResponse.isError());
	}
	
	@ParameterizedTest
	@CsvFileSource(resources = "/testdata/downloadFile.csv", delimiterString = "|||", maxCharsPerColumn = 9999999)
	void downloadFileTest(String fileName, String folderName, String loc, String isDownload, boolean isExists, boolean isFile) throws Exception {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setBearerAuth(jwtToken);

		if(fileName != null) {
			Resource fileResource = getResource(fileName, isFile, isExists);
			when(printManagerService.downloadFile(ArgumentMatchers.<String>any())).thenAnswer((answer) -> {
				log.info("Mock Print Service Called...");
				return fileResource;
			});
		}else {
			when(printManagerService.downloadFile(ArgumentMatchers.<String>any())).thenThrow(new FileNotFoundException());
		}

		
		MvcResult mvcResult = mockMvc
				.perform(get("/download-report").queryParam("file", fileName).queryParam("folder", folderName)
						.queryParam("loc", loc).queryParam("download", isDownload).headers(httpHeaders))
				.andReturn();
		String response = mvcResult.getResponse().getContentAsString();
		assertNotNull(response);
	}
	
	private Resource getResource(String fileName, boolean isFile, boolean isExists) throws Exception {
    	Resource fileResource = new Resource() {
			
			@Override
			public InputStream getInputStream() throws IOException {
				return new ByteArrayInputStream("SAMPLE BODY".getBytes());
			}
			
			@Override
			public long lastModified() throws IOException {
				return 0;
			}
			
			@Override
			public URL getURL() throws IOException {
				return null;
			}
			
			@Override
			public URI getURI() throws IOException {
				return null;
			}
			
			@Override
			public String getFilename() {
				return fileName;
			}
			
			@Override
			public boolean isFile() {
				return isFile;
			}
			
			@Override
			public File getFile() throws IOException {
				return null;
			}
			
			@Override
			public String getDescription() {
				return null;
			}
			
			@Override
			public boolean exists() {
				return isExists;
			}
			
			@Override
			public Resource createRelative(String relativePath) throws IOException {
				return null;
			}
			
			@Override
			public long contentLength() throws IOException {
				return 0;
			}
		};
		
		log.trace("{} {} {} {} {}", fileResource.lastModified(), fileResource.getURL(), fileResource.getURI(),
				fileResource.getDescription(), fileResource.createRelative(null));
		
		return fileResource;
	}
}
