node {
    currentBuild.displayName = "${currentBuild.number}-${release_name}-${version}"
}

pipeline {
    agent {
        label 'in-isvisv9650'
    }

    /*tools {
        git 'Default'
        nodejs 'extensure-nodejs' 
        maven 'extensure-maven'
        jdk 'extensure-java11'
    }*/
    environment {
        whitesourcedir = "/var/whitesource"
        image_tag = "${BRANCH}_${version}_${BUILD_TIMESTAMP}"
        kubeconfig_file = "${WORKSPACE}/devops/kubeconfig/${environment}"
        build_version = "${version}-SNAPSHOT"
        NEXUS_CREDS = credentials('nexus')
        NEXUS_REPO = "hj-pespes14238:5000"
        backend_service ="${service_name}"+'-service'
    }    
    stages {
        stage('checkout') {
            steps {
                sh '''echo "\n\nImage build tag: ${image_tag}\n\n"
                echo "Image build tag: ${image_tag}\n\n" > ${WORKSPACE}/imagelist.txt'''
                git branch: '${BRANCH}',credentialsId: 'github_credentials',url: "https://github.com/PSLGRP/c2ng_report_service.git"
            }
         }
          
        stage('Artifact creation of ${service_name} service') {
            steps {
                withCredentials([usernamePassword(credentialsId: 'nexus_cred', passwordVariable: 'repopass', usernameVariable: 'repouser')]) {
                    sh '''
                    export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-11.0.12.0.7-0.el8_4.x86_64
                        export PATH=$JAVA_HOME/bin:$PATH
                        ## complilation of ${backend_service} artifacts
                        cd ${WORKSPACE}
                        mvn clean package
                        cd ${WORKSPACE}/
                        docker build -t ${NEXUS_REPO}/${backend_service}:latest -t ${NEXUS_REPO}/${backend_service}:${image_tag} -t ${NEXUS_REPO}/${backend_service}:${version} --build-arg VERSION="*" .
                        docker push ${NEXUS_REPO}/${backend_service}
                        docker push ${NEXUS_REPO}/${backend_service}:${image_tag}
                        docker push ${NEXUS_REPO}/${backend_service}:${version}
                        echo "\n${NEXUS_REPO}/${backend_service}:${image_tag}" >> ${WORKSPACE}/imagelist.txt
                        '''
                }
            }
        }
        stage('Code Quality Check via SonarQube of ${service_name} service') {
            
            environment{
                scannerHome = tool 'extensure-sonar-scanner'
            }
            steps {
                withSonarQubeEnv("extensure-sonar-container") {
                    sh '''
                        export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-11.0.12.0.7-0.el8_4.x86_64
                        export PATH=$JAVA_HOME/bin:$PATH
                        cd  ${scannerHome}/bin/
                        ./sonar-scanner -Dsonar.projectBaseDir=${WORKSPACE}  -Dsonar.host.url=http://in-isvisv9186:9000   -Dsonar.projectKey=${backend_service} \
                        -Dsonar.java.binaries=${WORKSPACE}/target/classes -Dsonar.java.coveragePlugin=jacoco -Dsonar.coverage.jacoco.xmlReportPaths=${cosmat_workspace}/${backend_service}/target/site/jacoco/jacoco.xml
                        '''
                }
            }
        }
        stage('Deploying ${service_name} service') {
            steps {
                catchError(buildResult: 'SUCCESS', stageResult: 'FAILURE'){
                sh '''
                     if [  -z "$(kubectl get namespace --kubeconfig=${kubeconfig_file} | grep ${TEST_PROJECT})" ]
                    then
                        echo "Creating ${TEST_PROJECT} project"
                        kubectl create namespace ${TEST_PROJECT} --kubeconfig=${kubeconfig_file}
                        
                        kubectl create secret docker-registry nexus --docker-server=${NEXUS_REPO} --docker-username=${NEXUS_CREDS_USR} --docker-password=${NEXUS_CREDS_PSW} -n ${TEST_PROJECT} --kubeconfig=${kubeconfig_file}
                        kubectl patch serviceaccount default -p '{"imagePullSecrets": [{"name": "nexus"}]}' -n ${TEST_PROJECT} --kubeconfig=${kubeconfig_file}
                     fi 
                     sed -i '6s/.*/appVersion: '${version}'/' ${WORKSPACE}/devops/helm/${backend_service}/Chart.yaml
                     
                     helm package ${WORKSPACE}/devops/helm/${backend_service}
                     if [  -z "$(helm ls -n ${TEST_PROJECT} --kubeconfig=${kubeconfig_file} | grep ${release_name})" ]
                     then
                        helm install ${release_name} ${WORKSPACE}/devops/helm/${backend_service}/ -f ${WORKSPACE}/devops/helm/${backend_service}/${environment}-values.yaml --set global.namespace=${TEST_PROJECT} --set global.image.repository=${NEXUS_REPO} --set global.resources.enabled=false --set "${service_name}"Service.buildTag=${image_tag}   -n ${TEST_PROJECT} --kubeconfig=${kubeconfig_file}
                     else
                        helm upgrade ${release_name} ${WORKSPACE}/devops/helm/${backend_service}/ -f ${WORKSPACE}/devops/helm/${backend_service}/${environment}-values.yaml --set global.namespace=${TEST_PROJECT} --set global.image.repository=${NEXUS_REPO} --set global.resources.enabled=false --set "${service_name}"Service.buildTag=${image_tag}   -n ${TEST_PROJECT} --kubeconfig=${kubeconfig_file}
                     fi
                     case "${backend_service}" in
                	    #case 1
	                    "auth-service") kubectl patch svc auth-service -p '{"spec": { "type": "NodePort", "ports": [ { "nodePort": 31008, "port": 9090, "protocol": "TCP", "targetPort": 9090 } ] } }' --type=merge -n ${TEST_PROJECT} --kubeconfig=${kubeconfig_file}
                      ;;
	
	                    #case 2
	                    "customer-service") kubectl patch svc customer-service -p '{"spec": { "type": "NodePort", "ports": [ { "nodePort": 31000, "port": 8086, "protocol": "TCP", "targetPort": 8086 } ] } }' --type=merge -n ${TEST_PROJECT} --kubeconfig=${kubeconfig_file}
                     

                     ;;
	
	                    #case 3
	                    "location-service") kubectl patch svc location-service -p '{"spec": { "type": "NodePort", "ports": [ { "nodePort": 31002, "port": 8085, "protocol": "TCP", "targetPort": 8085 } ] } }' --type=merge -n ${TEST_PROJECT} --kubeconfig=${kubeconfig_file}
                     

                    ;;
                        #case 4
	                    "master-service") kubectl patch svc master-service -p '{"spec": { "type": "NodePort", "ports": [ { "nodePort": 31010, "port": 8088, "protocol": "TCP", "targetPort": 8088 } ] } }' --type=merge -n ${TEST_PROJECT} --kubeconfig=${kubeconfig_file}
                     

                    ;;
                        #case 5
	                    "network-service") kubectl patch svc network-service -p '{"spec": { "type": "NodePort", "ports": [ { "nodePort": 31006, "port": 8084, "protocol": "TCP", "targetPort": 8084 } ] } }' --type=merge -n ${TEST_PROJECT} --kubeconfig=${kubeconfig_file}
                     
                    ;;
                        #case 6
	                    "product-service") kubectl patch svc product-service -p '{"spec": { "type": "NodePort", "ports": [ { "nodePort": 31004, "port": 8082, "protocol": "TCP", "targetPort": 8082 } ] } }' --type=merge -n ${TEST_PROJECT} --kubeconfig=${kubeconfig_file}
                     

                    ;;
                        #case 7
	                    "pickup-service") kubectl patch svc pickup-service -p '{"spec": { "type": "NodePort", "ports": [ { "nodePort": 31003, "port": 8090, "protocol": "TCP", "targetPort": 8090 } ] } }' --type=merge -n ${TEST_PROJECT} --kubeconfig=${kubeconfig_file}
                     

                    ;;
                        #case 8
	                    "report-service") kubectl patch svc report-service -p '{"spec": { "type": "NodePort", "ports": [ { "nodePort": 31011, "port": 8089, "protocol": "TCP", "targetPort": 8089 } ] } }' --type=merge -n ${TEST_PROJECT} --kubeconfig=${kubeconfig_file}
                     

                    ;;
                        #case 9
	                    "route-service") kubectl patch svc route-service -p '{"spec": { "type": "NodePort", "ports": [ { "nodePort": 31005, "port": 8087, "protocol": "TCP", "targetPort": 8087 } ] } }' --type=merge -n ${TEST_PROJECT} --kubeconfig=${kubeconfig_file}
                     

                    ;;
                        #case 10
	                    "usermanagement-service") kubectl patch svc usermanagement-service -p '{"spec": { "type": "NodePort", "ports": [ { "nodePort": 31009, "port": 9084, "protocol": "TCP", "targetPort": 9084 } ] } }' --type=merge -n ${TEST_PROJECT} --kubeconfig=${kubeconfig_file}
                     

                    ;;
                        
                        #case 11
	                    "vehicle-service")  kubectl patch svc vehicle-service -p '{"spec": { "type": "NodePort", "ports": [ { "nodePort": 31012, "port": 8091, "protocol": "TCP", "targetPort": 8091 } ] } }' --type=merge -n ${TEST_PROJECT} --kubeconfig=${kubeconfig_file}
                     

                    ;;
                        #case 12
	                    "container-service")  kubectl patch svc container-service -p '{"spec": { "type": "NodePort", "ports": [ { "nodePort": 31013, "port": 8092, "protocol": "TCP", "targetPort": 8092 } ] } }' --type=merge -n ${TEST_PROJECT} --kubeconfig=${kubeconfig_file}
                

                    ;;
                        #case 13
	                    "shipment-service")   kubectl patch svc shipment-service -p '{"spec": { "type": "NodePort", "ports": [ { "nodePort": 31007, "port": 8083, "protocol": "TCP", "targetPort": 8083 } ] } }' --type=merge -n ${TEST_PROJECT} --kubeconfig=${kubeconfig_file}
                     

                    ;;
                    esac


                     '''
                }     
            }
        }
    }
    post {
        always {
            junit '**/target/surefire-reports/TEST-*.xml'
            archiveArtifacts artifacts: '**/target/*.jar,k8s/helm/*.tgz,imagelist.txt', onlyIfSuccessful: true
       }
    }               
 }
