node {
    currentBuild.displayName = "${currentBuild.number}-${release_name}-${version}"
   
}
pipeline {
    agent {
    kubernetes {
        cloud "${env.cloud}"
        inheritFrom 'jenkins-slave-prg-light'
              yaml """
apiVersion: v1
kind: Pod
metadata:
  labels:
    Label: openshift4-prg-light
spec:
  containers:
  - name: maven
    image: docker.artifactory.dhl.com/maven:3.8-jdk-11
    env:
    - name: HOME
      value: "/tmp"
    command:
    - cat
    tty: true
    resources:
     requests:
      cpu: 800m
      memory: 2Gi
     limits:
      cpu: 800m
      memory: 2Gi
    imagePullPolicy: Always
    workingDir: "/var/lib/jenkins"
  - name: helm
    image: docker.artifactory.dhl.com/tools/helm3:latest
    env:
    - name: HOME
      value: "/tmp"
    tty: true
    command:
    - cat
    resources:
      requests:
        cpu: 50m
        memory: 100Mi
      limits:
        cpu: 200m
        memory: 512Mi
    imagePullPolicy: Always
    workingDir: "/var/lib/jenkins"            
"""
    }
  }
environment {
    git_token = credentials('DHLDEVENVCRED')
    ocp_token = credentials('DHLDEVENVCRED')
    ARTIFACTORY_URL = "https://docker.artifactory.dhl.com"
    ARTIFACTORY_REPO = "docker.artifactory.dhl.com/bluedart"
    date = new Date().format("yyyy-MMM-dd-HH.mm", TimeZone.getTimeZone("IST"))
    image_tag ="${BRANCH}-${version}-${date}"
    CBJ_ARTIFACTORY = "docker.artifactory-cbj.dhl.com/bluedart"
    backend_service ="${service_name}"+'-service'
    }
    stages {
       stage('Artifact creation of common-service') {
        
            steps { 
              git branch: '${BRANCH}', credentialsId: 'DHLDEVENVCRED', url: "https://git.dhl.com/BlueDart/c2ng_commons_service.git"
           
                container('maven') {
                        sh '''
                        
                        cd ${WORKSPACE}/
                        mvn clean install -DskipTests
                       
                        '''
                        }               
                }
            }
        stage('checkout') {
            steps{
                git branch: '${BRANCH}', credentialsId: 'DHLDEVENVCRED', url: "https://git.dhl.com/BlueDart/c2ng_report_service.git"
            }
         }
          
        stage('Artifact creation of ${backend_service}') {
        
            steps { 
                container('maven') {
                        sh '''
                        
                        cd ${WORKSPACE}/
                        mvn  -DskipTests clean package 
                        '''          
                        }
                script {
                        docker.withRegistry("${ARTIFACTORY_URL}", 'DHLDEVENVCRED' ) {
                            sh """
                            cd ${WORKSPACE}/
                            docker build -t ${ARTIFACTORY_REPO}/${backend_service}:${image_tag} --build-arg VERSION="${version}" .
                            docker push ${ARTIFACTORY_REPO}/${backend_service}:${image_tag}
                            skopeo copy --src-creds=${ocp_token} --dest-creds=${ocp_token} docker://${ARTIFACTORY_REPO}/${backend_service}:${image_tag} docker://${CBJ_ARTIFACTORY}/${backend_service}:${image_tag}

                            echo "\n${CBJ_ARTIFACTORY}/${backend_service}:${image_tag}" >> ${WORKSPACE}/imagelist.txt
                            """
                        }
                    }                
                }
            }
        stage('Deploying ${backend_service}') {
            steps {
                container('helm') {
                    script{
                    openshift.withCluster(env.OPENSHIFT_API){
                sh '''
                     oc login --username=${ocp_token_USR}  --password=${ocp_token_PSW} --server=https://api.mykulocp001.dhl.com:6443
                        
                        if [  -z "$(oc  get secrets -n ${TEST_PROJECT}  | grep artifactory)" ]
                        then 
                           oc create secret docker-registry artifactory --docker-server=${ARTIFACTORY_REPO} --docker-username=${git_token_USR}  --docker-password=${git_token_PSW} -n ${TEST_PROJECT}
                           oc secrets link default artifactory --for=pull -n ${TEST_PROJECT} 
                           oc secrets link builder artifactory -n ${TEST_PROJECT}
                        fi
                     sed -i '6s/.*/appVersion: '${version}'/' ${WORKSPACE}/devops/helm/${backend_service}/Chart.yaml
                     
                     helm package ${WORKSPACE}/devops/helm/${backend_service}
                     if [  -z "$(helm ls -n ${TEST_PROJECT}  | grep ${release_name})" ]
                     then
                        helm install ${release_name} ${WORKSPACE}/devops/helm/${backend_service}/ -f ${WORKSPACE}/devops/helm/${backend_service}/${environment}-values.yaml --set global.namespace=${TEST_PROJECT} --set "${service_name}"Service.buildTag=${image_tag}   -n ${TEST_PROJECT} 
                     else
                        helm upgrade ${release_name} ${WORKSPACE}/devops/helm/${backend_service}/ -f ${WORKSPACE}/devops/helm/${backend_service}/${environment}-values.yaml --set global.namespace=${TEST_PROJECT} --set "${service_name}"Service.buildTag=${image_tag}   -n ${TEST_PROJECT} 
                     fi
                     
                     '''
                    }
                }
             }
            }
        }
    }
    
}  
